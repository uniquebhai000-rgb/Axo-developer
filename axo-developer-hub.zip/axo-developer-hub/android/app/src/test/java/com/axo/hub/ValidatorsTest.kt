package com.axo.hub

import com.axo.hub.core.Validators
import org.junit.Assert.*
import org.junit.Test

class ValidatorsTest {
    @Test fun emailAccepts() { assertTrue(Validators.isEmail("a.b+c@example.com")) }
    @Test fun emailRejects() { assertFalse(Validators.isEmail("nope@")); assertFalse(Validators.isEmail("a b@x.io")) }
    @Test fun passwordShort() { assertNotNull(Validators.passwordError("Ab1")) }
    @Test fun passwordNeedsDigit() { assertNotNull(Validators.passwordError("Abcdefgh")) }
    @Test fun passwordNeedsCase() { assertNotNull(Validators.passwordError("abcdefg1")) }
    @Test fun passwordOk() { assertNull(Validators.passwordError("Abcdefg1")) }
    @Test fun scoreGrows() { assertTrue(Validators.passwordScore("Abcdefg1!") > Validators.passwordScore("abc")) }
    @Test fun nameClean() { assertEquals("A B", Validators.cleanName("  A   B ")) }
}
