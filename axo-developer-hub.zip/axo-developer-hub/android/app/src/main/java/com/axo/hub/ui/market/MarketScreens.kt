package com.axo.hub.ui.market

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.axo.hub.core.*
import com.axo.hub.ui.components.*
import com.axo.hub.ui.theme.Axo
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun catIcon(slug: String): ImageVector = when (slug) {
    "minecraft-packs" -> Icons.Filled.GridView
    "minecraft-skins" -> Icons.Filled.Face
    "discord" -> Icons.Filled.Forum
    "apps-websites" -> Icons.Filled.Code
    "graphic-design" -> Icons.Filled.Brush
    else -> Icons.Filled.AutoAwesome
}

@Composable
fun ProjectCardView(card: ProjectCard, unlocked: Boolean, load: suspend (String) -> Bitmap?, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).clickable(onClick = onClick)) {
        RemoteImage(card.coverPath, load,
            Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)))
        Spacer(Modifier.height(12.dp))
        Text(card.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
        Text("by ${card.developer.ifBlank { "Unknown" }}  \u2022  ${card.category}", color = Axo.Mist,
            style = MaterialTheme.typography.bodyMedium, maxLines = 1)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(priceText(card.price), style = MaterialTheme.typography.titleMedium, color = Axo.Orchid)
            Spacer(Modifier.weight(1f))
            if (unlocked) {
                Icon(Icons.Filled.CheckCircle, null, tint = Axo.Success, modifier = Modifier.size(18.dp))
                Text("  Unlocked", color = Axo.Success, style = MaterialTheme.typography.bodyMedium)
            } else {
                Icon(Icons.Filled.Lock, null, tint = Axo.Violet, modifier = Modifier.size(18.dp))
                Text("  Preview available \u2022 Access required", color = Axo.Mist,
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun ProjectList(
    state: Load<List<ProjectCard>>, access: Set<String>, load: suspend (String) -> Bitmap?,
    emptyTitle: String, emptyBody: String, onOpen: (String) -> Unit
) {
    when (state) {
        Load.Loading -> repeat(2) { Skeleton(220.dp, Modifier.padding(bottom = 12.dp)) }
        is Load.Error -> Text(state.msg, color = Axo.Danger, modifier = Modifier.padding(vertical = 8.dp))
        is Load.Ready -> {
            if (state.data.isEmpty()) EmptyState(Icons.Filled.Inventory2, emptyTitle, emptyBody)
            else state.data.forEach { c ->
                ProjectCardView(c, c.id in access, load) { onOpen(c.id) }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun HomeTab(mv: MarketViewModel, name: String, onOpen: (String) -> Unit, onCategory: (String) -> Unit, onSearch: () -> Unit,
            unread: Int, onBell: () -> Unit) {
    val cats by mv.categories.collectAsState()
    val recent by mv.recent.collectAsState()
    val trending by mv.trending.collectAsState()
    val access by mv.access.collectAsState()

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AxoLogo(40.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Welcome back", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                Text(name.ifBlank { "Creator" }, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onBell) {
                BadgedBox(badge = { if (unread > 0) Badge(containerColor = Axo.Magenta) { Text(if (unread > 9) "9+" else unread.toString()) } }) {
                    Icon(Icons.Filled.Notifications, "Notifications", tint = Axo.Orchid)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(
            Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(16.dp)).background(Axo.Panel)
                .clickable(onClick = onSearch).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, null, tint = Axo.Mist)
            Text("  Search projects", color = Axo.Mist)
        }
        Spacer(Modifier.height(20.dp))
        Text("Popular categories", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            cats.filter { it.parentId == null }.forEach { c ->
                Column(
                    Modifier.clip(RoundedCornerShape(18.dp)).background(Axo.Panel)
                        .clickable { onCategory(c.id) }.padding(14.dp).width(104.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Axo.Gradient),
                        contentAlignment = Alignment.Center) {
                        Icon(catIcon(c.slug), null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(c.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("Recently added", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        ProjectList(recent, access, mv::loadImage, "No projects yet",
            "Published projects will show up here.", onOpen)
        Spacer(Modifier.height(10.dp))
        Text("Trending", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        ProjectList(trending, access, mv::loadImage, "Nothing trending yet",
            "Popular projects will appear here.", onOpen)
    }
}

@Composable
fun ExploreTab(mv: MarketViewModel, onOpen: (String) -> Unit) {
    val f by mv.filters.collectAsState()
    val res by mv.results.collectAsState()
    val cats by mv.categories.collectAsState()
    val access by mv.access.collectAsState()
    LaunchedEffect(f) { delay(300); mv.runSearch() }

    val chip = FilterChipDefaults.filterChipColors(
        selectedContainerColor = Axo.Electric, selectedLabelColor = Color.White, labelColor = Axo.Mist)

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Explore", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            f.query, { mv.filters.value = f.copy(query = it.take(40)) }, Modifier.fillMaxWidth(),
            placeholder = { Text("Search projects") },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = Axo.Mist) },
            singleLine = true, shape = RoundedCornerShape(16.dp), colors = axoFieldColors())
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(f.categoryId == null, { mv.filters.value = f.copy(categoryId = null) },
                { Text("All") }, colors = chip)
            cats.filter { it.parentId == null }.forEach { c ->
                FilterChip(f.categoryId == c.id, { mv.filters.value = f.copy(categoryId = c.id) },
                    { Text(c.name) }, colors = chip)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(f.maxPrice == null, { mv.filters.value = f.copy(maxPrice = null) }, { Text("Any price") }, colors = chip)
            FilterChip(f.maxPrice == 0.0, { mv.filters.value = f.copy(maxPrice = 0.0) }, { Text("Free") }, colors = chip)
            FilterChip(f.maxPrice == 500.0, { mv.filters.value = f.copy(maxPrice = 500.0) }, { Text("Under \u20B9500") }, colors = chip)
            FilterChip(!f.popular, { mv.filters.value = f.copy(popular = false) }, { Text("Newest") }, colors = chip)
            FilterChip(f.popular, { mv.filters.value = f.copy(popular = true) }, { Text("Popular") }, colors = chip)
        }
        Spacer(Modifier.height(16.dp))
        ProjectList(res, access, mv::loadImage, "No matches", "Try a different search or filter.", onOpen)
    }
}

@Composable
fun LibraryTab(mv: MarketViewModel, shop: ShopViewModel, onOpen: (String) -> Unit) {
    val unlocked by mv.unlocked.collectAsState()
    val saved by mv.saved.collectAsState()
    val access by mv.access.collectAsState()
    val pays by shop.payments.collectAsState()
    LaunchedEffect(Unit) { mv.refreshLibrary(); shop.loadPayments() }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("My Library", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Text("Unlocked", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        ProjectList(unlocked, access, mv::loadImage, "Nothing unlocked yet",
            "Projects appear here after your payment is approved.", onOpen)
        Spacer(Modifier.height(10.dp))
        Text("Saved", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        ProjectList(saved, access, mv::loadImage, "No saved projects",
            "Tap the heart on a project to save it.", onOpen)
        Spacer(Modifier.height(10.dp))
        Text("My payments", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        when (val p = pays) {
            Load.Loading -> Skeleton(60.dp)
            is Load.Error -> Text(p.msg, color = Axo.Danger)
            is Load.Ready -> {
                if (p.data.isEmpty()) Text("No payments yet.", color = Axo.Mist)
                p.data.forEach { m ->
                    val color = when (m.status) { "APPROVED" -> Axo.Success; "REJECTED", "REFUNDED" -> Axo.Danger; else -> Axo.Orchid }
                    GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(m.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                Text("${priceText(m.amount)}  \u2022  ${m.date}", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                                if (m.reason.isNotBlank()) Text(m.reason, color = Axo.Danger, style = MaterialTheme.typography.bodyMedium)
                            }
                            Text(m.status.replace('_', ' '), color = color, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBar(onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun DetailScreen(mv: MarketViewModel, shop: ShopViewModel, id: String, account: String, onBack: () -> Unit,
                 onPreview: () -> Unit, onGetAccess: (ProjectCard) -> Unit) {
    SecureScreen()
    LaunchedEffect(id) { mv.openDetail(id) }
    val st by mv.detail.collectAsState()
    val access by mv.access.collectAsState()
    val favs by mv.favIds.collectAsState()
    val paysState by shop.payments.collectAsState()
    LaunchedEffect(id) { shop.loadPayments() }
    val filesState by mv.files.collectAsState()
    val fileList = when (val f = filesState) { is Load.Ready -> f.data; else -> emptyList() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    val startDownload: (String) -> Unit = { fid ->
        if (!busy) {
            busy = true
            scope.launch {
                val res = runCatching { mv.ticket(id, fid) }
                busy = false
                val msg = res.fold(
                    onSuccess = { t -> Downloader.enqueue(ctx, t) },
                    onFailure = { e ->
                        if (e is ApiError && e.kind == Kind.RATE) "Too many attempts. Wait a minute."
                        else "Download not allowed or failed."
                    })
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        when (val s = st) {
            Load.Loading -> {
                TopBar(onBack)
                Column(Modifier.padding(20.dp)) { Skeleton(200.dp); Spacer(Modifier.height(14.dp)); Skeleton(90.dp) }
            }
            is Load.Error -> {
                TopBar(onBack)
                EmptyState(Icons.Filled.ErrorOutline, "Couldn't load project", s.msg)
            }
            is Load.Ready -> {
                val d = s.data
                if (d == null) {
                    TopBar(onBack)
                    EmptyState(Icons.Filled.Block, "Project not available", "It may have been removed or unpublished.")
                } else {
                    val unlocked = d.card.id in access
                    LaunchedEffect(d.card.id, unlocked) { if (unlocked) mv.loadFiles(d.card.id) }
                    TopBar(onBack) {
                        IconButton({ mv.toggleFavorite(d.card.id) }) {
                            Icon(if (d.card.id in favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                "Save", tint = Axo.Orchid)
                        }
                    }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                        RemoteImage(d.card.coverPath ?: d.previews.firstOrNull(), mv::loadImage,
                            Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(20.dp)).watermark(account))
                        Spacer(Modifier.height(16.dp))
                        Text(d.card.title, style = MaterialTheme.typography.headlineMedium)
                        Text("by ${d.card.developer.ifBlank { "Unknown" }}  \u2022  ${d.card.category}", color = Axo.Mist)
                        Spacer(Modifier.height(10.dp))
                        Text(priceText(d.card.price), style = MaterialTheme.typography.titleLarge, color = Axo.Orchid)
                        Spacer(Modifier.height(14.dp))
                        GlassCard(Modifier.fillMaxWidth(), animatedBorder = !unlocked) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (unlocked) {
                                    Icon(Icons.Filled.CheckCircle, null, tint = Axo.Success)
                                    Text("  Access unlocked", color = Axo.Success, fontWeight = FontWeight.SemiBold)
                                } else {
                                    Icon(Icons.Filled.Lock, null, tint = Axo.Violet)
                                    Text("  Locked \u2022 Preview available", fontWeight = FontWeight.SemiBold)
                                }
                            }
                            Text(
                                if (unlocked) "Your files are ready to download below."
                                else "Original files stay locked until your payment is approved by the admin.",
                                color = Axo.Mist, modifier = Modifier.padding(top = 6.dp))
                        }
                        if (d.card.version.isNotBlank() || d.updated.isNotBlank()) {
                            Spacer(Modifier.height(14.dp))
                            Text("Version ${d.card.version}   \u2022   Updated ${d.updated}", color = Axo.Mist)
                        }
                        if (d.description.isNotBlank()) {
                            Spacer(Modifier.height(16.dp))
                            Text("About", style = MaterialTheme.typography.titleMedium)
                            Text(d.description, modifier = Modifier.padding(top = 6.dp))
                        }
                        if (d.features.isNotEmpty()) {
                            Spacer(Modifier.height(16.dp))
                            Text("Features", style = MaterialTheme.typography.titleMedium)
                            d.features.forEach {
                                Row(Modifier.padding(top = 6.dp)) {
                                    Icon(Icons.Filled.Check, null, tint = Axo.Orchid, modifier = Modifier.size(18.dp))
                                    Text("  $it")
                                }
                            }
                        }
                        if (d.compatibility.isNotBlank()) {
                            Spacer(Modifier.height(16.dp))
                            Text("Compatibility", style = MaterialTheme.typography.titleMedium)
                            Text(d.compatibility, modifier = Modifier.padding(top = 6.dp))
                        }
                        if (unlocked) {
                            Spacer(Modifier.height(16.dp))
                            Text("Files", style = MaterialTheme.typography.titleMedium)
                            when (val fs = filesState) {
                                Load.Loading -> Skeleton(56.dp, Modifier.padding(top = 8.dp))
                                is Load.Error -> Text("Couldn't load files. Try again later.", color = Axo.Danger,
                                    modifier = Modifier.padding(top = 6.dp))
                                is Load.Ready -> {
                                    if (fs.data.isEmpty()) Text("The developer hasn't uploaded files yet.", color = Axo.Mist,
                                        modifier = Modifier.padding(top = 6.dp))
                                    fs.data.forEach { f ->
                                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(f.name, maxLines = 1)
                                                Text("${sizeText(f.size)}  \u2022  v${f.version}", color = Axo.Mist,
                                                    style = MaterialTheme.typography.bodyMedium)
                                            }
                                            IconButton({ startDownload(f.id) }, enabled = !busy) {
                                                Icon(Icons.Filled.Download, "Download", tint = Axo.Orchid)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("How to get access", style = MaterialTheme.typography.titleMedium)
                        Text("1. Tap GET ACCESS and pay using the shown instructions.\n2. Submit your payment reference.\n3. The admin verifies it and unlocks the project.",
                            color = Axo.Mist, modifier = Modifier.padding(top = 6.dp))
                        Spacer(Modifier.height(16.dp))
                        Text("Developer", style = MaterialTheme.typography.titleMedium)
                        Text(d.card.developer, modifier = Modifier.padding(top = 6.dp), fontWeight = FontWeight.SemiBold)
                        if (d.devBio.isNotBlank()) Text(d.devBio, color = Axo.Mist)
                        d.links.forEach { Text(it, color = Axo.Orchid) }
                        Spacer(Modifier.height(20.dp))
                    }
                    val myPay = (paysState as? Load.Ready<List<MyPayment>>)?.data?.firstOrNull { it.projectId == d.card.id }
                    val inReview = !unlocked && myPay != null && (myPay.status == "PENDING" || myPay.status == "UNDER_REVIEW")
                    val rejected = !unlocked && myPay != null && myPay.status == "REJECTED"
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (inReview) Text("Your payment is being verified. You'll get a notification once it's approved.",
                            color = Axo.Orchid, style = MaterialTheme.typography.bodyMedium)
                        if (rejected) Text("Payment rejected: ${myPay?.reason ?: ""}. You can submit again.",
                            color = Axo.Danger, style = MaterialTheme.typography.bodyMedium)
                        OutlinedButton(onPreview, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
                            enabled = d.previews.isNotEmpty()) {
                            Text(if (d.previews.isEmpty()) "NO PREVIEW YET" else "PREVIEW PROJECT")
                        }
                        if (unlocked) GradientButton("DOWNLOAD", loading = busy, enabled = fileList.isNotEmpty(),
                            onClick = { fileList.firstOrNull()?.let { startDownload(it.id) } })
                        else if (inReview) GradientButton("PAYMENT UNDER REVIEW", onClick = {}, enabled = false)
                        else GradientButton(if (rejected) "TRY AGAIN" else "GET ACCESS", onClick = { onGetAccess(d.card) })
                    }
                }
            }
        }
    }
}

@Composable
fun PreviewScreen(mv: MarketViewModel, account: String, onBack: () -> Unit) {
    SecureScreen()
    val st by mv.detail.collectAsState()
    val previews = ((st as? Load.Ready<*>)?.data as? ProjectDetail)?.previews ?: emptyList()
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(onBack) { Text("Protected preview", color = Axo.Mist, modifier = Modifier.padding(end = 12.dp)) }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            if (previews.isEmpty()) EmptyState(Icons.Filled.Photo, "No preview files", "The developer hasn't added previews yet.")
            previews.forEach { p ->
                RemoteImage(p, mv::loadImage,
                    Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).watermark(account))
                Spacer(Modifier.height(12.dp))
            }
            Text("Preview only. Screenshots and screen recording are blocked where supported, and every preview carries your account ID.",
                color = Axo.Mist, modifier = Modifier.padding(vertical = 12.dp))
        }
    }
}
