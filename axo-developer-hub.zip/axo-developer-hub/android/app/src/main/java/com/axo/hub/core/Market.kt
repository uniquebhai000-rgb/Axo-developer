package com.axo.hub.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    data class Error(val msg: String) : Load<Nothing>
    data class Ready<T>(val data: T) : Load<T>
}

data class Category(val id: String, val parentId: String?, val slug: String, val name: String)

data class ProjectCard(
    val id: String, val title: String, val price: Double, val coverPath: String?,
    val developer: String, val category: String, val version: String, val downloads: Int
)

data class ProjectDetail(
    val card: ProjectCard, val description: String, val features: List<String>,
    val compatibility: String, val devBio: String, val links: List<String>,
    val previews: List<String>, val updated: String
)

data class FileInfo(val id: String, val name: String, val size: Long, val version: String)
data class Ticket(val url: String, val name: String)

fun sizeText(b: Long): String = when {
    b >= 1_048_576 -> String.format(java.util.Locale.US, "%.1f MB", b / 1_048_576.0)
    b >= 1024 -> "${b / 1024} KB"
    else -> "$b B"
}

data class Filters(
    val query: String = "", val categoryId: String? = null,
    val maxPrice: Double? = null, val popular: Boolean = false
)

fun priceText(p: Double): String =
    if (p <= 0.0) "Free" else if (p % 1.0 == 0.0) "\u20B9${p.toInt()}" else "\u20B9$p"

fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)
private fun JSONArray?.strings(): List<String> =
    if (this == null) emptyList() else List(length()) { optString(it) }

object ImageCache {
    private val c = LruCache<String, Bitmap>(24)
    fun get(k: String): Bitmap? = c.get(k)
    fun put(k: String, v: Bitmap) { c.put(k, v) }
}

class MarketRepository(private val auth: AuthRepository) {
    private val sel = "id,title,price_inr,cover_path,version,download_count," +
        "developer_profiles(display_name),categories(name)"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private suspend fun get(path: String, single: Boolean = false): Resp {
        val r = auth.rest("GET", path, null, single)
        if (r.code !in 200..299 && !(single && r.code == 406))
            throw ApiError(Kind.OTHER, "${r.code} ${r.errorCode}".trim())
        return r
    }

    private fun nowIso(): String {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date())
    }

    private fun activeFilter() = "&or=" + enc("(expires_at.is.null,expires_at.gt.${nowIso()})")

    private fun card(o: JSONObject) = ProjectCard(
        o.getString("id"), o.str("title"), o.optDouble("price_inr", 0.0),
        o.str("cover_path").ifBlank { null },
        o.optJSONObject("developer_profiles")?.str("display_name") ?: "",
        o.optJSONObject("categories")?.str("name") ?: "",
        o.str("version"), o.optInt("download_count", 0)
    )

    suspend fun categories(): List<Category> {
        val a = JSONArray(get("/rest/v1/categories?select=id,parent_id,slug,name,sort_order&order=sort_order.asc").body)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Category(o.getString("id"), if (o.isNull("parent_id")) null else o.getString("parent_id"),
                o.str("slug"), o.str("name"))
        }
    }

    suspend fun projects(f: Filters, categoryIds: List<String>, limit: Int = 30): List<ProjectCard> {
        val q = StringBuilder("/rest/v1/projects?select=$sel&status=eq.PUBLISHED&deleted_at=is.null")
        val term = f.query.replace(Regex("[*,()%\\\\\"'&=]"), " ").trim().take(40)
        if (term.isNotEmpty()) q.append("&title=ilike.").append(enc("*$term*"))
        if (categoryIds.isNotEmpty()) q.append("&category_id=in.(").append(categoryIds.joinToString(",")).append(")")
        f.maxPrice?.let { q.append("&price_inr=lte.").append(it) }
        q.append(if (f.popular) "&order=download_count.desc,published_at.desc" else "&order=published_at.desc")
        q.append("&limit=").append(limit)
        val a = JSONArray(get(q.toString()).body)
        return List(a.length()) { card(a.getJSONObject(it)) }
    }

    suspend fun detail(id: String): ProjectDetail? {
        val r = get("/rest/v1/projects?id=eq.${enc(id)}&select=id,title,price_inr,cover_path,version,download_count," +
            "description,features,compatibility,published_at,categories(name)," +
            "developer_profiles(display_name,bio,portfolio_links),project_previews(storage_path,sort_order)", single = true)
        if (r.code != 200) return null
        val o = r.json()
        val dev = o.optJSONObject("developer_profiles")
        val pv = o.optJSONArray("project_previews")
        val previews = if (pv == null) emptyList() else
            (0 until pv.length()).map { pv.getJSONObject(it) }
                .sortedBy { it.optInt("sort_order") }.map { it.str("storage_path") }
        val card = ProjectCard(
            o.getString("id"), o.str("title"), o.optDouble("price_inr", 0.0), o.str("cover_path").ifBlank { null },
            dev?.str("display_name") ?: "", o.optJSONObject("categories")?.str("name") ?: "",
            o.str("version"), o.optInt("download_count", 0))
        return ProjectDetail(card, o.str("description"), o.optJSONArray("features").strings(),
            o.str("compatibility"), dev?.str("bio") ?: "", dev?.optJSONArray("portfolio_links").strings(),
            previews, o.str("published_at").take(10))
    }

    suspend fun myAccess(): Set<String> {
        val a = JSONArray(get("/rest/v1/project_access?status=eq.ACTIVE&select=project_id${activeFilter()}").body)
        return (0 until a.length()).map { a.getJSONObject(it).str("project_id") }.toSet()
    }

    suspend fun library(): List<ProjectCard> {
        val a = JSONArray(get("/rest/v1/project_access?status=eq.ACTIVE&select=projects($sel)" +
            "${activeFilter()}&order=granted_at.desc").body)
        return (0 until a.length()).mapNotNull { a.getJSONObject(it).optJSONObject("projects") }.map { card(it) }
    }

    suspend fun favorites(): List<ProjectCard> {
        val a = JSONArray(get("/rest/v1/favorites?select=projects($sel)&order=created_at.desc").body)
        return (0 until a.length()).mapNotNull { a.getJSONObject(it).optJSONObject("projects") }.map { card(it) }
    }

    suspend fun addFavorite(id: String) {
        val r = auth.rest("POST", "/rest/v1/favorites", JSONObject().put("project_id", id))
        if (r.code !in 200..299 && r.code != 409) throw ApiError(Kind.OTHER, "${r.code}")
    }

    suspend fun removeFavorite(id: String) {
        val r = auth.rest("DELETE", "/rest/v1/favorites?project_id=eq.${enc(id)}")
        if (r.code !in 200..299) throw ApiError(Kind.OTHER, "${r.code}")
    }

    /** Preview/cover image from the private previews bucket via a 5-minute signed URL. Memory cache only. */
    suspend fun image(path: String, bucket: String = "previews"): Bitmap? {
        val key = "$bucket/$path"
        ImageCache.get(key)?.let { return it }
        val signed = auth.storageSign(bucket, path) ?: return null
        val bytes = Api.getBytes(signed) ?: return null
        val bmp = decode(bytes) ?: return null
        ImageCache.put(key, bmp)
        return bmp
    }

    private fun decode(b: ByteArray): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / s > 1400) s *= 2
        return BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
    }

    /** File list for a project. The server only answers when this user has ACTIVE access. */
    suspend fun files(projectId: String): List<FileInfo> {
        val r = auth.rest("POST", "/functions/v1/get-download-url",
            JSONObject().put("action", "list").put("project_id", projectId), logoutOn401 = false)
        if (r.code !in 200..299) throw ApiError(Kind.OTHER, "${r.code}")
        val a = r.json().optJSONArray("files") ?: return emptyList()
        return List(a.length()) {
            val o = a.getJSONObject(it)
            FileInfo(o.str("id"), o.str("file_name"), o.optLong("size_bytes"), o.str("version"))
        }
    }

    /** Asks the AXO LOCK server for a 60-second signed download link. */
    suspend fun downloadTicket(projectId: String, fileId: String): Ticket {
        val r = auth.rest("POST", "/functions/v1/get-download-url",
            JSONObject().put("action", "download").put("project_id", projectId).put("file_id", fileId),
            logoutOn401 = false)
        when {
            r.code == 429 -> throw ApiError(Kind.RATE)
            r.code == 403 || r.code == 401 -> throw ApiError(Kind.INVALID, "denied")
            r.code !in 200..299 -> throw ApiError(Kind.OTHER, "${r.code}")
        }
        val j = r.json()
        val url = j.str("url")
        if (url.isBlank()) throw ApiError(Kind.OTHER, "no url")
        return Ticket(url, j.str("file_name").ifBlank { "download" })
    }
}
