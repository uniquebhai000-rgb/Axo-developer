package com.axo.hub.ui.auth

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.axo.hub.core.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AuthMode { SIGN_IN, SIGN_UP, FORGOT, CHECK_INBOX, RESET_SENT }
data class AuthUi(val mode: AuthMode = AuthMode.SIGN_IN, val loading: Boolean = false,
                  val error: String? = null)

class AuthViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ServiceLocator.auth(app)
    val session = MutableStateFlow<SessionState>(SessionState.Loading)
    val ui = MutableStateFlow(AuthUi())

    private var fails = 0
    private var lockedUntil = 0L

    init {
        viewModelScope.launch {
            try {
                val u = repo.restore()
                session.value = if (u != null) SessionState.SignedIn(u) else SessionState.SignedOut
            } catch (e: ApiError) {
                session.value = SessionState.SignedOut
                ui.update { it.copy(error = message(e)) }
            }
        }
    }

    val configured get() = repo.configured

    fun setMode(m: AuthMode) { ui.value = AuthUi(mode = m) }

    private fun message(e: ApiError) = when (e.kind) {
        Kind.INVALID -> "Email or password is incorrect."
        Kind.UNVERIFIED -> "Verify your email first. Check your inbox for the link."
        Kind.RATE -> "Too many attempts. Wait a minute and try again."
        Kind.NETWORK -> "Can't reach the server. Check your connection."
        Kind.NOT_CONFIGURED -> "Backend is not configured. Add SUPABASE_URL and SUPABASE_ANON_KEY and rebuild."
        Kind.OTHER -> friendly(e.detail)
    }

    private fun friendly(d: String): String = when {
        d.isBlank() -> "Something went wrong. Try again."
        "email_address_not_authorized" in d ->
            "Verification email can't be sent to this address yet. Set up custom email (SMTP) in Supabase."
        "unexpected_failure" in d || d.startsWith("500") ->
            "Server couldn't send the verification email. Check Supabase email settings. ($d)"
        else -> "Something went wrong ($d)."
    }

    private fun fail(e: Throwable) {
        val msg = if (e is ApiError) message(e) else "Something went wrong. Try again."
        ui.update { it.copy(loading = false, error = msg) }
    }

    fun signIn(email: String, password: String) {
        val wait = (lockedUntil - System.currentTimeMillis()) / 1000
        if (wait > 0) { ui.update { it.copy(error = "Too many failed attempts. Try again in ${wait}s.") }; return }
        if (!Validators.isEmail(email) || password.isEmpty()) {
            ui.update { it.copy(error = "Enter a valid email and your password.") }; return
        }
        ui.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val u = repo.signIn(email, password)
                fails = 0
                ui.value = AuthUi()
                session.value = SessionState.SignedIn(u)
            } catch (e: ApiError) {
                if (e.kind == Kind.INVALID && ++fails >= 5) {
                    lockedUntil = System.currentTimeMillis() + 60_000; fails = 0
                }
                fail(e)
            } catch (e: Exception) { fail(e) }
        }
    }

    fun signUp(email: String, password: String, confirm: String, name: String, agreed: Boolean) {
        val n = Validators.cleanName(name)
        val err = when {
            n.length < 2 -> "Enter your name (2+ characters)."
            !Validators.isEmail(email) -> "Enter a valid email address."
            Validators.passwordError(password) != null -> Validators.passwordError(password)
            password != confirm -> "Passwords don't match."
            !agreed -> "Accept the Terms and Privacy Policy to continue."
            else -> null
        }
        if (err != null) { ui.update { it.copy(error = err) }; return }
        ui.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                repo.signUp(email, password, n)
                ui.value = AuthUi(mode = AuthMode.CHECK_INBOX)
            } catch (e: ApiError) {
                if (e.kind == Kind.INVALID) ui.update { it.copy(loading = false, error = "Choose a stronger password.") }
                else fail(e)
            } catch (e: Exception) { fail(e) }
        }
    }

    fun forgot(email: String) {
        if (!Validators.isEmail(email)) { ui.update { it.copy(error = "Enter a valid email address.") }; return }
        ui.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try { repo.recover(email); ui.value = AuthUi(mode = AuthMode.RESET_SENT) }
            catch (e: Exception) { fail(e) }
        }
    }

    fun signOut() {
        viewModelScope.launch { repo.signOut(); ui.value = AuthUi(); session.value = SessionState.SignedOut }
    }

    fun updateProfile(name: String, bio: String, onDone: (String?) -> Unit) {
        val n = Validators.cleanName(name)
        if (n.length < 2) { onDone("Name must be 2+ characters."); return }
        viewModelScope.launch {
            try {
                val u = repo.updateProfile(n, bio.trim().take(300))
                session.value = SessionState.SignedIn(u); onDone(null)
            } catch (e: ApiError) { onDone(message(e)) }
        }
    }
}
