package com.axo.hub.core

object Validators {
    private val emailRegex = Regex("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}$")

    fun isEmail(v: String) = v.length <= 254 && emailRegex.matches(v.trim())

    /** 0..4 : length>=8, lower, upper, digit/symbol */
    fun passwordScore(p: String): Int {
        var s = 0
        if (p.length >= 8) s++
        if (p.any { it.isLowerCase() } && p.any { it.isUpperCase() }) s++
        if (p.any { it.isDigit() }) s++
        if (p.any { !it.isLetterOrDigit() } || p.length >= 14) s++
        return s
    }

    /** Minimum policy: 8+ chars, upper, lower, digit. Returns error text or null. */
    fun passwordError(p: String): String? = when {
        p.length < 8 -> "Use at least 8 characters."
        p.length > 72 -> "Password is too long (max 72)."
        p.none { it.isLowerCase() } || p.none { it.isUpperCase() } -> "Mix upper and lower case letters."
        p.none { it.isDigit() } -> "Add at least one number."
        else -> null
    }

    fun cleanName(v: String): String = v.trim().replace(Regex("\\s+"), " ").take(40)
}
