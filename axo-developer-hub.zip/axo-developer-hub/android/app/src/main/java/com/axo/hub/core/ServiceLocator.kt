package com.axo.hub.core

import android.content.Context

/** One shared AuthRepository so token refreshes are never done by two instances at once. */
object ServiceLocator {
    @Volatile private var instance: AuthRepository? = null
    fun auth(ctx: Context): AuthRepository =
        instance ?: synchronized(this) {
            instance ?: AuthRepository(ctx.applicationContext).also { instance = it }
        }
}
