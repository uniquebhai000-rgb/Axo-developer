package com.axo.hub.core

enum class Kind { INVALID, UNVERIFIED, RATE, NETWORK, NOT_CONFIGURED, OTHER }
class ApiError(val kind: Kind, val detail: String = "") : Exception(kind.name)

data class UserInfo(
    val id: String,
    val email: String,
    val accountCode: String,
    val displayName: String,
    val bio: String,
    val roles: Set<String>
) {
    // Display only. Real enforcement happens in the backend (RLS + Edge Functions).
    val canUseStudio get() = "DEVELOPER" in roles || "SUPER_ADMIN" in roles
}

sealed interface SessionState {
    data object Loading : SessionState
    data object SignedOut : SessionState
    data class SignedIn(val user: UserInfo) : SessionState
}
