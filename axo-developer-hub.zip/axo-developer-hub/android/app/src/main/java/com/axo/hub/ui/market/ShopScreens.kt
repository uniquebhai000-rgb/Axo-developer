package com.axo.hub.ui.market

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.axo.hub.core.*
import com.axo.hub.ui.components.*
import com.axo.hub.ui.theme.Axo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ToastHost(flow: MutableStateFlow<String?>) {
    val ctx = LocalContext.current
    val m by flow.collectAsState()
    LaunchedEffect(m) {
        val t = m
        if (t != null) { Toast.makeText(ctx, t, Toast.LENGTH_LONG).show(); flow.value = null }
    }
}

@Composable
private fun Bar(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

// ------------------------------------------------------------------ pay for a project
@Composable
fun PaymentScreen(shop: ShopViewModel, mv: MarketViewModel, card: ProjectCard, userId: String, onBack: () -> Unit) {
    LaunchedEffect(Unit) { shop.loadSettings(); shop.submitted.value = false }
    ToastHost(shop.message)
    val st by shop.settings.collectAsState()
    val busy by shop.busy.collectAsState()
    val done by shop.submitted.collectAsState()
    val clip = LocalClipboardManager.current
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    var ref by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today) }
    var note by remember { mutableStateOf("") }
    var proof by remember { mutableStateOf<Uri?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) proof = u }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Bar("Get access", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Text(card.title, style = MaterialTheme.typography.titleLarge)
            Text("Amount to pay: ${priceText(card.price)}", color = Axo.Orchid, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(16.dp))
            if (done) {
                GlassCard(Modifier.fillMaxWidth(), animatedBorder = true) {
                    Icon(Icons.Filled.CheckCircle, null, tint = Axo.Success, modifier = Modifier.size(40.dp))
                    Text("Request sent", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp))
                    Text("Status: PENDING. The owner will verify your payment. You'll get a notification when it's approved. Your files stay locked until then.",
                        color = Axo.Mist, modifier = Modifier.padding(top = 6.dp))
                }
                Spacer(Modifier.height(14.dp))
                GradientButton("DONE", onClick = onBack)
            } else {
                when (val s = st) {
                    Load.Loading -> Skeleton(160.dp)
                    is Load.Error -> Text(s.msg, color = Axo.Danger)
                    is Load.Ready -> {
                        val ps = s.data
                        GlassCard(Modifier.fillMaxWidth(), animatedBorder = true) {
                            Text("Step 1: Pay", style = MaterialTheme.typography.titleMedium)
                            if (ps.upi.isBlank() && ps.qrPath == null)
                                Text("The owner hasn't set payment details yet. Please contact support.", color = Axo.Danger,
                                    modifier = Modifier.padding(top = 8.dp))
                            if (ps.upi.isNotBlank()) {
                                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("UPI ID", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                                        Text(ps.upi, fontWeight = FontWeight.SemiBold)
                                    }
                                    IconButton({ clip.setText(AnnotatedString(ps.upi)) }) {
                                        Icon(Icons.Filled.ContentCopy, "Copy UPI ID", tint = Axo.Orchid)
                                    }
                                }
                            }
                            ps.qrPath?.let { q ->
                                Spacer(Modifier.height(8.dp))
                                RemoteImage(q, { p -> mv.loadImageFrom("payment-assets", p) },
                                    Modifier.size(220.dp).align(Alignment.CenterHorizontally).clip(RoundedCornerShape(16.dp)))
                            }
                            if (ps.instructions.isNotBlank()) Text(ps.instructions, modifier = Modifier.padding(top = 10.dp))
                            if (ps.support.isNotBlank()) Text("Support: ${ps.support}", color = Axo.Mist, modifier = Modifier.padding(top = 8.dp))
                            if (ps.terms.isNotBlank()) Text(ps.terms, color = Axo.Mist, style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 8.dp))
                            Text("Never share your UPI PIN, card details or passwords with anyone. We never ask for them.",
                                color = Axo.Orchid, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("Step 2: Tell us you paid", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(ref, { ref = it.take(40) }, Modifier.fillMaxWidth(), label = { Text("Transaction / UTR reference") },
                    singleLine = true, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(date, { date = it.take(10) }, Modifier.fillMaxWidth(), label = { Text("Payment date (YYYY-MM-DD)") },
                    singleLine = true, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(note, { note = it.take(500) }, Modifier.fillMaxWidth(), label = { Text("Message (optional)") },
                    minLines = 2, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedButton({ pick.launch("image/*") }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Filled.Photo, null); Spacer(Modifier.width(8.dp))
                    Text(if (proof == null) "Add payment screenshot (optional)" else "Screenshot added (tap to change)")
                }
                err?.let { Text(it, color = Axo.Danger, modifier = Modifier.padding(top = 8.dp)) }
                Spacer(Modifier.height(14.dp))
                GradientButton("SUBMIT PAYMENT REQUEST", loading = busy, onClick = {
                    when {
                        ref.trim().length < 6 -> err = "Enter the transaction reference (6+ characters)."
                        !Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(date) -> err = "Use the date format YYYY-MM-DD."
                        else -> { err = null; shop.submitPayment(userId, card.id, ref.trim(), date, proof, note.trim()) }
                    }
                })
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

// ------------------------------------------------------------------ notifications
@Composable
fun NotificationsScreen(shop: ShopViewModel, onBack: () -> Unit) {
    val st by shop.notices.collectAsState()
    LaunchedEffect(Unit) { shop.loadNotices(); delay(2000); shop.markAllRead() }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Bar("Notifications", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            when (val s = st) {
                Load.Loading -> { Skeleton(70.dp); Spacer(Modifier.height(10.dp)); Skeleton(70.dp) }
                is Load.Error -> Text(s.msg, color = Axo.Danger)
                is Load.Ready -> {
                    if (s.data.isEmpty()) EmptyState(Icons.Filled.Notifications, "Nothing yet", "Payment and access updates appear here.")
                    s.data.forEach { n ->
                        GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (!n.read) Box(Modifier.size(9.dp).clip(RoundedCornerShape(5.dp)).background(Axo.Magenta))
                                if (!n.read) Spacer(Modifier.width(8.dp))
                                Text(n.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                Text(n.date, color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                            }
                            if (n.body.isNotBlank()) Text(n.body, color = Axo.Mist, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ support (customer + owner inbox)
@Composable
fun SupportScreen(shop: ShopViewModel, admin: Boolean, onBack: () -> Unit) {
    var open by remember { mutableStateOf<SupportTicket?>(null) }
    var creating by remember { mutableStateOf(false) }
    val tickets by shop.tickets.collectAsState()
    val thread by shop.thread.collectAsState()
    val busy by shop.busy.collectAsState()
    ToastHost(shop.message)
    LaunchedEffect(admin) { shop.loadTickets(admin) }
    BackHandler(enabled = open != null) { open = null }

    val t = open
    if (t == null) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Bar(if (admin) "Support inbox" else "Help & support", onBack)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                if (!admin) { GradientButton("+ NEW TICKET", onClick = { creating = true }); Spacer(Modifier.height(14.dp)) }
                when (val s = tickets) {
                    Load.Loading -> { Skeleton(64.dp); Spacer(Modifier.height(10.dp)); Skeleton(64.dp) }
                    is Load.Error -> Text(s.msg, color = Axo.Danger)
                    is Load.Ready -> {
                        if (s.data.isEmpty()) EmptyState(Icons.Filled.SupportAgent, "No tickets", if (admin) "Customer questions appear here." else "Tap NEW TICKET if you need help.")
                        s.data.forEach { k ->
                            GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(24.dp)).clickable { open = k; shop.loadThread(k.id) }) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(k.subject, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                        Text(listOf(k.category, k.who, k.date).filter { it.isNotBlank() }.joinToString("  \u2022  "),
                                            color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    Text(k.status, color = if (k.status == "CLOSED") Axo.Mist else Axo.Orchid, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        var text by remember(t.id) { mutableStateOf("") }
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            Bar(t.subject, { open = null }) {
                if (!admin && t.status != "CLOSED")
                    TextButton({ shop.close(t.id, false) { open = null } }) { Text("Close", color = Axo.Danger) }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
                when (val m = thread) {
                    Load.Loading -> Skeleton(80.dp)
                    is Load.Error -> Text(m.msg, color = Axo.Danger)
                    is Load.Ready -> m.data.forEach { msg ->
                        val mine = msg.staff == admin
                        Column(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                            Text(if (msg.staff) "Support" else "Customer", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                            Box(Modifier.clip(RoundedCornerShape(16.dp)).background(if (mine) Axo.Electric else Axo.Panel).padding(12.dp)) {
                                Text(msg.body)
                            }
                            Text(msg.date, color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            if (t.status != "CLOSED") {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(text, { text = it.take(3000) }, Modifier.weight(1f), placeholder = { Text("Write a reply") },
                        colors = axoFieldColors(), shape = RoundedCornerShape(16.dp), maxLines = 4)
                    IconButton({ if (text.isNotBlank() && !busy) { shop.reply(t.id, text.trim(), admin); text = "" } }) {
                        Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Axo.Orchid)
                    }
                }
            } else Text("This ticket is closed.", color = Axo.Mist, modifier = Modifier.padding(16.dp))
        }
    }

    if (creating) {
        var cat by remember { mutableStateOf("Payment") }
        var subject by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        val chip = FilterChipDefaults.filterChipColors(selectedContainerColor = Axo.Electric, selectedLabelColor = Color.White, labelColor = Axo.Mist)
        AlertDialog(
            onDismissRequest = { creating = false }, containerColor = Axo.Panel,
            title = { Text("New ticket") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                        listOf("Payment", "Access", "Account", "Other").forEach { c ->
                            FilterChip(cat == c, { cat = c }, { Text(c) }, colors = chip)
                        }
                    }
                    OutlinedTextField(subject, { subject = it.take(120) }, label = { Text("Subject") }, singleLine = true,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(body, { body = it.take(3000) }, label = { Text("Message") }, minLines = 3,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                }
            },
            confirmButton = {
                TextButton(enabled = subject.trim().length >= 3 && body.isNotBlank() && !busy, onClick = {
                    shop.createTicket(cat, subject.trim(), body.trim(), false); creating = false
                }) { Text("Send") }
            },
            dismissButton = { TextButton({ creating = false }) { Text("Cancel") } })
    }
}
