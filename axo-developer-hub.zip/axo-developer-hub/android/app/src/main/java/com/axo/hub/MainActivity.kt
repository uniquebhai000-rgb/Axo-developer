package com.axo.hub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.axo.hub.core.SessionState
import com.axo.hub.ui.auth.AuthScreen
import com.axo.hub.ui.auth.AuthViewModel
import com.axo.hub.ui.home.HomeScreen
import com.axo.hub.ui.splash.SplashScreen
import com.axo.hub.ui.theme.AxoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AxoTheme {
                val vm: AuthViewModel = viewModel()
                val s by vm.session.collectAsState()
                // The home screen is only reachable with a server-verified session.
                when (val st = s) {
                    SessionState.Loading -> SplashScreen()
                    SessionState.SignedOut -> AuthScreen(vm)
                    is SessionState.SignedIn -> HomeScreen(st.user, vm::signOut, vm::updateProfile)
                }
            }
        }
    }
}
