package com.axo.hub.ui.splash

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.axo.hub.ui.components.AxoBackground
import com.axo.hub.ui.components.AxoLogo
import com.axo.hub.ui.theme.Axo

@Composable
fun SplashScreen() {
    AxoBackground {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally) {
            AxoLogo(200.dp)
        }
    }
}
