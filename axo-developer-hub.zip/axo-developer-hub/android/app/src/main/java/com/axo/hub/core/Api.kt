package com.axo.hub.core

import com.axo.hub.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Resp(val code: Int, val body: String) {
    fun json(): JSONObject = try { JSONObject(body) } catch (e: Exception) { JSONObject() }
    val errorCode: String get() = json().optString("error_code", json().optString("code", ""))
}

/** Minimal HTTPS client for Supabase Auth + PostgREST. Public anon key only. */
object Api {
    // Only scheme + host are used, so a pasted "https://x.supabase.co/rest/v1/" still works.
    private val base get() = try {
        "https://" + URL(BuildConfig.SUPABASE_URL.trim()).host
    } catch (e: Exception) { "" }
    private val key get() = BuildConfig.SUPABASE_ANON_KEY.trim()
    val configured get() = base.length > 8 && key.isNotBlank()

    suspend fun call(
        method: String, path: String, body: JSONObject? = null,
        token: String? = null, single: Boolean = false
    ): Resp = withContext(Dispatchers.IO) {
        if (!configured) throw ApiError(Kind.NOT_CONFIGURED)
        try {
            val c = URL(base + path).openConnection() as HttpURLConnection
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = 15000
            c.setRequestProperty("apikey", key)
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Content-Type", "application/json")
            if (single) c.setRequestProperty("Accept", "application/vnd.pgrst.object+json")
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            c.disconnect()
            Resp(code, text)
        } catch (e: IOException) {
            throw ApiError(Kind.NETWORK)
        }
    }
}
