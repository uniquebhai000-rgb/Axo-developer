package com.axo.hub.core

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import java.net.URLEncoder
import org.json.JSONObject

class AuthRepository(ctx: Context) {
    private val store = SessionStore(ctx.applicationContext)
    val configured get() = Api.configured

    private fun now() = System.currentTimeMillis() / 1000

    private fun saveFrom(j: JSONObject): StoredSession {
        val user = j.getJSONObject("user")
        val s = StoredSession(
            j.getString("access_token"), j.getString("refresh_token"),
            now() + j.optLong("expires_in", 3600),
            user.getString("id"), user.optString("email", "")
        )
        store.save(s)
        return s
    }

    /** Returns true when the server answered; never reveals whether the email already exists. */
    suspend fun signUp(email: String, password: String, name: String) {
        val body = JSONObject()
            .put("email", email.trim().lowercase())
            .put("password", password)
            .put("data", JSONObject().put("display_name", name))
        val r = Api.call("POST", "/auth/v1/signup", body)
        when {
            r.code == 429 -> throw ApiError(Kind.RATE)
            r.code == 422 && r.errorCode == "weak_password" -> throw ApiError(Kind.INVALID)
            r.code !in 200..299 -> throw ApiError(Kind.OTHER, "${r.code} ${r.errorCode}".trim())
        }
        // Even if the server returned a session (email confirmation disabled) we do NOT keep it.
    }

    suspend fun signIn(email: String, password: String): UserInfo {
        val body = JSONObject().put("email", email.trim().lowercase()).put("password", password)
        val r = Api.call("POST", "/auth/v1/token?grant_type=password", body)
        when {
            r.code == 429 -> throw ApiError(Kind.RATE)
            r.code == 400 && r.errorCode == "email_not_confirmed" -> throw ApiError(Kind.UNVERIFIED)
            r.code in 400..499 -> throw ApiError(Kind.INVALID)
            r.code !in 200..299 -> throw ApiError(Kind.OTHER, "${r.code} ${r.errorCode}".trim())
        }
        saveFrom(r.json())
        return try { loadUser() } catch (e: Exception) { store.clear(); throw e }
    }

    suspend fun restore(): UserInfo? {
        if (store.load() == null) return null
        return try { loadUser() } catch (e: ApiError) {
            if (e.kind == Kind.NETWORK) throw e
            store.clear(); null
        }
    }

    suspend fun recover(email: String) {
        val r = Api.call("POST", "/auth/v1/recover", JSONObject().put("email", email.trim().lowercase()))
        if (r.code == 429) throw ApiError(Kind.RATE)
        // Any other result is treated as success so the UI cannot be used to probe accounts.
    }

    suspend fun signOut() {
        val s = store.load()
        store.clear()
        if (s != null) try { Api.call("POST", "/auth/v1/logout", token = s.access) } catch (e: Exception) { /* ignore: local session already cleared */ }
    }

    suspend fun updateProfile(name: String, bio: String): UserInfo {
        val body = JSONObject().put("p_display_name", name).put("p_bio", bio)
        val r = authed("POST", "/rest/v1/rpc/update_my_profile", body)
        if (r.code !in 200..299) throw ApiError(Kind.OTHER)
        return loadUser()
    }

    private val refreshLock = Mutex()

    private suspend fun freshToken(): String = refreshLock.withLock {
        val s = store.load() ?: throw ApiError(Kind.INVALID)
        if (s.expiresAt - 60 > now()) return@withLock s.access
        val r = Api.call("POST", "/auth/v1/token?grant_type=refresh_token",
            JSONObject().put("refresh_token", s.refresh))
        if (r.code !in 200..299) {
            if (r.code in 400..499) { store.clear(); throw ApiError(Kind.INVALID) }
            throw ApiError(Kind.OTHER)
        }
        saveFrom(r.json()).access
    }

    /** Authenticated REST call (user token, RLS applies). */
    suspend fun rest(method: String, path: String, body: JSONObject? = null, single: Boolean = false,
                     logoutOn401: Boolean = true): Resp =
        authed(method, path, body, single, logoutOn401)

    /** Short-lived signed URL (path + token) for a private storage object. */
    suspend fun storageSign(bucket: String, path: String): String? {
        val enc = path.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        val r = authed("POST", "/storage/v1/object/sign/$bucket/$enc", JSONObject().put("expiresIn", 300))
        if (r.code !in 200..299) return null
        val u = r.json().optString("signedURL", "")
        return when {
            u.isEmpty() -> null
            u.startsWith("/storage/v1") -> u
            u.startsWith("/") -> "/storage/v1$u"
            else -> null
        }
    }

    private suspend fun authed(method: String, path: String, body: JSONObject? = null, single: Boolean = false,
                               logoutOn401: Boolean = true): Resp {
        val r = Api.call(method, path, body, freshToken(), single)
        if (r.code == 401) { if (logoutOn401) store.clear(); throw ApiError(Kind.INVALID) }
        return r
    }

    private suspend fun loadUser(): UserInfo {
        val s = store.load() ?: throw ApiError(Kind.INVALID)
        val id = s.userId
        val p = authed("GET", "/rest/v1/profiles?select=account_code,display_name,bio&id=eq.$id", single = true)
        if (p.code != 200) throw ApiError(Kind.OTHER)
        val pj = p.json()
        val rr = authed("GET", "/rest/v1/user_roles?select=role&user_id=eq.$id&revoked_at=is.null")
        val roles = mutableSetOf<String>()
        if (rr.code == 200) {
            val arr = try { JSONArray(rr.body) } catch (e: Exception) { JSONArray() }
            for (i in 0 until arr.length()) roles += arr.getJSONObject(i).optString("role")
        }
        if (roles.isEmpty()) roles += "CUSTOMER"
        return UserInfo(id, s.email, pj.optString("account_code"), pj.optString("display_name"),
            pj.optString("bio"), roles)
    }
}
