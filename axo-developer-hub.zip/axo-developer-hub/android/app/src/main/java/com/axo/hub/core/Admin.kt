package com.axo.hub.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class AdminProject(
    val id: String, val title: String, val description: String,
    val price: Double, val status: String, val categoryId: String
)
data class AdminFile(val id: String, val name: String, val size: Long)
data class AdminAccess(
    val id: String, val email: String, val name: String,
    val status: String, val expires: String, val granted: String
)
data class UserHit(val id: String, val email: String, val name: String, val code: String)

/** Owner-only operations. Every call is checked again on the server (RLS + require_admin()). */
class AdminRepository(private val auth: AuthRepository) {

    private fun errMsg(r: Resp): String {
        val j = r.json()
        return j.optString("message").ifBlank { j.optString("msg") }.ifBlank { "HTTP ${r.code}" }
    }

    private suspend fun rpc(name: String, args: JSONObject): Resp {
        val r = auth.rest("POST", "/rest/v1/rpc/$name", args)
        if (r.code !in 200..299) throw ApiError(Kind.OTHER, errMsg(r))
        return r
    }

    private suspend fun get(path: String): JSONArray {
        val r = auth.rest("GET", path)
        if (r.code !in 200..299) throw ApiError(Kind.OTHER, errMsg(r))
        return JSONArray(r.body)
    }

    suspend fun projects(): List<AdminProject> {
        val a = get("/rest/v1/projects?select=id,title,description,price_inr,status,category_id&deleted_at=is.null&order=created_at.desc")
        return List(a.length()) {
            val o = a.getJSONObject(it)
            AdminProject(o.getString("id"), o.str("title"), o.str("description"),
                o.optDouble("price_inr", 0.0), o.str("status"), o.str("category_id"))
        }
    }

    suspend fun createProject(title: String, desc: String, price: Double, categoryId: String, publish: Boolean) {
        rpc("admin_create_project", JSONObject().put("p_title", title).put("p_description", desc)
            .put("p_price", price).put("p_category_id", categoryId).put("p_publish", publish))
    }

    suspend fun updateProject(id: String, title: String?, desc: String?, price: Double?, status: String?) {
        val j = JSONObject().put("p_id", id)
        if (title != null) j.put("p_title", title)
        if (desc != null) j.put("p_description", desc)
        if (price != null) j.put("p_price", price)
        if (status != null) j.put("p_status", status)
        rpc("admin_update_project", j)
    }

    suspend fun files(projectId: String): List<AdminFile> {
        val a = get("/rest/v1/project_files?project_id=eq.$projectId&deleted_at=is.null&select=id,file_name,size_bytes&order=created_at.desc")
        return List(a.length()) {
            val o = a.getJSONObject(it)
            AdminFile(o.getString("id"), o.str("file_name"), o.optLong("size_bytes"))
        }
    }

    suspend fun deleteFile(fileId: String) { rpc("admin_delete_file", JSONObject().put("p_file", fileId)) }

    suspend fun access(projectId: String): List<AdminAccess> {
        val a = JSONArray(rpc("admin_list_access", JSONObject().put("p_project", projectId)).body)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            AdminAccess(o.str("access_id"), o.str("email"), o.str("display_name"), o.str("status"),
                o.str("expires_at").take(10), o.str("granted_at").take(10))
        }
    }

    suspend fun findUsers(q: String): List<UserHit> {
        val a = JSONArray(rpc("admin_find_user", JSONObject().put("p_query", q)).body)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            UserHit(o.str("user_id"), o.str("email"), o.str("display_name"), o.str("account_code"))
        }
    }

    suspend fun unlock(userId: String, projectId: String, days: Int?) {
        val j = JSONObject().put("p_user", userId).put("p_project", projectId)
        if (days != null) j.put("p_days", days)
        rpc("admin_unlock_user", j)
    }

    suspend fun revoke(accessId: String) {
        rpc("revoke_access", JSONObject().put("p_access_id", accessId).put("p_reason", "Locked by owner"))
    }

    private fun describe(ctx: Context, uri: Uri): Pair<String, Long> {
        var name = "file"
        var size = -1L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0 && !c.isNull(n)) name = c.getString(n)
                if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
            }
        }
        return name to size
    }

    private fun imageMime(name: String): String {
        val n = name.lowercase()
        return when {
            n.endsWith(".png") -> "image/png"
            n.endsWith(".jpg") || n.endsWith(".jpeg") -> "image/jpeg"
            n.endsWith(".webp") -> "image/webp"
            else -> throw ApiError(Kind.OTHER, "Pick a JPG, PNG or WEBP image.")
        }
    }

    /** Uploads to the private bucket, then registers it. Originals never get a public URL. */
    suspend fun upload(ctx: Context, uri: Uri, projectId: String, preview: Boolean) {
        val (name, size) = describe(ctx, uri)
        if (size <= 0) throw ApiError(Kind.OTHER, "Couldn't read that file.")
        val limit = if (preview) 10L * 1024 * 1024 else 50L * 1024 * 1024
        if (size > limit) throw ApiError(Kind.OTHER, "File is too big (max ${limit / 1024 / 1024} MB).")
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "file" }
        val path = "$projectId/${UUID.randomUUID()}-$safe"
        val mime = if (preview) imageMime(safe) else "application/octet-stream"
        auth.uploadObject(if (preview) "previews" else "originals", path, mime, size) {
            ctx.contentResolver.openInputStream(uri) ?: throw ApiError(Kind.OTHER, "Couldn't open that file.")
        }
        if (preview) rpc("admin_add_preview", JSONObject().put("p_project", projectId).put("p_path", path).put("p_make_cover", true))
        else rpc("admin_register_file", JSONObject().put("p_project", projectId).put("p_path", path).put("p_file_name", name.take(200)))
    }
}
