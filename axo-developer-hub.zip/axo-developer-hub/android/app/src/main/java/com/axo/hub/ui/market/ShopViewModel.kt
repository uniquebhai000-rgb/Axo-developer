package com.axo.hub.ui.market

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.axo.hub.core.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class ShopViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ShopRepository(ServiceLocator.auth(app))

    val settings = MutableStateFlow<Load<PaymentSettings>>(Load.Loading)
    val payments = MutableStateFlow<Load<List<MyPayment>>>(Load.Loading)
    val notices = MutableStateFlow<Load<List<Notice>>>(Load.Loading)
    val tickets = MutableStateFlow<Load<List<SupportTicket>>>(Load.Loading)
    val thread = MutableStateFlow<Load<List<SupportMsg>>>(Load.Loading)
    val busy = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)
    val submitted = MutableStateFlow(false)

    private fun msg(e: Throwable): String = when {
        e is ApiError && e.detail.isNotBlank() -> e.detail
        e is ApiError && e.kind == Kind.NETWORK -> "Can't reach the server."
        else -> "Something went wrong."
    }

    private suspend fun <T> load(flow: MutableStateFlow<Load<T>>, block: suspend () -> T) {
        flow.value = try { Load.Ready(block()) } catch (e: Exception) { Load.Error(msg(e)) }
    }

    private fun act(ok: String?, block: suspend () -> Unit, after: suspend () -> Unit = {}) {
        viewModelScope.launch {
            busy.value = true
            try {
                block()
                if (ok != null) message.value = ok
                after()
            } catch (e: Exception) {
                message.value = msg(e)
            } finally {
                busy.value = false
            }
        }
    }

    fun loadSettings() { viewModelScope.launch { load(settings) { repo.paymentSettings() } } }
    fun loadPayments() { viewModelScope.launch { load(payments) { repo.myPayments() } } }
    fun loadNotices() { viewModelScope.launch { load(notices) { repo.notices() } } }
    fun loadTickets(admin: Boolean) {
        viewModelScope.launch { load(tickets) { if (admin) repo.allTickets() else repo.myTickets() } }
    }
    fun loadThread(id: String) { viewModelScope.launch { thread.value = Load.Loading; load(thread) { repo.messages(id) } } }

    fun markAllRead() { act(null, { repo.markRead() }, { load(notices) { repo.notices() } }) }

    fun submitPayment(userId: String, projectId: String, ref: String, date: String, proof: Uri?, note: String) {
        submitted.value = false
        act("Payment request sent. We'll verify it soon.",
            { repo.submitPayment(getApplication<Application>(), userId, projectId, ref, date, proof, note) },
            { submitted.value = true; load(payments) { repo.myPayments() } })
    }

    fun createTicket(category: String, subject: String, body: String, admin: Boolean) =
        act("Ticket created", { repo.createTicket(category, subject, body) }, { load(tickets) { if (admin) repo.allTickets() else repo.myTickets() } })

    fun reply(ticketId: String, body: String, admin: Boolean) =
        act(null, { repo.reply(ticketId, body) }, { load(thread) { repo.messages(ticketId) }; load(tickets) { if (admin) repo.allTickets() else repo.myTickets() } })

    fun close(ticketId: String, admin: Boolean, onDone: () -> Unit) =
        act("Ticket closed", { repo.close(ticketId) }, { load(tickets) { if (admin) repo.allTickets() else repo.myTickets() }; onDone() })
}
