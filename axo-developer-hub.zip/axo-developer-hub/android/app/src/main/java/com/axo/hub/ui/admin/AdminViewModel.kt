package com.axo.hub.ui.admin

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.axo.hub.core.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class AdminViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = AdminRepository(ServiceLocator.auth(app))

    val projects = MutableStateFlow<Load<List<AdminProject>>>(Load.Loading)
    val files = MutableStateFlow<Load<List<AdminFile>>>(Load.Loading)
    val access = MutableStateFlow<Load<List<AdminAccess>>>(Load.Loading)
    val hits = MutableStateFlow<List<UserHit>>(emptyList())
    val busy = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)

    private fun msg(e: Throwable): String = when {
        e is ApiError && e.detail.isNotBlank() -> e.detail
        e is ApiError && e.kind == Kind.NETWORK -> "Can't reach the server."
        else -> "Something went wrong."
    }

    private suspend fun <T> load(flow: MutableStateFlow<Load<T>>, block: suspend () -> T) {
        flow.value = try { Load.Ready(block()) } catch (e: Exception) { Load.Error(msg(e)) }
    }

    private fun act(okMessage: String?, block: suspend () -> Unit, after: suspend () -> Unit = {}) {
        viewModelScope.launch {
            busy.value = true
            try {
                block()
                if (okMessage != null) message.value = okMessage
                after()
            } catch (e: Exception) {
                message.value = msg(e)
            } finally {
                busy.value = false
            }
        }
    }

    fun loadProjects() { viewModelScope.launch { load(projects) { repo.projects() } } }
    fun loadFiles(pid: String) { viewModelScope.launch { load(files) { repo.files(pid) } } }
    fun loadAccess(pid: String) { viewModelScope.launch { load(access) { repo.access(pid) } } }

    fun createProject(title: String, desc: String, price: Double, categoryId: String, publish: Boolean) =
        act("Project created", { repo.createProject(title, desc, price, categoryId, publish) }, { load(projects) { repo.projects() } })

    fun updateProject(id: String, title: String, desc: String, price: Double, status: String) =
        act("Saved", { repo.updateProject(id, title, desc, price, status) }, { load(projects) { repo.projects() } })

    fun upload(uri: Uri, pid: String, preview: Boolean) =
        act(if (preview) "Image added" else "File uploaded",
            { repo.upload(getApplication<Application>(), uri, pid, preview) },
            { load(files) { repo.files(pid) } })

    fun deleteFile(fileId: String, pid: String) =
        act("File removed", { repo.deleteFile(fileId) }, { load(files) { repo.files(pid) } })

    fun search(q: String) {
        viewModelScope.launch {
            try { hits.value = repo.findUsers(q) } catch (e: Exception) { message.value = msg(e) }
        }
    }

    fun unlock(userId: String, pid: String, days: Int?) =
        act("Unlocked", { repo.unlock(userId, pid, days) }, { load(access) { repo.access(pid) } })

    fun lock(accessId: String, pid: String) =
        act("Locked again", { repo.revoke(accessId) }, { load(access) { repo.access(pid) } })
}
