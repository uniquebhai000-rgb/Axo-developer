package com.axo.hub.ui.auth

import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.axo.hub.core.Validators
import com.axo.hub.ui.components.*
import com.axo.hub.ui.theme.Axo

@Composable
fun AuthScreen(vm: AuthViewModel) {
    // Screenshots / recents thumbnails are blocked on sign-in screens.
    val activity = LocalContext.current as ComponentActivity
    DisposableEffect(Unit) {
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    val ui by vm.ui.collectAsState()
    var email by rememberSaveable { mutableStateOf("") }

    AxoBackground {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))
            AxoLogo(76.dp)
            Spacer(Modifier.height(14.dp))
            Text("AXO DEVELOPER HUB", style = MaterialTheme.typography.titleLarge)
            Text("Create. Showcase. Protect. Sell.", color = Axo.Mist,
                style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(26.dp))
            GlassCard(Modifier.fillMaxWidth(), animatedBorder = true) {
                when (ui.mode) {
                    AuthMode.SIGN_IN, AuthMode.SIGN_UP -> Forms(vm, ui, email) { email = it }
                    AuthMode.FORGOT -> Forgot(vm, ui, email) { email = it }
                    AuthMode.CHECK_INBOX -> Notice(Icons.Filled.MarkEmailRead, "Check your inbox",
                        "If this email can be used, we sent a verification link. Open it, then sign in.") {
                        vm.setMode(AuthMode.SIGN_IN) }
                    AuthMode.RESET_SENT -> Notice(Icons.Filled.MarkEmailRead, "Reset link sent",
                        "If an account exists for that email, a reset link is on its way.") {
                        vm.setMode(AuthMode.SIGN_IN) }
                }
            }
            if (!vm.configured) {
                Spacer(Modifier.height(14.dp))
                Text("Backend not configured yet. See docs/PHASE2_SETUP.md.",
                    color = Axo.Danger, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun ColumnScope.Forms(vm: AuthViewModel, ui: AuthUi, email: String, setEmail: (String) -> Unit) {
    val signUp = ui.mode == AuthMode.SIGN_UP
    var name by rememberSaveable { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var agreed by remember { mutableStateOf(false) }

    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Axo.Ink).padding(4.dp)) {
        Segment("Sign in", !signUp, Modifier.weight(1f)) { vm.setMode(AuthMode.SIGN_IN) }
        Segment("Create account", signUp, Modifier.weight(1f)) { vm.setMode(AuthMode.SIGN_UP) }
    }
    Spacer(Modifier.height(18.dp))

    if (signUp) {
        Field(name, { name = it }, "Display name", Icons.Filled.Person)
        Spacer(Modifier.height(12.dp))
    }
    Field(email, setEmail, "Email", Icons.Filled.Email, keyboard = KeyboardType.Email)
    Spacer(Modifier.height(12.dp))
    Field(pw, { pw = it }, "Password", Icons.Filled.Lock, keyboard = KeyboardType.Password,
        secret = !show, trailing = {
            IconButton({ show = !show }) {
                Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                    if (show) "Hide password" else "Show password", tint = Axo.Mist)
            }
        })
    if (signUp) {
        Spacer(Modifier.height(10.dp))
        StrengthBar(Validators.passwordScore(pw))
        Text("8+ characters, upper and lower case, one number.", color = Axo.Mist,
            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(12.dp))
        Field(pw2, { pw2 = it }, "Confirm password", Icons.Filled.Lock, keyboard = KeyboardType.Password, secret = !show)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().clickable { agreed = !agreed }, verticalAlignment = Alignment.CenterVertically) {
            Checkbox(agreed, { agreed = it }, colors = CheckboxDefaults.colors(checkedColor = Axo.Violet))
            Text("I agree to the Terms and Privacy Policy", style = MaterialTheme.typography.bodyMedium)
        }
    }
    ui.error?.let {
        Spacer(Modifier.height(10.dp))
        Text(it, color = Axo.Danger, style = MaterialTheme.typography.bodyMedium)
    }
    Spacer(Modifier.height(16.dp))
    GradientButton(if (signUp) "Create account" else "Sign in", loading = ui.loading, onClick = {
        if (signUp) vm.signUp(email, pw, pw2, name, agreed) else vm.signIn(email, pw)
    })
    if (!signUp) {
        TextButton({ vm.setMode(AuthMode.FORGOT) }, Modifier.align(Alignment.CenterHorizontally)) {
            Text("Forgot password?", color = Axo.Orchid)
        }
    }
}

@Composable
private fun ColumnScope.Forgot(vm: AuthViewModel, ui: AuthUi, email: String, setEmail: (String) -> Unit) {
    Text("Reset password", style = MaterialTheme.typography.titleLarge)
    Text("Enter your email and we'll send a reset link.", color = Axo.Mist,
        style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 8.dp))
    Field(email, setEmail, "Email", Icons.Filled.Email, keyboard = KeyboardType.Email)
    ui.error?.let { Text(it, color = Axo.Danger, modifier = Modifier.padding(top = 10.dp)) }
    Spacer(Modifier.height(16.dp))
    GradientButton("Send reset link", loading = ui.loading, onClick = { vm.forgot(email) })
    TextButton({ vm.setMode(AuthMode.SIGN_IN) }, Modifier.align(Alignment.CenterHorizontally)) {
        Text("Back to sign in", color = Axo.Orchid)
    }
}

@Composable
private fun Notice(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, body: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Axo.Orchid, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Text(body, color = Axo.Mist, textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 10.dp))
        GradientButton("Back to sign in", onClick = onBack)
    }
}

@Composable
private fun Segment(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(11.dp))
            .background(if (selected) Axo.Gradient else androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color0, Color0)))
            .clickable(onClick = onClick).padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge,
            color = if (selected) androidx.compose.ui.graphics.Color.White else Axo.Mist)
    }
}
private val Color0 = androidx.compose.ui.graphics.Color.Transparent

@Composable
private fun Field(
    value: String, onChange: (String) -> Unit, label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    keyboard: KeyboardType = KeyboardType.Text, secret: Boolean = false,
    trailing: (@Composable () -> Unit)? = null
) {
    OutlinedTextField(
        value, onChange, Modifier.fillMaxWidth(), label = { Text(label) },
        leadingIcon = { Icon(icon, null, tint = Axo.Mist) }, trailingIcon = trailing,
        singleLine = true, shape = RoundedCornerShape(14.dp), colors = axoFieldColors(),
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None
    )
}
