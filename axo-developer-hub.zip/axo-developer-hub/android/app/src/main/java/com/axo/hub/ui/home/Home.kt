package com.axo.hub.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.axo.hub.core.UserInfo
import com.axo.hub.ui.components.*
import com.axo.hub.ui.theme.Axo

private data class Cat(val name: String, val sub: String, val icon: ImageVector)
private val categories = listOf(
    Cat("Minecraft Packs", "Textures, shaders, mods", Icons.Filled.GridView),
    Cat("Minecraft Skins", "PvP, HD, bundles", Icons.Filled.Face),
    Cat("Discord", "Templates and bots", Icons.Filled.Forum),
    Cat("Apps & Websites", "Source and UI designs", Icons.Filled.Code),
    Cat("Graphic Design", "Logos, banners, wallpapers", Icons.Filled.Brush),
    Cat("Other Projects", "Tools and custom work", Icons.Filled.AutoAwesome)
)

@Composable
fun HomeScreen(user: UserInfo, onSignOut: () -> Unit, onUpdateProfile: (String, String, (String?) -> Unit) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = buildList {
        add("Home" to Icons.Filled.Home); add("Explore" to Icons.Filled.Search); add("Library" to Icons.Filled.Lock)
        if (user.canUseStudio) add("Studio" to Icons.Filled.Code)
        add("Profile" to Icons.Filled.Person)
    }
    val label = tabs[tab.coerceAtMost(tabs.lastIndex)].first

    AxoBackground {
        Scaffold(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Axo.Ink.copy(alpha = 0.94f)) {
                    tabs.forEachIndexed { i, (l, ic) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(ic, l) }, label = { Text(l) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = androidx.compose.ui.graphics.Color.White,
                                indicatorColor = Axo.Electric, unselectedIconColor = Axo.Mist,
                                selectedTextColor = Axo.Orchid, unselectedTextColor = Axo.Mist))
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (label) {
                    "Home" -> HomeTab(user)
                    "Explore" -> Empty(Icons.Filled.Search, "Explore opens soon", "Search and filters arrive with the marketplace in Phase 4.")
                    "Library" -> Empty(Icons.Filled.Lock, "Your library is empty", "Projects you unlock will appear here.")
                    "Studio" -> Empty(Icons.Filled.Code, "Developer Studio", "Listing tools arrive in Phase 7.")
                    else -> ProfileTab(user, onSignOut, onUpdateProfile)
                }
            }
        }
    }
}

@Composable
private fun HomeTab(user: UserInfo) {
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AxoLogo(40.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Welcome back", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                Text(user.displayName.ifBlank { "Creator" }, style = MaterialTheme.typography.titleLarge)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Browse by category", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        categories.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { c ->
                    GlassCard(Modifier.weight(1f)) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Axo.Gradient),
                            contentAlignment = Alignment.Center) {
                            Icon(c.icon, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(c.name, style = MaterialTheme.typography.titleMedium)
                        Text(c.sub, color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun Empty(icon: ImageVector, title: String, body: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Axo.Orchid, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(14.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Text(body, color = Axo.Mist, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun ProfileTab(user: UserInfo, onSignOut: () -> Unit, onUpdate: (String, String, (String?) -> Unit) -> Unit) {
    var editing by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Profile", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth(), animatedBorder = true) {
            Text(user.displayName.ifBlank { "Creator" }, style = MaterialTheme.typography.titleLarge)
            Text(user.email, color = Axo.Mist)
            if (user.bio.isNotBlank()) Text(user.bio, modifier = Modifier.padding(top = 10.dp))
            Spacer(Modifier.height(14.dp))
            Text("Account ID", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
            Text(user.accountCode, color = Axo.Orchid, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                user.roles.forEach {
                    AssistChip(onClick = {}, label = { Text(it.replace('_', ' ')) },
                        colors = AssistChipDefaults.assistChipColors(labelColor = Axo.Orchid))
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton({ editing = true }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit profile")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton({ confirm = true }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.AutoMirrored.Filled.Logout, null); Spacer(Modifier.width(8.dp)); Text("Sign out")
        }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = Axo.Panel,
        title = { Text("Sign out?") }, text = { Text("You'll need to sign in again to access your library.") },
        confirmButton = { TextButton({ confirm = false; onSignOut() }) { Text("Sign out", color = Axo.Danger) } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } })

    if (editing) {
        var n by remember { mutableStateOf(user.displayName) }
        var b by remember { mutableStateOf(user.bio) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { editing = false }, containerColor = Axo.Panel,
            title = { Text("Edit profile") },
            text = {
                Column {
                    OutlinedTextField(n, { n = it.take(40) }, label = { Text("Display name") }, singleLine = true,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(b, { b = it.take(300) }, label = { Text("Bio") }, minLines = 3,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    err?.let { Text(it, color = Axo.Danger, modifier = Modifier.padding(top = 8.dp)) }
                }
            },
            confirmButton = { TextButton({ onUpdate(n, b) { e -> if (e == null) editing = false else err = e } }) { Text("Save") } },
            dismissButton = { TextButton({ editing = false }) { Text("Cancel") } })
    }
}
