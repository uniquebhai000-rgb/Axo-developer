package com.axo.hub.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.axo.hub.core.UserInfo
import androidx.lifecycle.viewmodel.compose.viewModel
import com.axo.hub.ui.components.*
import com.axo.hub.ui.admin.*
import com.axo.hub.ui.market.*
import com.axo.hub.ui.theme.Axo

@Composable
fun HomeScreen(user: UserInfo, onSignOut: () -> Unit, onUpdateProfile: (String, String, (String?) -> Unit) -> Unit) {
    val mv: MarketViewModel = viewModel()
    val av: AdminViewModel = viewModel()
    val shop: ShopViewModel = viewModel()
    var payFor by remember { mutableStateOf<com.axo.hub.core.ProjectCard?>(null) }
    var notifOpen by remember { mutableStateOf(false) }
    var supportMode by remember { mutableStateOf<String?>(null) }
    var adminProject by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var detailId by remember { mutableStateOf<String?>(null) }
    var previewing by remember { mutableStateOf(false) }
    val tabs = buildList {
        add("Home" to Icons.Filled.Home); add("Explore" to Icons.Filled.Search); add("Library" to Icons.Filled.Lock)
        if (user.isAdmin) add("Admin" to Icons.Filled.AdminPanelSettings)
        else if (user.canUseStudio) add("Studio" to Icons.Filled.Code)
        add("Profile" to Icons.Filled.Person)
    }
    val label = tabs[tab.coerceAtMost(tabs.lastIndex)].first

    BackHandler(enabled = detailId != null || adminProject != null || payFor != null || notifOpen || supportMode != null) {
        if (payFor != null) payFor = null
        else if (notifOpen) notifOpen = false
        else if (supportMode != null) supportMode = null
        else if (adminProject != null) adminProject = null
        else if (previewing) previewing = false else detailId = null
    }
    val notices by shop.notices.collectAsState()
    val unread = (notices as? com.axo.hub.core.Load.Ready<List<com.axo.hub.core.Notice>>)?.data?.count { !it.read } ?: 0
    LaunchedEffect(label) { if (label == "Home") { mv.refreshHome(); shop.loadNotices() } }

    AxoBackground {
        val open = detailId
        val adminOpen = adminProject
        val pay = payFor
        val sup = supportMode
        if (pay != null) {
            PaymentScreen(shop, mv, pay, user.id) { payFor = null; mv.refreshHome() }
        } else if (notifOpen) {
            NotificationsScreen(shop) { notifOpen = false; shop.loadNotices() }
        } else if (sup != null) {
            SupportScreen(shop, sup == "admin") { supportMode = null }
        } else if (adminOpen != null && user.isAdmin) {
            AdminProjectScreen(av, adminOpen) { adminProject = null }
        } else if (open != null) {
            if (previewing) PreviewScreen(mv, user.accountCode) { previewing = false }
            else DetailScreen(mv, shop, open, user.accountCode, { detailId = null }, { previewing = true }, { payFor = it })
        } else Scaffold(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Axo.Ink.copy(alpha = 0.94f)) {
                    tabs.forEachIndexed { i, (l, ic) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(ic, l) }, label = { Text(l) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = androidx.compose.ui.graphics.Color.White,
                                indicatorColor = Axo.Electric, unselectedIconColor = Axo.Mist,
                                selectedTextColor = Axo.Orchid, unselectedTextColor = Axo.Mist))
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (label) {
                    "Home" -> HomeTab(mv, user.displayName,
                        onOpen = { detailId = it },
                        onCategory = { id -> mv.filters.value = com.axo.hub.core.Filters(categoryId = id); tab = 1 },
                        onSearch = { tab = 1 }, unread = unread, onBell = { notifOpen = true })
                    "Explore" -> ExploreTab(mv) { detailId = it }
                    "Library" -> LibraryTab(mv, shop) { detailId = it }
                    "Admin" -> AdminTab(av, mv, { adminProject = it }, { supportMode = "admin" })
                    "Studio" -> Empty(Icons.Filled.Code, "Developer Studio", "Listing tools arrive in Phase 7.")
                    else -> ProfileTab(user, onSignOut, onUpdateProfile) { supportMode = "user" }
                }
            }
        }
    }
}

@Composable
private fun Empty(icon: ImageVector, title: String, body: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Axo.Orchid, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(14.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Text(body, color = Axo.Mist, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun ProfileTab(user: UserInfo, onSignOut: () -> Unit, onUpdate: (String, String, (String?) -> Unit) -> Unit, onSupport: () -> Unit) {
    var editing by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Profile", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth(), animatedBorder = true) {
            Text(user.displayName.ifBlank { "Creator" }, style = MaterialTheme.typography.titleLarge)
            Text(user.email, color = Axo.Mist)
            if (user.bio.isNotBlank()) Text(user.bio, modifier = Modifier.padding(top = 10.dp))
            Spacer(Modifier.height(14.dp))
            Text("Account ID", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
            Text(user.accountCode, color = Axo.Orchid, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                user.roles.forEach {
                    AssistChip(onClick = {}, label = { Text(it.replace('_', ' ')) },
                        colors = AssistChipDefaults.assistChipColors(labelColor = Axo.Orchid))
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton({ editing = true }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(8.dp)); Text("Edit profile")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onSupport, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Filled.SupportAgent, null); Spacer(Modifier.width(8.dp)); Text("Help & support")
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton({ info = "about" }) { Text("About", color = Axo.Mist) }
            TextButton({ info = "privacy" }) { Text("Privacy", color = Axo.Mist) }
            TextButton({ info = "terms" }) { Text("Terms", color = Axo.Mist) }
        }
        Spacer(Modifier.height(4.dp))
        OutlinedButton({ confirm = true }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.AutoMirrored.Filled.Logout, null); Spacer(Modifier.width(8.dp)); Text("Sign out")
        }
    }

    info?.let { k ->
        val (title, body) = when (k) {
            "privacy" -> "Privacy policy" to ("We store your email, display name, payment references and the screenshots you choose to upload, " +
                "so the owner can verify payments and give you access. Files are kept in private storage and are never public. " +
                "We never ask for UPI PINs, card details or passwords, and we don't sell your data. " +
                "Contact support to ask for your data to be deleted.")
            "terms" -> "Terms and conditions" to ("Projects are digital products. Access is given only after the owner verifies your payment. " +
                "Files are for your own use; sharing, reselling or leaking them can lead to your access being removed. " +
                "Refunds are decided by the owner. Preview protection reduces copying but cannot stop every capture method.")
            else -> "About" to ("AXO DEVELOPER HUB\nCreate. Showcase. Protect. Sell.\n\nVersion ${com.axo.hub.BuildConfig.VERSION_NAME}")
        }
        AlertDialog(
            onDismissRequest = { info = null }, containerColor = Axo.Panel,
            title = { Text(title) }, text = { Text(body) },
            confirmButton = { TextButton({ info = null }) { Text("OK") } })
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = Axo.Panel,
        title = { Text("Sign out?") }, text = { Text("You'll need to sign in again to access your library.") },
        confirmButton = { TextButton({ confirm = false; onSignOut() }) { Text("Sign out", color = Axo.Danger) } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } })

    if (editing) {
        var n by remember { mutableStateOf(user.displayName) }
        var b by remember { mutableStateOf(user.bio) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { editing = false }, containerColor = Axo.Panel,
            title = { Text("Edit profile") },
            text = {
                Column {
                    OutlinedTextField(n, { n = it.take(40) }, label = { Text("Display name") }, singleLine = true,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(b, { b = it.take(300) }, label = { Text("Bio") }, minLines = 3,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    err?.let { Text(it, color = Axo.Danger, modifier = Modifier.padding(top = 8.dp)) }
                }
            },
            confirmButton = { TextButton({ onUpdate(n, b) { e -> if (e == null) editing = false else err = e } }) { Text("Save") } },
            dismissButton = { TextButton({ editing = false }) { Text("Cancel") } })
    }
}
