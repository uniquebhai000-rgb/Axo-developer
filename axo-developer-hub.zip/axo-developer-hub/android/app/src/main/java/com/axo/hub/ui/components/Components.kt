package com.axo.hub.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axo.hub.ui.theme.Axo
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AxoBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Axo.Void).drawBehind {
            drawRect(Brush.radialGradient(
                listOf(Axo.Electric.copy(alpha = 0.38f), Color.Transparent),
                center = Offset(size.width * 0.9f, -size.height * 0.02f), radius = size.width * 1.1f))
            drawRect(Brush.radialGradient(
                listOf(Axo.Magenta.copy(alpha = 0.16f), Color.Transparent),
                center = Offset(-size.width * 0.1f, size.height * 0.95f), radius = size.width))
        },
        content = content
    )
}

@Composable
fun rgbBrush(): Brush {
    val t by rememberInfiniteTransition(label = "rgb").animateFloat(
        0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "t")
    val w = 900f
    return Brush.linearGradient(
        listOf(Axo.Electric, Axo.Orchid, Axo.Magenta, Axo.Blue, Axo.Electric),
        start = Offset(w * t - w, 0f), end = Offset(w * t, w), tileMode = TileMode.Mirror)
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier, animatedBorder: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val border = if (animatedBorder) BorderStroke(1.5.dp, rgbBrush())
    else BorderStroke(1.dp, Axo.Line)
    Card(
        modifier = modifier, shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Axo.Panel.copy(alpha = 0.78f)),
        border = border
    ) { Column(Modifier.padding(20.dp), content = content) }
}

@Composable
fun GradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
                   enabled: Boolean = true, loading: Boolean = false) {
    Box(
        modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(16.dp))
            .background(if (enabled) Axo.Gradient else Brush.linearGradient(listOf(Axo.Line, Axo.Line)))
            .clickable(enabled = enabled && !loading, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (loading) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
        else Text(text, color = Color.White, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun AxoLogo(size: androidx.compose.ui.unit.Dp = 72.dp) {
    val brush = rgbBrush()
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f * 0.92f
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val path = Path()
            for (i in 0..5) {
                val a = (PI / 3.0 * i - PI / 2.0).toFloat()
                val p = Offset(c.x + r * cos(a), c.y + r * sin(a))
                if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
            }
            path.close()
            drawPath(path, Axo.Ink)
            drawPath(path, brush, style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round))
        }
        Text("A", color = Color.White, fontWeight = FontWeight.Black, fontSize = (size.value * 0.42f).sp)
    }
}

@Composable
fun StrengthBar(score: Int, modifier: Modifier = Modifier) {
    val color = when (score) { 0, 1 -> Axo.Danger; 2 -> Color(0xFFFBBF24); else -> Axo.Success }
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(4) { i ->
            Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp))
                .background(if (i < score) color else Axo.Line))
        }
    }
}

@Composable
fun axoFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Axo.Violet, unfocusedBorderColor = Axo.Line,
    focusedLabelColor = Axo.Orchid, unfocusedLabelColor = Axo.Mist,
    cursorColor = Axo.Orchid, focusedContainerColor = Axo.Ink, unfocusedContainerColor = Axo.Ink
)
