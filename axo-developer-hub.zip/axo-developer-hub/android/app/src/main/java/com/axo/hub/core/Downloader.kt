package com.axo.hub.core

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File

/** Hands a short-lived signed URL to the system DownloadManager. */
object Downloader {
    fun enqueue(ctx: Context, t: Ticket): String {
        val safe = t.name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(100).ifBlank { "download" }
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        fun request() = DownloadManager.Request(Uri.parse(t.url))
            .setTitle(safe)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)

        // 1st choice: public Downloads/AXO. 2nd: the app's own folder (always allowed).
        return try {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AXO")
            dir.mkdirs()
            dm.enqueue(request().setDestinationUri(Uri.fromFile(File(dir, safe))))
            "Download started: $safe (Downloads/AXO)"
        } catch (e: Exception) {
            try {
                dm.enqueue(request().setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, safe))
                "Download started: $safe"
            } catch (e2: Exception) {
                "Couldn't start the download."
            }
        }
    }
}
