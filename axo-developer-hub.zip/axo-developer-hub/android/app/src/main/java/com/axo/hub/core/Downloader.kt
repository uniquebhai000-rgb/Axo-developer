package com.axo.hub.core

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment

/** Hands a short-lived signed URL to the system DownloadManager. */
object Downloader {
    fun enqueue(ctx: Context, t: Ticket): String = try {
        val safe = t.name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(100).ifBlank { "download" }
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val req = DownloadManager.Request(Uri.parse(t.url))
            .setTitle(safe)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDirectory(Environment.DIRECTORY_DOWNLOADS, "AXO/$safe")
        dm.enqueue(req)
        "Download started: $safe"
    } catch (e: Exception) {
        "Couldn't start the download."
    }
}
