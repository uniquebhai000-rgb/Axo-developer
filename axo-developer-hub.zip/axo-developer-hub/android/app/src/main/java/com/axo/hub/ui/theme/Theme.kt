package com.axo.hub.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object Axo {
    val Void = Color(0xFF07060B)
    val Ink = Color(0xFF0E0C16)
    val Panel = Color(0xFF161226)
    val Line = Color(0xFF2B2447)
    val Electric = Color(0xFF7C3AED)
    val Violet = Color(0xFF8B5CF6)
    val Orchid = Color(0xFFC084FC)
    val Magenta = Color(0xFFD946EF)
    val Blue = Color(0xFF6366F1)
    val Mist = Color(0xFFB4ACCB)
    val Success = Color(0xFF34D399)
    val Danger = Color(0xFFF87171)
    val Gradient = Brush.linearGradient(listOf(Electric, Violet, Magenta))
}

private val Dark = darkColorScheme(
    primary = Axo.Violet, onPrimary = Color.White, secondary = Axo.Orchid,
    background = Axo.Void, onBackground = Color(0xFFF4F0FF),
    surface = Axo.Panel, onSurface = Color(0xFFF4F0FF), onSurfaceVariant = Axo.Mist,
    error = Axo.Danger, outline = Axo.Line
)
private val Light = lightColorScheme(primary = Axo.Electric, secondary = Axo.Magenta)

private val Type = Typography(
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold,
        fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.8).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp, letterSpacing = (-0.3).sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp, letterSpacing = 0.2.sp)
)

@Composable
fun AxoTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = Type, content = content)
}
