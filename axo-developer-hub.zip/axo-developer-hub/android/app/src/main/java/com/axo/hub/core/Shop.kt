package com.axo.hub.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class PaymentSettings(val upi: String, val qrPath: String?, val instructions: String, val support: String, val terms: String)
data class MyPayment(
    val id: String, val projectId: String, val title: String, val amount: Double,
    val status: String, val ref: String, val reason: String, val date: String
)
data class Notice(val id: String, val title: String, val body: String, val read: Boolean, val date: String)
data class SupportTicket(val id: String, val subject: String, val category: String, val status: String, val who: String, val date: String)
data class SupportMsg(val id: String, val body: String, val staff: Boolean, val date: String)

/** Customer-side payment, notification and support calls. All writes go through checked SQL functions. */
class ShopRepository(private val auth: AuthRepository) {

    private fun errMsg(r: Resp): String {
        val j = r.json()
        return j.optString("message").ifBlank { j.optString("msg") }.ifBlank { "HTTP ${r.code}" }
    }

    private suspend fun get(path: String, single: Boolean = false): Resp {
        val r = auth.rest("GET", path, null, single)
        if (r.code !in 200..299) throw ApiError(Kind.OTHER, errMsg(r))
        return r
    }

    private suspend fun rpc(name: String, args: JSONObject): Resp {
        val r = auth.rest("POST", "/rest/v1/rpc/$name", args)
        if (r.code !in 200..299) throw ApiError(Kind.OTHER, errMsg(r))
        return r
    }

    suspend fun paymentSettings(): PaymentSettings {
        val r = get("/rest/v1/payment_settings?id=eq.1&select=upi_id,qr_path,instructions,support_contact,terms", true)
        val o = r.json()
        return PaymentSettings(o.str("upi_id"), o.str("qr_path").ifBlank { null }, o.str("instructions"),
            o.str("support_contact"), o.str("terms"))
    }

    suspend fun myPayments(): List<MyPayment> {
        val a = JSONArray(get("/rest/v1/payment_requests?select=id,project_id,amount,status,transaction_ref," +
            "rejection_reason,payment_date,projects(title)&order=created_at.desc&limit=50").body)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            MyPayment(o.str("id"), o.str("project_id"), o.optJSONObject("projects")?.str("title") ?: "",
                o.optDouble("amount", 0.0), o.str("status"), o.str("transaction_ref"),
                o.str("rejection_reason"), o.str("payment_date"))
        }
    }

    private fun describe(ctx: Context, uri: Uri): Pair<String, Long> {
        var name = "proof"
        var size = -1L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0 && !c.isNull(n)) name = c.getString(n)
                if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
            }
        }
        return name to size
    }

    /** Uploads the optional screenshot to the user's private folder, then files the request. Price comes from the server. */
    suspend fun submitPayment(ctx: Context, userId: String, projectId: String, ref: String, date: String,
                              proof: Uri?, message: String) {
        var path: String? = null
        if (proof != null) {
            val (name, size) = describe(ctx, proof)
            if (size <= 0 || size > 5L * 1024 * 1024) throw ApiError(Kind.OTHER, "Screenshot must be under 5 MB.")
            val low = name.lowercase()
            val mime = when {
                low.endsWith(".png") -> "image/png"
                low.endsWith(".jpg") || low.endsWith(".jpeg") -> "image/jpeg"
                low.endsWith(".webp") -> "image/webp"
                else -> throw ApiError(Kind.OTHER, "Screenshot must be JPG, PNG or WEBP.")
            }
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifBlank { "proof" }
            path = "$userId/${UUID.randomUUID()}-$safe"
            auth.uploadObject("payment-proofs", path, mime, size) {
                ctx.contentResolver.openInputStream(proof) ?: throw ApiError(Kind.OTHER, "Couldn't open the screenshot.")
            }
        }
        val j = JSONObject().put("p_project_id", projectId).put("p_transaction_ref", ref).put("p_payment_date", date)
        if (path != null) j.put("p_screenshot_path", path)
        if (message.isNotBlank()) j.put("p_message", message)
        rpc("submit_payment_request", j)
    }

    // ---- notifications
    suspend fun notices(): List<Notice> {
        val a = JSONArray(get("/rest/v1/notifications?select=id,title,body,read_at,created_at&order=created_at.desc&limit=50").body)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Notice(o.str("id"), o.str("title"), o.str("body"), !o.isNull("read_at"), o.str("created_at").take(10))
        }
    }
    suspend fun markRead() { rpc("mark_notifications_read", JSONObject()) }

    // ---- support
    suspend fun myTickets(): List<SupportTicket> {
        val a = JSONArray(get("/rest/v1/support_tickets?select=id,subject,category,status,created_at&order=created_at.desc&limit=50").body)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            SupportTicket(o.str("id"), o.str("subject"), o.str("category"), o.str("status"), "", o.str("created_at").take(10))
        }
    }

    suspend fun allTickets(): List<SupportTicket> {
        val a = JSONArray(rpc("admin_list_tickets", JSONObject()).body)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            SupportTicket(o.str("ticket_id"), o.str("subject"), o.str("category"), o.str("status"),
                o.str("display_name").ifBlank { o.str("email") }, o.str("created_at").take(10))
        }
    }

    suspend fun messages(ticketId: String): List<SupportMsg> {
        val a = JSONArray(get("/rest/v1/support_messages?ticket_id=eq.$ticketId&select=id,body,is_staff,created_at&order=created_at.asc").body)
        return List(a.length()) {
            val o = a.getJSONObject(it)
            SupportMsg(o.str("id"), o.str("body"), o.optBoolean("is_staff"), o.str("created_at").take(16).replace('T', ' '))
        }
    }

    suspend fun createTicket(category: String, subject: String, body: String) {
        rpc("create_ticket", JSONObject().put("p_category", category).put("p_subject", subject).put("p_body", body))
    }

    suspend fun reply(ticketId: String, body: String) {
        val r = auth.rest("POST", "/rest/v1/support_messages", JSONObject().put("ticket_id", ticketId).put("body", body))
        if (r.code !in 200..299) throw ApiError(Kind.OTHER, errMsg(r))
    }

    suspend fun close(ticketId: String) { rpc("close_my_ticket", JSONObject().put("p_ticket_id", ticketId)) }
}
