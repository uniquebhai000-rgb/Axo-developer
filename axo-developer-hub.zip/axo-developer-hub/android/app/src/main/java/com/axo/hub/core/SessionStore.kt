package com.axo.hub.core

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

data class StoredSession(
    val access: String, val refresh: String, val expiresAt: Long,
    val userId: String, val email: String
)

/** Tokens are kept in AES-256 encrypted preferences (Android Keystore backed). */
class SessionStore(context: Context) {
    private val prefs: SharedPreferences? = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "axo_session", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) { null } // no persistence if keystore is unavailable

    fun save(s: StoredSession) {
        prefs?.edit()
            ?.putString("a", s.access)?.putString("r", s.refresh)?.putLong("e", s.expiresAt)
            ?.putString("u", s.userId)?.putString("m", s.email)?.apply()
    }

    fun load(): StoredSession? {
        val p = prefs ?: return null
        val a = p.getString("a", null) ?: return null
        val r = p.getString("r", null) ?: return null
        val u = p.getString("u", null) ?: return null
        return StoredSession(a, r, p.getLong("e", 0L), u, p.getString("m", "") ?: "")
    }

    fun clear() { prefs?.edit()?.clear()?.apply() }
}
