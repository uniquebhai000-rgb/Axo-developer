package com.axo.hub.ui.market

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.axo.hub.core.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MarketViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MarketRepository(ServiceLocator.auth(app))

    val categories = MutableStateFlow<List<Category>>(emptyList())
    val recent = MutableStateFlow<Load<List<ProjectCard>>>(Load.Loading)
    val trending = MutableStateFlow<Load<List<ProjectCard>>>(Load.Loading)
    val results = MutableStateFlow<Load<List<ProjectCard>>>(Load.Loading)
    val unlocked = MutableStateFlow<Load<List<ProjectCard>>>(Load.Loading)
    val saved = MutableStateFlow<Load<List<ProjectCard>>>(Load.Loading)
    val detail = MutableStateFlow<Load<ProjectDetail?>>(Load.Loading)
    val access = MutableStateFlow<Set<String>>(emptySet())
    val favIds = MutableStateFlow<Set<String>>(emptySet())
    val filters = MutableStateFlow(Filters())

    init { refreshHome() }

    private fun err(e: Throwable) =
        if (e is ApiError && e.kind == Kind.NETWORK) "Can't reach the server. Check your connection."
        else "Couldn't load. Please try again."

    private suspend fun <T> load(flow: MutableStateFlow<Load<T>>, block: suspend () -> T) {
        flow.value = try { Load.Ready(block()) } catch (e: Exception) { Load.Error(err(e)) }
    }

    fun refreshHome() {
        viewModelScope.launch {
            try { categories.value = repo.categories() } catch (e: Exception) { /* chips just stay empty */ }
            try { access.value = repo.myAccess() } catch (e: Exception) { }
            load(saved) { repo.favorites().also { l -> favIds.value = l.map { it.id }.toSet() } }
            load(recent) { repo.projects(Filters(), emptyList(), 8) }
            load(trending) { repo.projects(Filters(popular = true), emptyList(), 5) }
        }
    }

    fun refreshLibrary() {
        viewModelScope.launch {
            try { access.value = repo.myAccess() } catch (e: Exception) { }
            load(unlocked) { repo.library() }
            load(saved) { repo.favorites().also { l -> favIds.value = l.map { it.id }.toSet() } }
        }
    }

    private fun catIds(id: String?): List<String> {
        if (id == null) return emptyList()
        return listOf(id) + categories.value.filter { it.parentId == id }.map { it.id }
    }

    fun runSearch() {
        val f = filters.value
        viewModelScope.launch { load(results) { repo.projects(f, catIds(f.categoryId)) } }
    }

    fun openDetail(id: String) {
        viewModelScope.launch {
            detail.value = Load.Loading
            load(detail) { repo.detail(id) }
        }
    }

    fun toggleFavorite(id: String) {
        val on = id in favIds.value
        favIds.value = if (on) favIds.value - id else favIds.value + id
        viewModelScope.launch {
            try {
                if (on) repo.removeFavorite(id) else repo.addFavorite(id)
                load(saved) { repo.favorites() }
            } catch (e: Exception) {
                favIds.value = if (on) favIds.value + id else favIds.value - id
            }
        }
    }

    suspend fun loadImage(path: String): Bitmap? = repo.image(path)
}
