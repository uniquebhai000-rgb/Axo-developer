package com.axo.hub.ui.admin

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.axo.hub.core.*
import com.axo.hub.ui.components.*
import com.axo.hub.ui.market.MarketViewModel
import com.axo.hub.ui.theme.Axo
import kotlinx.coroutines.delay

@Composable
private fun Toasts(av: AdminViewModel) {
    val ctx = LocalContext.current
    val m by av.message.collectAsState()
    LaunchedEffect(m) {
        val t = m
        if (t != null) { Toast.makeText(ctx, t, Toast.LENGTH_LONG).show(); av.message.value = null }
    }
}

@Composable
private fun StatusChip(status: String) {
    val (label, color) = when (status) {
        "PUBLISHED" -> "Published" to Axo.Success
        "DRAFT" -> "Draft" to Axo.Mist
        "SUSPENDED" -> "Hidden" to Axo.Danger
        else -> status to Axo.Mist
    }
    Text(label, color = color, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
}

private fun priceField(p: Double) = if (p % 1.0 == 0.0) p.toInt().toString() else p.toString()

// ------------------------------------------------------------------ list
@Composable
fun AdminTab(av: AdminViewModel, mv: MarketViewModel, onOpen: (String) -> Unit) {
    val st by av.projects.collectAsState()
    val cats by mv.categories.collectAsState()
    val busy by av.busy.collectAsState()
    var creating by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { av.loadProjects(); mv.refreshHome() }
    Toasts(av)

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Owner panel", style = MaterialTheme.typography.headlineMedium)
        Text("Only you can see this. Add projects, set prices, upload files, lock or unlock users.",
            color = Axo.Mist, modifier = Modifier.padding(vertical = 6.dp))
        Spacer(Modifier.height(10.dp))
        GradientButton("+ NEW PROJECT", onClick = { creating = true })
        Spacer(Modifier.height(18.dp))
        when (val s = st) {
            Load.Loading -> { Skeleton(80.dp); Spacer(Modifier.height(10.dp)); Skeleton(80.dp) }
            is Load.Error -> Text(s.msg, color = Axo.Danger)
            is Load.Ready -> {
                if (s.data.isEmpty()) EmptyState(Icons.Filled.Inventory2, "No projects yet", "Tap NEW PROJECT to add your first one.")
                s.data.forEach { p ->
                    GlassCard(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).clickable { onOpen(p.id) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                                Text(priceText(p.price), color = Axo.Orchid)
                            }
                            StatusChip(p.status)
                            Icon(Icons.Filled.ChevronRight, null, tint = Axo.Mist)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }

    if (creating) {
        var title by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var cat by remember { mutableStateOf<String?>(null) }
        var publish by remember { mutableStateOf(false) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { creating = false }, containerColor = Axo.Panel,
            title = { Text("New project") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(title, { title = it.take(80) }, label = { Text("Title") }, singleLine = true,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(price, { price = it.filter { c -> c.isDigit() || c == '.' }.take(9) },
                        label = { Text("Price in \u20B9 (0 = free)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(desc, { desc = it.take(5000) }, label = { Text("Description") }, minLines = 3,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Category", color = Axo.Mist)
                    cats.filter { it.parentId != null }.forEach { c ->
                        Row(Modifier.fillMaxWidth().clickable { cat = c.id }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(cat == c.id, { cat = c.id })
                            Text(c.name)
                        }
                    }
                    Row(Modifier.fillMaxWidth().clickable { publish = !publish }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(publish, { publish = it })
                        Text("Publish now (visible to everyone)")
                    }
                    err?.let { Text(it, color = Axo.Danger) }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    val p = price.toDoubleOrNull()
                    when {
                        title.trim().length < 3 -> err = "Title needs 3+ characters."
                        p == null -> err = "Enter a price (0 for free)."
                        cat == null -> err = "Pick a category."
                        else -> { av.createProject(title.trim(), desc.trim(), p, cat!!, publish); creating = false }
                    }
                }) { Text("Create") }
            },
            dismissButton = { TextButton({ creating = false }) { Text("Cancel") } })
    }
}

// ------------------------------------------------------------------ one project
@Composable
fun AdminProjectScreen(av: AdminViewModel, projectId: String, onBack: () -> Unit) {
    val projects by av.projects.collectAsState()
    val files by av.files.collectAsState()
    val access by av.access.collectAsState()
    val hits by av.hits.collectAsState()
    val busy by av.busy.collectAsState()
    Toasts(av)
    LaunchedEffect(projectId) { av.loadFiles(projectId); av.loadAccess(projectId) }

    val project = (projects as? Load.Ready<List<AdminProject>>)?.data?.firstOrNull { it.id == projectId }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) av.upload(uri, projectId, false)
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) av.upload(uri, projectId, true)
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Manage project", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            if (busy) CircularProgressIndicator(Modifier.size(22.dp).padding(end = 4.dp), strokeWidth = 2.dp, color = Axo.Orchid)
        }
        if (project == null) {
            EmptyState(Icons.Filled.Inventory2, "Loading project", "If this stays, go back and open it again.")
            return@Column
        }

        var title by remember(project.id, project.title) { mutableStateOf(project.title) }
        var price by remember(project.id, project.price) { mutableStateOf(priceField(project.price)) }
        var desc by remember(project.id, project.description) { mutableStateOf(project.description) }
        var status by remember(project.id, project.status) { mutableStateOf(project.status) }
        var query by remember { mutableStateOf("") }
        var pick by remember { mutableStateOf<UserHit?>(null) }
        var lockTarget by remember { mutableStateOf<AdminAccess?>(null) }
        var removeFile by remember { mutableStateOf<AdminFile?>(null) }
        LaunchedEffect(query) {
            if (query.trim().length >= 3) { delay(400); av.search(query.trim()) } else av.hits.value = emptyList()
        }
        val chip = FilterChipDefaults.filterChipColors(selectedContainerColor = Axo.Electric,
            selectedLabelColor = Color.White, labelColor = Axo.Mist)

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            // ---- details & price
            Text("Details and price", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(title, { title = it.take(80) }, Modifier.fillMaxWidth(), label = { Text("Title") },
                singleLine = true, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(price, { price = it.filter { c -> c.isDigit() || c == '.' }.take(9) }, Modifier.fillMaxWidth(),
                label = { Text("Price in \u20B9 (0 = free)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(desc, { desc = it.take(5000) }, Modifier.fillMaxWidth(), label = { Text("Description") },
                minLines = 3, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(status == "DRAFT", { status = "DRAFT" }, { Text("Draft") }, colors = chip)
                FilterChip(status == "PUBLISHED", { status = "PUBLISHED" }, { Text("Published") }, colors = chip)
                FilterChip(status == "SUSPENDED", { status = "SUSPENDED" }, { Text("Hidden") }, colors = chip)
            }
            Spacer(Modifier.height(10.dp))
            GradientButton("SAVE", loading = busy, onClick = {
                val p = price.toDoubleOrNull()
                if (p == null) av.message.value = "Enter a valid price."
                else av.updateProject(project.id, title.trim(), desc.trim(), p, status)
            })

            // ---- images
            Spacer(Modifier.height(24.dp))
            Text("Cover / preview images", style = MaterialTheme.typography.titleMedium)
            Text("Shown to everyone with your account watermark. Don't upload the real product here.",
                color = Axo.Mist, modifier = Modifier.padding(vertical = 6.dp))
            OutlinedButton({ pickImage.launch("image/*") }, Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp), enabled = !busy) {
                Icon(Icons.Filled.Photo, null); Spacer(Modifier.width(8.dp)); Text("Add image")
            }

            // ---- files
            Spacer(Modifier.height(24.dp))
            Text("Locked files", style = MaterialTheme.typography.titleMedium)
            Text("Private. Only users you unlock can download these.", color = Axo.Mist,
                modifier = Modifier.padding(vertical = 6.dp))
            when (val f = files) {
                Load.Loading -> Skeleton(56.dp)
                is Load.Error -> Text(f.msg, color = Axo.Danger)
                is Load.Ready -> {
                    if (f.data.isEmpty()) Text("No files yet.", color = Axo.Mist)
                    f.data.forEach { file ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(file.name, maxLines = 1)
                                Text(sizeText(file.size), color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                            }
                            IconButton({ removeFile = file }) { Icon(Icons.Filled.Delete, "Remove", tint = Axo.Danger) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton({ pickFile.launch("*/*") }, Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp), enabled = !busy) {
                Icon(Icons.Filled.Upload, null); Spacer(Modifier.width(8.dp)); Text("Upload file (max 50 MB)")
            }

            // ---- access
            Spacer(Modifier.height(24.dp))
            Text("Who has access", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            when (val a = access) {
                Load.Loading -> Skeleton(56.dp)
                is Load.Error -> Text(a.msg, color = Axo.Danger)
                is Load.Ready -> {
                    if (a.data.isEmpty()) Text("Nobody yet.", color = Axo.Mist)
                    a.data.forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(row.name.ifBlank { row.email }, maxLines = 1)
                                Text("${row.email}\n${row.status}" +
                                    (if (row.expires.isNotBlank()) " \u2022 until ${row.expires}" else " \u2022 no expiry"),
                                    color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                            }
                            if (row.status == "ACTIVE") TextButton({ lockTarget = row }) { Text("Lock", color = Axo.Danger) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Unlock for a user", color = Axo.Mist)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(query, { query = it.take(60) }, Modifier.fillMaxWidth(),
                placeholder = { Text("Email, name or AXO-ID") }, singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = Axo.Mist) },
                colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            hits.forEach { h ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { pick = h }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(h.name.ifBlank { h.email }, maxLines = 1)
                        Text("${h.email} \u2022 ${h.code}", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                    }
                    Icon(Icons.Filled.LockOpen, null, tint = Axo.Orchid)
                }
            }
            Spacer(Modifier.height(30.dp))
        }

        pick?.let { u ->
            AlertDialog(
                onDismissRequest = { pick = null }, containerColor = Axo.Panel,
                title = { Text("Unlock for ${u.name.ifBlank { u.email }}") },
                text = { Text("Choose how long they keep access.") },
                confirmButton = {
                    Column {
                        TextButton({ av.unlock(u.id, projectId, null); pick = null; query = "" }) { Text("Forever") }
                        TextButton({ av.unlock(u.id, projectId, 30); pick = null; query = "" }) { Text("30 days") }
                        TextButton({ av.unlock(u.id, projectId, 7); pick = null; query = "" }) { Text("7 days") }
                    }
                },
                dismissButton = { TextButton({ pick = null }) { Text("Cancel") } })
        }
        lockTarget?.let { t ->
            AlertDialog(
                onDismissRequest = { lockTarget = null }, containerColor = Axo.Panel,
                title = { Text("Lock again?") },
                text = { Text("${t.email} will not be able to download this project any more.") },
                confirmButton = { TextButton({ av.lock(t.id, projectId); lockTarget = null }) { Text("Lock", color = Axo.Danger) } },
                dismissButton = { TextButton({ lockTarget = null }) { Text("Cancel") } })
        }
        removeFile?.let { f ->
            AlertDialog(
                onDismissRequest = { removeFile = null }, containerColor = Axo.Panel,
                title = { Text("Remove file?") },
                text = { Text("${f.name} will no longer be downloadable.") },
                confirmButton = { TextButton({ av.deleteFile(f.id, projectId); removeFile = null }) { Text("Remove", color = Axo.Danger) } },
                dismissButton = { TextButton({ removeFile = null }) { Text("Cancel") } })
        }
    }
}
