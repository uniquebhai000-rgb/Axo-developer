package com.axo.hub.ui.admin

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.axo.hub.core.*
import com.axo.hub.ui.components.*
import com.axo.hub.ui.market.MarketViewModel
import com.axo.hub.ui.theme.Axo
import kotlinx.coroutines.delay

@Composable
private fun Toasts(av: AdminViewModel) {
    val ctx = LocalContext.current
    val m by av.message.collectAsState()
    LaunchedEffect(m) {
        val t = m
        if (t != null) { Toast.makeText(ctx, t, Toast.LENGTH_LONG).show(); av.message.value = null }
    }
}

@Composable
private fun StatusChip(status: String) {
    val (label, color) = when (status) {
        "PUBLISHED" -> "Published" to Axo.Success
        "DRAFT" -> "Draft" to Axo.Mist
        "SUSPENDED" -> "Hidden" to Axo.Danger
        else -> status to Axo.Mist
    }
    Text(label, color = color, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
}

private fun priceField(p: Double) = if (p % 1.0 == 0.0) p.toInt().toString() else p.toString()

// ------------------------------------------------------------------ list
@Composable
private fun ProjectsSection(av: AdminViewModel, mv: MarketViewModel, onOpen: (String) -> Unit) {
    val st by av.projects.collectAsState()
    val cats by mv.categories.collectAsState()
    val busy by av.busy.collectAsState()
    var creating by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { av.loadProjects(); mv.refreshHome() }
    Toasts(av)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Owner panel", style = MaterialTheme.typography.headlineMedium)
        Text("Only you can see this. Add projects, set prices, upload files, lock or unlock users.",
            color = Axo.Mist, modifier = Modifier.padding(vertical = 6.dp))
        Spacer(Modifier.height(10.dp))
        GradientButton("+ NEW PROJECT", onClick = { creating = true })
        Spacer(Modifier.height(18.dp))
        when (val s = st) {
            Load.Loading -> { Skeleton(80.dp); Spacer(Modifier.height(10.dp)); Skeleton(80.dp) }
            is Load.Error -> Text(s.msg, color = Axo.Danger)
            is Load.Ready -> {
                if (s.data.isEmpty()) EmptyState(Icons.Filled.Inventory2, "No projects yet", "Tap NEW PROJECT to add your first one.")
                s.data.forEach { p ->
                    GlassCard(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).clickable { onOpen(p.id) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                                Text(priceText(p.price), color = Axo.Orchid)
                            }
                            StatusChip(p.status)
                            Icon(Icons.Filled.ChevronRight, null, tint = Axo.Mist)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }

    if (creating) {
        var title by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var cat by remember { mutableStateOf<String?>(null) }
        var publish by remember { mutableStateOf(false) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { creating = false }, containerColor = Axo.Panel,
            title = { Text("New project") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(title, { title = it.take(80) }, label = { Text("Title") }, singleLine = true,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(price, { price = it.filter { c -> c.isDigit() || c == '.' }.take(9) },
                        label = { Text("Price in \u20B9 (0 = free)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(desc, { desc = it.take(5000) }, label = { Text("Description") }, minLines = 3,
                        colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Category", color = Axo.Mist)
                    cats.filter { it.parentId != null }.forEach { c ->
                        Row(Modifier.fillMaxWidth().clickable { cat = c.id }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(cat == c.id, { cat = c.id })
                            Text(c.name)
                        }
                    }
                    Row(Modifier.fillMaxWidth().clickable { publish = !publish }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(publish, { publish = it })
                        Text("Publish now (visible to everyone)")
                    }
                    err?.let { Text(it, color = Axo.Danger) }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    val p = price.toDoubleOrNull()
                    when {
                        title.trim().length < 3 -> err = "Title needs 3+ characters."
                        p == null -> err = "Enter a price (0 for free)."
                        cat == null -> err = "Pick a category."
                        else -> { av.createProject(title.trim(), desc.trim(), p, cat!!, publish); creating = false }
                    }
                }) { Text("Create") }
            },
            dismissButton = { TextButton({ creating = false }) { Text("Cancel") } })
    }
}

@Composable
fun AdminTab(av: AdminViewModel, mv: MarketViewModel, onOpen: (String) -> Unit, onSupport: () -> Unit) {
    var section by remember { mutableStateOf("Projects") }
    val chip = FilterChipDefaults.filterChipColors(selectedContainerColor = Axo.Electric,
        selectedLabelColor = Color.White, labelColor = Axo.Mist)
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Projects", "Payments", "Settings").forEach { n ->
                FilterChip(section == n, { section = n }, { Text(n) }, colors = chip)
            }
            AssistChip(onClick = onSupport, label = { Text("Support inbox") },
                leadingIcon = { Icon(Icons.Filled.SupportAgent, null, tint = Axo.Orchid) })
        }
        when (section) {
            "Projects" -> ProjectsSection(av, mv, onOpen)
            "Payments" -> PaymentsSection(av, mv)
            else -> SettingsSection(av, mv)
        }
    }
}

@Composable
private fun PaymentsSection(av: AdminViewModel, mv: MarketViewModel) {
    val st by av.payments.collectAsState()
    val busy by av.busy.collectAsState()
    var filter by remember { mutableStateOf<String?>("PENDING") }
    var sel by remember { mutableStateOf<AdminPayment?>(null) }
    var confirmApprove by remember { mutableStateOf<AdminPayment?>(null) }
    var reasonFor by remember { mutableStateOf<Pair<String, AdminPayment>?>(null) }
    LaunchedEffect(filter) { av.loadPayments(filter) }
    Toasts(av)
    val chip = FilterChipDefaults.filterChipColors(selectedContainerColor = Axo.Electric,
        selectedLabelColor = Color.White, labelColor = Axo.Mist)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Text("Payment requests", style = MaterialTheme.typography.headlineMedium)
        Text("Check the money in your own UPI app first, then approve.", color = Axo.Mist, modifier = Modifier.padding(vertical = 6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("PENDING" to "Pending", "UNDER_REVIEW" to "In review", "APPROVED" to "Approved",
                "REJECTED" to "Rejected", null to "All").forEach { (v, label) ->
                FilterChip(filter == v, { filter = v }, { Text(label) }, colors = chip)
            }
        }
        Spacer(Modifier.height(12.dp))
        when (val s = st) {
            Load.Loading -> { Skeleton(90.dp); Spacer(Modifier.height(10.dp)); Skeleton(90.dp) }
            is Load.Error -> Text(s.msg, color = Axo.Danger)
            is Load.Ready -> {
                if (s.data.isEmpty()) EmptyState(Icons.Filled.Payments, "Nothing here", "No payment requests in this list.")
                s.data.forEach { p ->
                    GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(24.dp)).clickable { sel = p }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.project, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                Text("${p.name.ifBlank { p.email }}  \u2022  ${priceText(p.amount)}", color = Axo.Mist,
                                    style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                                Text("Ref ${p.ref}  \u2022  ${p.created}", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                            }
                            Text(p.status.replace('_', ' '), fontWeight = FontWeight.SemiBold,
                                color = when (p.status) { "APPROVED" -> Axo.Success; "REJECTED", "REFUNDED" -> Axo.Danger; else -> Axo.Orchid })
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    sel?.let { p ->
        AlertDialog(
            onDismissRequest = { sel = null }, containerColor = Axo.Panel,
            title = { Text(p.project) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("${p.name.ifBlank { "Customer" }}\n${p.email}", color = Axo.Mist)
                    Spacer(Modifier.height(8.dp))
                    Text("Amount: ${priceText(p.amount)}", fontWeight = FontWeight.SemiBold)
                    Text("Reference: ${p.ref}")
                    Text("Paid on: ${p.payDate}")
                    Text("Status: ${p.status}")
                    if (p.message.isNotBlank()) Text("Message: ${p.message}", color = Axo.Mist)
                    if (p.reason.isNotBlank()) Text("Reason: ${p.reason}", color = Axo.Danger)
                    p.proof?.let { path ->
                        Spacer(Modifier.height(8.dp))
                        Text("Payment screenshot", color = Axo.Mist)
                        RemoteImage(path, { x -> mv.loadImageFrom("payment-proofs", x) },
                            Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(12.dp)))
                    }
                }
            },
            confirmButton = {
                Column {
                    if (p.status == "PENDING") TextButton({ av.underReview(p.id); sel = null }, enabled = !busy) { Text("Mark under review") }
                    if (p.status == "PENDING" || p.status == "UNDER_REVIEW") {
                        TextButton({ confirmApprove = p; sel = null }, enabled = !busy) { Text("Approve", color = Axo.Success) }
                        TextButton({ reasonFor = "reject" to p; sel = null }, enabled = !busy) { Text("Reject", color = Axo.Danger) }
                    }
                    if (p.status == "APPROVED") TextButton({ reasonFor = "refund" to p; sel = null }, enabled = !busy) { Text("Refund and lock", color = Axo.Danger) }
                }
            },
            dismissButton = { TextButton({ sel = null }) { Text("Close") } })
    }

    confirmApprove?.let { p ->
        AlertDialog(
            onDismissRequest = { confirmApprove = null }, containerColor = Axo.Panel,
            title = { Text("Approve payment?") },
            text = { Text("Only approve if ${priceText(p.amount)} really reached your account. This unlocks the project for ${p.email}.") },
            confirmButton = { TextButton({ av.approve(p.id); confirmApprove = null }) { Text("Approve", color = Axo.Success) } },
            dismissButton = { TextButton({ confirmApprove = null }) { Text("Cancel") } })
    }

    reasonFor?.let { (kind, p) ->
        var reason by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { reasonFor = null }, containerColor = Axo.Panel,
            title = { Text(if (kind == "reject") "Reject payment" else "Refund and lock") },
            text = {
                OutlinedTextField(reason, { reason = it.take(300) }, label = { Text("Reason (customer will see it)") },
                    minLines = 2, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            },
            confirmButton = {
                TextButton(enabled = reason.trim().length >= 3, onClick = {
                    if (kind == "reject") av.reject(p.id, reason.trim()) else av.refund(p.id, reason.trim())
                    reasonFor = null
                }) { Text("Confirm", color = Axo.Danger) }
            },
            dismissButton = { TextButton({ reasonFor = null }) { Text("Cancel") } })
    }
}

@Composable
private fun SettingsSection(av: AdminViewModel, mv: MarketViewModel) {
    val st by av.settings.collectAsState()
    val qr by av.qrPath.collectAsState()
    val busy by av.busy.collectAsState()
    LaunchedEffect(Unit) { av.loadSettings() }
    Toasts(av)
    val pickQr = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) av.uploadQr(uri)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Text("Payment settings", style = MaterialTheme.typography.headlineMedium)
        Text("Customers see this when they tap GET ACCESS.", color = Axo.Mist, modifier = Modifier.padding(vertical = 6.dp))
        when (val s = st) {
            Load.Loading -> Skeleton(200.dp)
            is Load.Error -> Text(s.msg, color = Axo.Danger)
            is Load.Ready -> {
                val ps = s.data
                var upi by remember(ps) { mutableStateOf(ps.upi) }
                var instr by remember(ps) { mutableStateOf(ps.instructions) }
                var support by remember(ps) { mutableStateOf(ps.support) }
                var terms by remember(ps) { mutableStateOf(ps.terms) }
                OutlinedTextField(upi, { upi = it.take(100) }, Modifier.fillMaxWidth(), label = { Text("UPI ID") },
                    singleLine = true, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(instr, { instr = it.take(2000) }, Modifier.fillMaxWidth(), label = { Text("Payment instructions") },
                    minLines = 3, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(support, { support = it.take(200) }, Modifier.fillMaxWidth(), label = { Text("Support contact") },
                    singleLine = true, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(terms, { terms = it.take(3000) }, Modifier.fillMaxWidth(), label = { Text("Payment terms") },
                    minLines = 3, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(10.dp))
                qr?.let { q ->
                    RemoteImage(q, { x -> mv.loadImageFrom("payment-assets", x) },
                        Modifier.size(200.dp).clip(RoundedCornerShape(16.dp)))
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedButton({ pickQr.launch("image/*") }, Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp), enabled = !busy) {
                    Icon(Icons.Filled.QrCode, null); Spacer(Modifier.width(8.dp))
                    Text(if (qr == null) "Upload payment QR" else "Change payment QR")
                }
                Spacer(Modifier.height(12.dp))
                GradientButton("SAVE", loading = busy, onClick = { av.saveSettings(upi, instr, support, terms) })
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

// ------------------------------------------------------------------ one project
@Composable
fun AdminProjectScreen(av: AdminViewModel, projectId: String, onBack: () -> Unit) {
    val projects by av.projects.collectAsState()
    val files by av.files.collectAsState()
    val access by av.access.collectAsState()
    val hits by av.hits.collectAsState()
    val busy by av.busy.collectAsState()
    Toasts(av)
    LaunchedEffect(projectId) { av.loadFiles(projectId); av.loadAccess(projectId) }

    val project = (projects as? Load.Ready<List<AdminProject>>)?.data?.firstOrNull { it.id == projectId }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) av.upload(uri, projectId, false)
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) av.upload(uri, projectId, true)
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("Manage project", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            if (busy) CircularProgressIndicator(Modifier.size(22.dp).padding(end = 4.dp), strokeWidth = 2.dp, color = Axo.Orchid)
        }
        if (project == null) {
            EmptyState(Icons.Filled.Inventory2, "Loading project", "If this stays, go back and open it again.")
            return@Column
        }

        var title by remember(project.id, project.title) { mutableStateOf(project.title) }
        var price by remember(project.id, project.price) { mutableStateOf(priceField(project.price)) }
        var desc by remember(project.id, project.description) { mutableStateOf(project.description) }
        var status by remember(project.id, project.status) { mutableStateOf(project.status) }
        var query by remember { mutableStateOf("") }
        var pick by remember { mutableStateOf<UserHit?>(null) }
        var lockTarget by remember { mutableStateOf<AdminAccess?>(null) }
        var removeFile by remember { mutableStateOf<AdminFile?>(null) }
        var confirmDelete by remember { mutableStateOf(false) }
        LaunchedEffect(query) {
            if (query.trim().length >= 3) { delay(400); av.search(query.trim()) } else av.hits.value = emptyList()
        }
        val chip = FilterChipDefaults.filterChipColors(selectedContainerColor = Axo.Electric,
            selectedLabelColor = Color.White, labelColor = Axo.Mist)

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            // ---- details & price
            Text("Details and price", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(title, { title = it.take(80) }, Modifier.fillMaxWidth(), label = { Text("Title") },
                singleLine = true, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(price, { price = it.filter { c -> c.isDigit() || c == '.' }.take(9) }, Modifier.fillMaxWidth(),
                label = { Text("Price in \u20B9 (0 = free)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(desc, { desc = it.take(5000) }, Modifier.fillMaxWidth(), label = { Text("Description") },
                minLines = 3, colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(status == "DRAFT", { status = "DRAFT" }, { Text("Draft") }, colors = chip)
                FilterChip(status == "PUBLISHED", { status = "PUBLISHED" }, { Text("Published") }, colors = chip)
                FilterChip(status == "SUSPENDED", { status = "SUSPENDED" }, { Text("Hidden") }, colors = chip)
            }
            Spacer(Modifier.height(10.dp))
            GradientButton("SAVE", loading = busy, onClick = {
                val p = price.toDoubleOrNull()
                if (p == null) av.message.value = "Enter a valid price."
                else av.updateProject(project.id, title.trim(), desc.trim(), p, status)
            })

            // ---- images
            Spacer(Modifier.height(24.dp))
            Text("Cover / preview images", style = MaterialTheme.typography.titleMedium)
            Text("Shown to everyone with your account watermark. Don't upload the real product here.",
                color = Axo.Mist, modifier = Modifier.padding(vertical = 6.dp))
            OutlinedButton({ pickImage.launch("image/*") }, Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp), enabled = !busy) {
                Icon(Icons.Filled.Photo, null); Spacer(Modifier.width(8.dp)); Text("Add image")
            }

            // ---- files
            Spacer(Modifier.height(24.dp))
            Text("Locked files", style = MaterialTheme.typography.titleMedium)
            Text("Private. Only users you unlock can download these.", color = Axo.Mist,
                modifier = Modifier.padding(vertical = 6.dp))
            when (val f = files) {
                Load.Loading -> Skeleton(56.dp)
                is Load.Error -> Text(f.msg, color = Axo.Danger)
                is Load.Ready -> {
                    if (f.data.isEmpty()) Text("No files yet.", color = Axo.Mist)
                    f.data.forEach { file ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(file.name, maxLines = 1)
                                Text(sizeText(file.size), color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                            }
                            IconButton({ removeFile = file }) { Icon(Icons.Filled.Delete, "Remove", tint = Axo.Danger) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton({ pickFile.launch("*/*") }, Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp), enabled = !busy) {
                Icon(Icons.Filled.Upload, null); Spacer(Modifier.width(8.dp)); Text("Upload file (max 50 MB)")
            }

            // ---- access
            Spacer(Modifier.height(24.dp))
            Text("Who has access", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            when (val a = access) {
                Load.Loading -> Skeleton(56.dp)
                is Load.Error -> Text(a.msg, color = Axo.Danger)
                is Load.Ready -> {
                    if (a.data.isEmpty()) Text("Nobody yet.", color = Axo.Mist)
                    a.data.forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(row.name.ifBlank { row.email }, maxLines = 1)
                                Text("${row.email}\n${row.status}" +
                                    (if (row.expires.isNotBlank()) " \u2022 until ${row.expires}" else " \u2022 no expiry"),
                                    color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                            }
                            if (row.status == "ACTIVE") TextButton({ lockTarget = row }) { Text("Lock", color = Axo.Danger) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Unlock for a user", color = Axo.Mist)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(query, { query = it.take(60) }, Modifier.fillMaxWidth(),
                placeholder = { Text("Email, name or AXO-ID") }, singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = Axo.Mist) },
                colors = axoFieldColors(), shape = RoundedCornerShape(14.dp))
            hits.forEach { h ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { pick = h }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(h.name.ifBlank { h.email }, maxLines = 1)
                        Text("${h.email} \u2022 ${h.code}", color = Axo.Mist, style = MaterialTheme.typography.bodyMedium)
                    }
                    Icon(Icons.Filled.LockOpen, null, tint = Axo.Orchid)
                }
            }
            Spacer(Modifier.height(28.dp))
            OutlinedButton({ confirmDelete = true }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Axo.Danger), enabled = !busy) {
                Icon(Icons.Filled.Delete, null); Spacer(Modifier.width(8.dp)); Text("Delete project")
            }
            Spacer(Modifier.height(30.dp))
        }

        if (confirmDelete) AlertDialog(
            onDismissRequest = { confirmDelete = false }, containerColor = Axo.Panel,
            title = { Text("Delete this project?") },
            text = { Text("It disappears for everyone, including customers who already paid. Payment history is kept.") },
            confirmButton = { TextButton({ confirmDelete = false; av.deleteProject(project.id) { onBack() } }) { Text("Delete", color = Axo.Danger) } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("Cancel") } })

        pick?.let { u ->
            AlertDialog(
                onDismissRequest = { pick = null }, containerColor = Axo.Panel,
                title = { Text("Unlock for ${u.name.ifBlank { u.email }}") },
                text = { Text("Choose how long they keep access.") },
                confirmButton = {
                    Column {
                        TextButton({ av.unlock(u.id, projectId, null); pick = null; query = "" }) { Text("Forever") }
                        TextButton({ av.unlock(u.id, projectId, 30); pick = null; query = "" }) { Text("30 days") }
                        TextButton({ av.unlock(u.id, projectId, 7); pick = null; query = "" }) { Text("7 days") }
                    }
                },
                dismissButton = { TextButton({ pick = null }) { Text("Cancel") } })
        }
        lockTarget?.let { t ->
            AlertDialog(
                onDismissRequest = { lockTarget = null }, containerColor = Axo.Panel,
                title = { Text("Lock again?") },
                text = { Text("${t.email} will not be able to download this project any more.") },
                confirmButton = { TextButton({ av.lock(t.id, projectId); lockTarget = null }) { Text("Lock", color = Axo.Danger) } },
                dismissButton = { TextButton({ lockTarget = null }) { Text("Cancel") } })
        }
        removeFile?.let { f ->
            AlertDialog(
                onDismissRequest = { removeFile = null }, containerColor = Axo.Panel,
                title = { Text("Remove file?") },
                text = { Text("${f.name} will no longer be downloadable.") },
                confirmButton = { TextButton({ av.deleteFile(f.id, projectId); removeFile = null }) { Text("Remove", color = Axo.Danger) } },
                dismissButton = { TextButton({ removeFile = null }) { Text("Cancel") } })
        }
    }
}
