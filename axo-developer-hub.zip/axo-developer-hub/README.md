# AXO DEVELOPER HUB
Create. Showcase. Protect. Sell.

Phase 2: Supabase email auth (sign up, verification, sign in, reset, session persistence), profiles, roles.
See `docs/PHASE2_SETUP.md`. APK builds through GitHub Actions.
