# AXO DEVELOPER HUB
Create. Showcase. Protect. Sell.

- Phase 1-2: Android app (Compose + Material 3), email auth, profiles, roles.
- Phase 3: Supabase database, RLS, private storage, atomic payment/access functions.

Backend setup: `docs/PHASE3_SETUP.md`. APK builds through GitHub Actions.
