# AXO DEVELOPER HUB
Create. Showcase. Protect. Sell.

- Phase 1-2: Android app (Compose + Material 3), email auth, profiles, roles.
- Phase 3: Supabase database, RLS, private storage, atomic payment/access functions.
- Owner Admin panel (in-app).
- Phase 5: AXO LOCK secure download Edge Function + in-app download.
- Phase 4: Marketplace (browse, search, filters, details, protected preview, favorites, library).

Setup: `docs/PHASE3_SETUP.md`, `docs/PHASE4_SETUP.md`. APK builds through GitHub Actions.
