-- AXO DEVELOPER HUB - Phase 2: profiles + roles + RLS
do $$ begin
  create type public.app_role as enum ('CUSTOMER','DEVELOPER','SUPER_ADMIN');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  account_code  text not null unique,
  display_name  text not null default '' check (char_length(display_name) <= 40),
  bio           text not null default '' check (char_length(bio) <= 300),
  avatar_path   text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz
);

create table if not exists public.user_roles (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  role        public.app_role not null,
  granted_by  uuid references auth.users(id),
  granted_at  timestamptz not null default now(),
  revoked_at  timestamptz
);
create unique index if not exists user_roles_active_uq
  on public.user_roles(user_id, role) where revoked_at is null;
create index if not exists user_roles_user_idx on public.user_roles(user_id);

-- New user -> profile (unique AXO-XXXXXXXX id) + CUSTOMER role. Role is never read from the client.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
declare code text; tries int := 0; nm text;
begin
  nm := left(btrim(coalesce(new.raw_user_meta_data->>'display_name','')), 40);
  loop
    code := 'AXO-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,8));
    begin
      insert into public.profiles(id, account_code, display_name) values (new.id, code, nm);
      exit;
    exception when unique_violation then
      tries := tries + 1;
      if tries > 5 then raise; end if;
    end;
  end loop;
  insert into public.user_roles(user_id, role) values (new.id, 'CUSTOMER');
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Row Level Security
alter table public.profiles   enable row level security;
alter table public.user_roles enable row level security;

revoke all on public.profiles, public.user_roles from anon, authenticated;
grant select on public.profiles, public.user_roles to authenticated;

drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles
  for select to authenticated using (id = auth.uid() and deleted_at is null);

drop policy if exists roles_select_own on public.user_roles;
create policy roles_select_own on public.user_roles
  for select to authenticated using (user_id = auth.uid());
-- No insert/update/delete policies: only server-side code (service role / SQL) can change roles.

-- The only way a user edits their profile: whitelisted columns, validated.
create or replace function public.update_my_profile(p_display_name text, p_bio text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if char_length(btrim(p_display_name)) not between 2 and 40 then raise exception 'invalid name'; end if;
  if char_length(coalesce(p_bio,'')) > 300 then raise exception 'bio too long'; end if;
  update public.profiles set display_name = btrim(p_display_name), bio = coalesce(p_bio,''), updated_at = now()
   where id = auth.uid();
end $$;
revoke all on function public.update_my_profile(text,text) from public, anon;
grant execute on function public.update_my_profile(text,text) to authenticated;
