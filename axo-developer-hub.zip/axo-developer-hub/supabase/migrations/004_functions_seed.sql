-- AXO DEVELOPER HUB - Phase 3 (3/3): atomic business logic + seed data
-- Run AFTER 003_rls_storage.sql. Every function below runs in ONE transaction.
-- IMPORTANT: admin functions check auth.uid(), so call them with the ADMIN'S OWN login token
-- (not with the service-role key).

-- ---------- internal helpers ----------
create or replace function public.require_admin() returns void
language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.is_super_admin() then raise exception 'forbidden' using errcode = '42501'; end if;
end $$;

create or replace function public.audit_write(p_action text, p_entity text, p_id uuid, p_details jsonb default '{}'::jsonb)
returns void language sql security definer set search_path = '' as $$
  insert into public.audit_logs(actor_id, action, entity_type, entity_id, details)
  values (auth.uid(), p_action, p_entity, p_id, coalesce(p_details, '{}'::jsonb)) $$;

create or replace function public.notify_user(p_user uuid, p_type text, p_title text, p_body text, p_data jsonb default '{}'::jsonb)
returns void language sql security definer set search_path = '' as $$
  insert into public.notifications(user_id, type, title, body, data)
  values (p_user, p_type, p_title, coalesce(p_body,''), coalesce(p_data,'{}'::jsonb)) $$;

revoke all on function public.require_admin(), public.audit_write(text,text,uuid,jsonb),
  public.notify_user(uuid,text,text,text,jsonb) from public, anon, authenticated;

-- ---------- customer: submit a payment request (price is read from the DB, never from the client) ----------
create or replace function public.submit_payment_request(
  p_project_id uuid, p_transaction_ref text, p_payment_date date,
  p_screenshot_path text default null, p_message text default null) returns uuid
language plpgsql security definer set search_path = '' as $$
declare v_uid uuid := auth.uid(); v_price numeric; v_dev_user uuid; v_id uuid;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode = '42501'; end if;
  select p.price_inr, d.user_id into v_price, v_dev_user
    from public.projects p join public.developer_profiles d on d.id = p.developer_id
   where p.id = p_project_id and p.status = 'PUBLISHED' and p.deleted_at is null;
  if not found then raise exception 'project not available'; end if;
  if v_dev_user = v_uid then raise exception 'cannot buy your own project'; end if;
  if public.has_active_access(v_uid, p_project_id) then raise exception 'you already have access'; end if;
  if p_payment_date > current_date + 1 then raise exception 'invalid payment date'; end if;
  if p_screenshot_path is not null and p_screenshot_path not like v_uid::text || '/%' then
    raise exception 'invalid proof path';
  end if;
  begin
    insert into public.payment_requests(user_id, project_id, amount, transaction_ref, payment_date, screenshot_path, message)
    values (v_uid, p_project_id, v_price, btrim(p_transaction_ref), p_payment_date, p_screenshot_path, left(p_message, 500))
    returning id into v_id;
  exception when unique_violation then
    raise exception 'duplicate payment request';
  end;
  perform public.notify_user(v_uid, 'PAYMENT_SUBMITTED', 'Payment submitted', 'We will verify your payment soon.',
                             jsonb_build_object('payment_request_id', v_id));
  perform public.audit_write('PAYMENT_SUBMITTED', 'payment_request', v_id, jsonb_build_object('project_id', p_project_id));
  return v_id;
end $$;

-- ---------- admin: payments ----------
create or replace function public.set_payment_under_review(p_request_id uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  update public.payment_requests set status = 'UNDER_REVIEW' where id = p_request_id and status = 'PENDING';
  if not found then raise exception 'request not pending'; end if;
  perform public.audit_write('PAYMENT_UNDER_REVIEW', 'payment_request', p_request_id);
end $$;

create or replace function public.approve_payment(p_request_id uuid, p_note text default null) returns uuid
language plpgsql security definer set search_path = '' as $$
declare r public.payment_requests; proj public.projects; v_access uuid; v_pct numeric; v_comm numeric; v_dev_pct numeric;
begin
  perform public.require_admin();
  select * into r from public.payment_requests where id = p_request_id for update;   -- row lock = no double approval
  if not found then raise exception 'request not found'; end if;
  if r.status not in ('PENDING','UNDER_REVIEW') then raise exception 'request already processed'; end if;
  select * into proj from public.projects where id = r.project_id;

  update public.payment_requests
     set status = 'APPROVED', reviewed_by = auth.uid(), reviewed_at = now(), admin_note = coalesce(p_note, admin_note)
   where id = r.id;

  select id into v_access from public.project_access
   where user_id = r.user_id and project_id = r.project_id and status = 'ACTIVE' for update;
  if v_access is null then
    insert into public.project_access(user_id, project_id, granted_by, payment_request_id, reason)
    values (r.user_id, r.project_id, auth.uid(), r.id, 'Payment approved') returning id into v_access;
  else
    update public.project_access set payment_request_id = coalesce(payment_request_id, r.id), expires_at = null
     where id = v_access;
  end if;

  select coalesce((select (value #>> '{}')::numeric from public.app_settings where key = 'platform_commission_percent'), 20)
    into v_pct;
  select commission_percent into v_dev_pct from public.developer_profiles where id = proj.developer_id;
  v_pct := coalesce(v_dev_pct, v_pct);
  v_comm := round(r.amount * v_pct / 100, 2);
  insert into public.developer_earnings(developer_id, project_id, payment_request_id, gross_amount, commission_percent, commission_amount, net_amount)
  values (proj.developer_id, proj.id, r.id, r.amount, v_pct, v_comm, r.amount - v_comm)
  on conflict (payment_request_id) do nothing;

  perform public.notify_user(r.user_id, 'PAYMENT_APPROVED', 'Payment approved', 'Your access to "' || proj.title || '" is unlocked.',
                             jsonb_build_object('project_id', proj.id));
  perform public.audit_write('PAYMENT_APPROVED', 'payment_request', r.id,
                             jsonb_build_object('project_id', proj.id, 'amount', r.amount, 'access_id', v_access));
  return v_access;
end $$;

create or replace function public.reject_payment(p_request_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare r public.payment_requests;
begin
  perform public.require_admin();
  if p_reason is null or char_length(btrim(p_reason)) < 3 then raise exception 'reason required'; end if;
  select * into r from public.payment_requests where id = p_request_id for update;
  if not found then raise exception 'request not found'; end if;
  if r.status not in ('PENDING','UNDER_REVIEW') then raise exception 'request already processed'; end if;
  update public.payment_requests set status = 'REJECTED', rejection_reason = btrim(p_reason),
         reviewed_by = auth.uid(), reviewed_at = now() where id = r.id;
  perform public.notify_user(r.user_id, 'PAYMENT_REJECTED', 'Payment rejected', btrim(p_reason),
                             jsonb_build_object('payment_request_id', r.id));
  perform public.audit_write('PAYMENT_REJECTED', 'payment_request', r.id, jsonb_build_object('reason', btrim(p_reason)));
end $$;

create or replace function public.refund_payment(p_request_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare r public.payment_requests;
begin
  perform public.require_admin();
  select * into r from public.payment_requests where id = p_request_id for update;
  if not found or r.status <> 'APPROVED' then raise exception 'only approved payments can be refunded'; end if;
  if exists (select 1 from public.developer_earnings where payment_request_id = r.id and status = 'PAID') then
    raise exception 'developer earning already paid out; resolve manually';
  end if;
  update public.payment_requests set status = 'REFUNDED', admin_note = coalesce(p_reason, admin_note) where id = r.id;
  update public.project_access set status = 'REVOKED', revoked_at = now(), revoked_by = auth.uid()
   where payment_request_id = r.id and status = 'ACTIVE';
  update public.developer_earnings set status = 'CANCELLED' where payment_request_id = r.id;
  perform public.notify_user(r.user_id, 'ACCESS_REVOKED', 'Payment refunded', 'Access to the project was removed after a refund.',
                             jsonb_build_object('project_id', r.project_id));
  perform public.audit_write('PAYMENT_REFUNDED', 'payment_request', r.id, jsonb_build_object('reason', p_reason));
end $$;

-- ---------- admin: manual access control ----------
create or replace function public.grant_access(p_user uuid, p_project uuid, p_expires timestamptz default null, p_reason text default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
  perform public.require_admin();
  if not exists (select 1 from auth.users where id = p_user) then raise exception 'user not found'; end if;
  if not exists (select 1 from public.projects where id = p_project and deleted_at is null) then raise exception 'project not found'; end if;
  if p_expires is not null and p_expires <= now() then raise exception 'expiry must be in the future'; end if;
  if exists (select 1 from public.project_access where user_id = p_user and project_id = p_project and status = 'ACTIVE') then
    raise exception 'access already active (use extend)';
  end if;
  insert into public.project_access(user_id, project_id, granted_by, expires_at, reason)
  values (p_user, p_project, auth.uid(), p_expires, coalesce(p_reason, 'Manual grant')) returning id into v_id;
  perform public.notify_user(p_user, 'ACCESS_GRANTED', 'Access granted', 'You now have access to a project.',
                             jsonb_build_object('project_id', p_project));
  perform public.audit_write('ACCESS_GRANTED', 'project_access', v_id,
                             jsonb_build_object('user_id', p_user, 'project_id', p_project, 'expires_at', p_expires, 'reason', p_reason));
  return v_id;
end $$;

create or replace function public.revoke_access(p_access_id uuid, p_reason text default null) returns void
language plpgsql security definer set search_path = '' as $$
declare a public.project_access;
begin
  perform public.require_admin();
  select * into a from public.project_access where id = p_access_id for update;
  if not found or a.status <> 'ACTIVE' then raise exception 'active access not found'; end if;
  update public.project_access set status = 'REVOKED', revoked_at = now(), revoked_by = auth.uid(),
         reason = coalesce(p_reason, reason) where id = a.id;
  perform public.notify_user(a.user_id, 'ACCESS_REVOKED', 'Access revoked', coalesce(p_reason, 'Your access was removed.'),
                             jsonb_build_object('project_id', a.project_id));
  perform public.audit_write('ACCESS_REVOKED', 'project_access', a.id, jsonb_build_object('reason', p_reason));
end $$;

create or replace function public.extend_access(p_access_id uuid, p_new_expiry timestamptz) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  if p_new_expiry is not null and p_new_expiry <= now() then raise exception 'expiry must be in the future'; end if;
  update public.project_access set expires_at = p_new_expiry where id = p_access_id and status = 'ACTIVE';
  if not found then raise exception 'active access not found'; end if;
  perform public.audit_write('ACCESS_EXTENDED', 'project_access', p_access_id, jsonb_build_object('expires_at', p_new_expiry));
end $$;

-- ---------- projects ----------
create or replace function public.submit_project_for_review(p_project_id uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.owns_editable_project(p_project_id) then raise exception 'not allowed' using errcode = '42501'; end if;
  if not exists (select 1 from public.project_files where project_id = p_project_id and deleted_at is null) then
    raise exception 'upload at least one original file'; end if;
  if not exists (select 1 from public.project_previews where project_id = p_project_id) then
    raise exception 'add at least one preview'; end if;
  update public.projects set status = 'PENDING_REVIEW', rejection_reason = null where id = p_project_id;
  perform public.audit_write('PROJECT_SUBMITTED', 'project', p_project_id);
end $$;

create or replace function public.admin_set_project_status(p_project_id uuid, p_status public.project_status, p_reason text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare pr public.projects; v_user uuid;
begin
  perform public.require_admin();
  select * into pr from public.projects where id = p_project_id for update;
  if not found then raise exception 'project not found'; end if;
  if not ((pr.status = 'PENDING_REVIEW' and p_status in ('APPROVED','REJECTED'))
       or (pr.status in ('APPROVED','SUSPENDED') and p_status = 'PUBLISHED')
       or (pr.status = 'PUBLISHED' and p_status = 'SUSPENDED')) then
    raise exception 'invalid status change % -> %', pr.status, p_status;
  end if;
  if p_status in ('REJECTED','SUSPENDED') and (p_reason is null or char_length(btrim(p_reason)) < 3) then
    raise exception 'reason required'; end if;
  update public.projects set status = p_status, reviewed_by = auth.uid(),
         rejection_reason = case when p_status in ('REJECTED','SUSPENDED') then btrim(p_reason) else null end,
         published_at = case when p_status = 'PUBLISHED' then coalesce(published_at, now()) else published_at end
   where id = pr.id;
  select user_id into v_user from public.developer_profiles where id = pr.developer_id;
  perform public.notify_user(v_user,
    case p_status when 'REJECTED' then 'PROJECT_REJECTED' when 'PUBLISHED' then 'PROJECT_PUBLISHED' else 'PROJECT_' || p_status::text end,
    'Project ' || lower(p_status::text), '"' || pr.title || '" is now ' || lower(p_status::text) || '.',
    jsonb_build_object('project_id', pr.id));
  perform public.audit_write('PROJECT_' || p_status::text, 'project', pr.id, jsonb_build_object('reason', p_reason));
end $$;

-- ---------- developers & roles ----------
create or replace function public.apply_as_developer(p_display_name text, p_bio text default '', p_links jsonb default '[]'::jsonb)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'not authenticated' using errcode = '42501'; end if;
  if jsonb_typeof(coalesce(p_links,'[]'::jsonb)) <> 'array' or jsonb_array_length(coalesce(p_links,'[]'::jsonb)) > 10 then
    raise exception 'invalid links'; end if;
  insert into public.developer_profiles(user_id, display_name, bio, portfolio_links)
  values (auth.uid(), btrim(p_display_name), left(coalesce(p_bio,''), 500), coalesce(p_links,'[]'::jsonb))
  returning id into v_id;
  perform public.audit_write('DEVELOPER_APPLIED', 'developer_profile', v_id);
  return v_id;
exception when unique_violation then raise exception 'you already applied';
end $$;

create or replace function public.admin_review_developer(p_user_id uuid, p_approve boolean) returns void
language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
  perform public.require_admin();
  select id into v_id from public.developer_profiles where user_id = p_user_id for update;
  if not found then raise exception 'application not found'; end if;
  if p_approve then
    update public.developer_profiles set status = 'APPROVED' where id = v_id;
    insert into public.user_roles(user_id, role, granted_by) values (p_user_id, 'DEVELOPER', auth.uid()) on conflict do nothing;
    perform public.notify_user(p_user_id, 'DEVELOPER_APPROVED', 'Developer application approved', 'You can now create projects.');
  else
    update public.developer_profiles set status = 'REJECTED' where id = v_id;
    update public.user_roles set revoked_at = now() where user_id = p_user_id and role = 'DEVELOPER' and revoked_at is null;
    perform public.notify_user(p_user_id, 'DEVELOPER_REJECTED', 'Developer application declined', '');
  end if;
  perform public.audit_write(case when p_approve then 'DEVELOPER_APPROVED' else 'DEVELOPER_REJECTED' end, 'developer_profile', v_id);
end $$;

create or replace function public.grant_role(p_user uuid, p_role public.app_role) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  insert into public.user_roles(user_id, role, granted_by) values (p_user, p_role, auth.uid()) on conflict do nothing;
  perform public.audit_write('ROLE_GRANTED', 'user', p_user, jsonb_build_object('role', p_role));
end $$;

create or replace function public.revoke_role(p_user uuid, p_role public.app_role) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  if p_user = auth.uid() and p_role = 'SUPER_ADMIN' then raise exception 'you cannot remove your own super admin role'; end if;
  update public.user_roles set revoked_at = now() where user_id = p_user and role = p_role and revoked_at is null;
  perform public.audit_write('ROLE_REVOKED', 'user', p_user, jsonb_build_object('role', p_role));
end $$;

-- ---------- earnings & payouts (earnings become PAID only with a recorded payout) ----------
create or replace function public.approve_earnings(p_earning_ids uuid[]) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  update public.developer_earnings set status = 'APPROVED' where id = any(p_earning_ids) and status = 'PENDING';
  perform public.audit_write('EARNINGS_APPROVED', 'developer_earning', null, jsonb_build_object('ids', p_earning_ids));
end $$;

create or replace function public.record_payout(p_developer_id uuid, p_earning_ids uuid[], p_method text, p_reference text, p_note text default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_total numeric; v_n int; v_pid uuid;
begin
  perform public.require_admin();
  if p_reference is null or char_length(btrim(p_reference)) < 3 then raise exception 'payout reference required'; end if;
  perform 1 from public.developer_earnings
   where id = any(p_earning_ids) and developer_id = p_developer_id and status in ('PENDING','APPROVED') for update;
  select coalesce(sum(net_amount),0), count(*) into v_total, v_n from public.developer_earnings
   where id = any(p_earning_ids) and developer_id = p_developer_id and status in ('PENDING','APPROVED');
  if v_n = 0 or v_n <> coalesce(array_length(p_earning_ids,1),0) then raise exception 'invalid earnings selection'; end if;
  insert into public.developer_payouts(developer_id, amount, method, reference, note, paid_by)
  values (p_developer_id, v_total, btrim(p_method), btrim(p_reference), p_note, auth.uid()) returning id into v_pid;
  update public.developer_earnings set status = 'PAID', payout_id = v_pid where id = any(p_earning_ids);
  perform public.audit_write('PAYOUT_RECORDED', 'developer_payout', v_pid, jsonb_build_object('amount', v_total, 'reference', p_reference));
  return v_pid;
end $$;

-- ---------- support ----------
create or replace function public.close_my_ticket(p_ticket_id uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  update public.support_tickets set status = 'CLOSED', closed_at = now()
   where id = p_ticket_id and user_id = auth.uid() and status <> 'CLOSED';
  if not found then raise exception 'ticket not found'; end if;
end $$;

-- ---------- function permissions: only signed-in users may call; admin checks are inside ----------
do $$ declare f text; begin
  foreach f in array array[
    'submit_payment_request(uuid,text,date,text,text)','set_payment_under_review(uuid)','approve_payment(uuid,text)',
    'reject_payment(uuid,text)','refund_payment(uuid,text)','grant_access(uuid,uuid,timestamptz,text)',
    'revoke_access(uuid,text)','extend_access(uuid,timestamptz)','submit_project_for_review(uuid)',
    'admin_set_project_status(uuid,public.project_status,text)','apply_as_developer(text,text,jsonb)',
    'admin_review_developer(uuid,boolean)','grant_role(uuid,public.app_role)','revoke_role(uuid,public.app_role)',
    'approve_earnings(uuid[])','record_payout(uuid,uuid[],text,text,text)','close_my_ticket(uuid)'] loop
    execute format('revoke all on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated', f);
  end loop;
end $$;

-- ---------- seed: settings ----------
insert into public.app_settings(key, value, is_public) values
  ('platform_commission_percent', '20'::jsonb, false),
  ('min_app_version',             '"0.2.0"'::jsonb, true),
  ('maintenance_mode',            'false'::jsonb, true)
on conflict (key) do nothing;

-- ---------- seed: categories ----------
with g as (
  insert into public.categories(slug, name, icon, sort_order) values
    ('minecraft-packs','Minecraft Packs','grid',1), ('minecraft-skins','Minecraft Skins','face',2),
    ('discord','Discord','forum',3), ('apps-websites','Apps & Websites','code',4),
    ('graphic-design','Graphic Design','brush',5), ('other-projects','Other Projects','auto_awesome',6)
  on conflict (slug) do nothing returning id, slug)
insert into public.categories(parent_id, slug, name, sort_order)
select g.id, v.slug, v.name, v.ord from g join (values
  ('minecraft-packs','texture-packs','Texture Packs',1), ('minecraft-packs','resource-packs','Resource Packs',2),
  ('minecraft-packs','shaders','Shaders',3), ('minecraft-packs','addons','Addons',4),
  ('minecraft-packs','mods','Mods',5), ('minecraft-packs','custom-configurations','Custom Configurations',6),
  ('minecraft-skins','pvp-skins','PvP Skins',1), ('minecraft-skins','hd-skins','HD Skins',2),
  ('minecraft-skins','custom-skins','Custom Skins',3), ('minecraft-skins','skin-bundles','Skin Bundles',4),
  ('discord','discord-server-templates','Discord Server Templates',1), ('discord','discord-bot-projects','Discord Bot Projects',2),
  ('discord','discord-server-designs','Discord Server Designs',3), ('discord','discord-configurations','Discord Configurations',4),
  ('apps-websites','android-applications','Android Applications',1), ('apps-websites','website-templates','Website Templates',2),
  ('apps-websites','ui-designs','UI Designs',3), ('apps-websites','source-code-projects','Source Code Projects',4),
  ('graphic-design','logos','Logos',1), ('graphic-design','banners','Banners',2), ('graphic-design','thumbnails','Thumbnails',3),
  ('graphic-design','wallpapers','Wallpapers',4), ('graphic-design','profile-pictures','Profile Pictures',5),
  ('other-projects','custom-digital-products','Custom Digital Products',1), ('other-projects','developer-tools','Developer Tools',2),
  ('other-projects','other-creative-projects','Other Creative Projects',3)
) as v(parent, slug, name, ord) on v.parent = g.slug
on conflict (slug) do nothing;
