-- 007a: delete project, payment settings, payment review list (owner only)
drop policy if exists axoadm_qr_insert on storage.objects;
drop policy if exists axoadm_qr_delete on storage.objects;
create policy axoadm_qr_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'payment-assets' and public.is_super_admin());
create policy axoadm_qr_delete on storage.objects for delete to authenticated
  using (bucket_id = 'payment-assets' and public.is_super_admin());

-- Soft delete: hides the project everywhere but keeps payment/audit history intact.
create or replace function public.admin_delete_project(p_id uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  update public.projects set deleted_at = now(), status = 'SUSPENDED' where id = p_id and deleted_at is null;
  if not found then raise exception 'Project not found'; end if;
  perform public.audit_write('PROJECT_DELETED_BY_OWNER', 'project', p_id);
end $$;

create or replace function public.admin_save_payment_settings(
  p_upi text, p_instructions text, p_support text, p_terms text, p_qr_path text default null)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  update public.payment_settings set
    upi_id = left(btrim(coalesce(p_upi, '')), 100),
    instructions = left(coalesce(p_instructions, ''), 2000),
    support_contact = left(btrim(coalesce(p_support, '')), 200),
    terms = left(coalesce(p_terms, ''), 3000),
    qr_path = coalesce(p_qr_path, qr_path),
    updated_by = auth.uid()
  where id = 1;
  perform public.audit_write('PAYMENT_SETTINGS_UPDATED', 'payment_settings', null);
end $$;

create or replace function public.admin_list_payments(p_status text default null)
returns table(request_id uuid, email text, display_name text, project_title text, amount numeric,
              transaction_ref text, payment_date date, message text, screenshot_path text,
              status text, admin_note text, rejection_reason text, created_at timestamptz)
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  return query
    select r.id, u.email::text, pr.display_name, p.title, r.amount, r.transaction_ref, r.payment_date,
           r.message, r.screenshot_path, r.status::text, r.admin_note, r.rejection_reason, r.created_at
      from public.payment_requests r
      join auth.users u on u.id = r.user_id
      join public.profiles pr on pr.id = r.user_id
      join public.projects p on p.id = r.project_id
     where (p_status is null or r.status::text = p_status)
     order by r.created_at desc limit 100;
end $$;

revoke all on function public.admin_delete_project(uuid) from public, anon;
revoke all on function public.admin_save_payment_settings(text,text,text,text,text) from public, anon;
revoke all on function public.admin_list_payments(text) from public, anon;
grant execute on function public.admin_delete_project(uuid) to authenticated;
grant execute on function public.admin_save_payment_settings(text,text,text,text,text) to authenticated;
grant execute on function public.admin_list_payments(text) to authenticated;
