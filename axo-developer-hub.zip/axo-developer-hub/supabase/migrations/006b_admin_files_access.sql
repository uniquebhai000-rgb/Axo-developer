-- 006b: owner-only admin: files, previews, find users, lock/unlock access
create or replace function public.admin_register_file(p_project uuid, p_path text, p_file_name text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare o record; v uuid;
begin
  perform public.require_admin();
  if p_path not like p_project::text || '/%' then raise exception 'Bad file path'; end if;
  select name, metadata into o from storage.objects where bucket_id = 'originals' and name = p_path;
  if not found then raise exception 'File was not uploaded'; end if;
  insert into public.project_files(project_id, file_name, storage_path, size_bytes, mime_type)
  values (p_project, left(btrim(p_file_name), 200), p_path,
          greatest(coalesce((o.metadata->>'size')::bigint, 1), 1), o.metadata->>'mimetype')
  returning id into v;
  perform public.audit_write('FILE_ADDED_BY_OWNER', 'project', p_project, jsonb_build_object('file', p_file_name));
  return v;
end $$;

create or replace function public.admin_delete_file(p_file uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  update public.project_files set deleted_at = now() where id = p_file and deleted_at is null;
  if not found then raise exception 'File not found'; end if;
  perform public.audit_write('FILE_REMOVED_BY_OWNER', 'project_file', p_file);
end $$;

create or replace function public.admin_add_preview(p_project uuid, p_path text, p_make_cover boolean default true)
returns void language plpgsql security definer set search_path = '' as $$
declare v_no_cover boolean;
begin
  perform public.require_admin();
  if p_path not like p_project::text || '/%' then raise exception 'Bad file path'; end if;
  if not exists (select 1 from storage.objects where bucket_id = 'previews' and name = p_path) then
    raise exception 'Image was not uploaded'; end if;
  select cover_path is null into v_no_cover from public.projects where id = p_project;
  insert into public.project_previews(project_id, kind, storage_path, sort_order, is_cover)
  values (p_project, 'IMAGE', p_path,
          coalesce((select max(sort_order) + 1 from public.project_previews where project_id = p_project), 0),
          p_make_cover or coalesce(v_no_cover, false));
  if p_make_cover or coalesce(v_no_cover, false) then
    update public.projects set cover_path = p_path where id = p_project;
    update public.project_previews set is_cover = false where project_id = p_project and storage_path <> p_path;
  end if;
end $$;

create or replace function public.admin_find_user(p_query text)
returns table(user_id uuid, email text, display_name text, account_code text)
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  return query
    select u.id, u.email::text, pr.display_name, pr.account_code
      from auth.users u join public.profiles pr on pr.id = u.id
     where lower(u.email) like lower(btrim(p_query)) || '%'
        or upper(pr.account_code) = upper(btrim(p_query))
        or pr.display_name ilike '%' || btrim(p_query) || '%'
     order by u.created_at desc limit 20;
end $$;

create or replace function public.admin_list_access(p_project uuid)
returns table(access_id uuid, email text, display_name text, status text, expires_at timestamptz, granted_at timestamptz)
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  return query
    select a.id, u.email::text, pr.display_name, a.status::text, a.expires_at, a.granted_at
      from public.project_access a
      join auth.users u on u.id = a.user_id
      join public.profiles pr on pr.id = a.user_id
     where a.project_id = p_project
     order by a.granted_at desc;
end $$;

create or replace function public.admin_unlock_user(p_user uuid, p_project uuid, p_days int default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_exp timestamptz; v_id uuid;
begin
  perform public.require_admin();
  v_exp := case when p_days is null then null else now() + make_interval(days => p_days) end;
  select id into v_id from public.project_access where user_id = p_user and project_id = p_project and status = 'ACTIVE';
  if v_id is not null then
    perform public.extend_access(v_id, v_exp);
    return v_id;
  end if;
  return public.grant_access(p_user, p_project, v_exp, 'Unlocked by owner');
end $$;

do $$ declare f text; begin
  foreach f in array array[
    'admin_register_file(uuid,text,text)','admin_delete_file(uuid)','admin_add_preview(uuid,text,boolean)',
    'admin_find_user(text)','admin_list_access(uuid)','admin_unlock_user(uuid,uuid,int)'] loop
    execute format('revoke all on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated', f);
  end loop;
end $$;
