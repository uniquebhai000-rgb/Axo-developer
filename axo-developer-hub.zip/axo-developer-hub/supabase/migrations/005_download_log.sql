-- AXO LOCK: server-only download logging (called by the Edge Function with the service role)
create or replace function public.log_download(
  p_user uuid, p_project uuid, p_file uuid, p_access uuid, p_outcome text, p_reason text, p_ip text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  insert into public.download_logs(user_id, project_id, file_id, access_id, outcome, reason, ip)
  values (p_user, p_project, p_file, p_access, p_outcome, p_reason, p_ip);
  if p_outcome = 'GRANTED' then
    update public.projects set download_count = download_count + 1 where id = p_project;
  end if;
end $$;
revoke all on function public.log_download(uuid,uuid,uuid,uuid,text,text,text) from public, anon, authenticated;
grant execute on function public.log_download(uuid,uuid,uuid,uuid,text,text,text) to service_role;
