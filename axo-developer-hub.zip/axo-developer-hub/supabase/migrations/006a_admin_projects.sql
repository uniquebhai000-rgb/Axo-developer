-- 006a: owner-only admin: storage upload rights + project functions
drop policy if exists axoadm_orig_insert on storage.objects;
drop policy if exists axoadm_orig_delete on storage.objects;
drop policy if exists axoadm_prev_insert on storage.objects;
drop policy if exists axoadm_prev_delete on storage.objects;
create policy axoadm_orig_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'originals' and public.is_super_admin());
create policy axoadm_orig_delete on storage.objects for delete to authenticated
  using (bucket_id = 'originals' and public.is_super_admin());
create policy axoadm_prev_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'previews' and public.is_super_admin());
create policy axoadm_prev_delete on storage.objects for delete to authenticated
  using (bucket_id = 'previews' and public.is_super_admin());

create or replace function public.admin_dev_id() returns uuid
language plpgsql security definer set search_path = '' as $$
declare v uuid;
begin
  perform public.require_admin();
  select id into v from public.developer_profiles where user_id = auth.uid();
  if v is null then
    insert into public.developer_profiles(user_id, display_name, status)
    values (auth.uid(), 'AXO Studio', 'APPROVED') returning id into v;
  else
    update public.developer_profiles set status = 'APPROVED' where id = v and status <> 'APPROVED';
  end if;
  return v;
end $$;

create or replace function public.admin_create_project(
  p_title text, p_description text, p_price numeric, p_category_id uuid, p_publish boolean default false)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v uuid; dev uuid;
begin
  perform public.require_admin();
  if char_length(btrim(coalesce(p_title,''))) not between 3 and 80 then raise exception 'Title must be 3-80 characters'; end if;
  if p_price is null or p_price < 0 or p_price > 1000000 then raise exception 'Invalid price'; end if;
  if not exists (select 1 from public.categories where id = p_category_id) then raise exception 'Pick a category'; end if;
  dev := public.admin_dev_id();
  insert into public.projects(developer_id, category_id, title, description, price_inr, status, published_at)
  values (dev, p_category_id, btrim(p_title), left(coalesce(p_description,''), 5000), p_price,
          case when p_publish then 'PUBLISHED'::public.project_status else 'DRAFT'::public.project_status end,
          case when p_publish then now() else null end)
  returning id into v;
  perform public.audit_write('PROJECT_CREATED_BY_OWNER', 'project', v, jsonb_build_object('price', p_price));
  return v;
end $$;

create or replace function public.admin_update_project(
  p_id uuid, p_title text default null, p_description text default null,
  p_price numeric default null, p_status text default null)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  if p_price is not null and (p_price < 0 or p_price > 1000000) then raise exception 'Invalid price'; end if;
  if p_title is not null and char_length(btrim(p_title)) not between 3 and 80 then raise exception 'Title must be 3-80 characters'; end if;
  if p_status is not null and p_status not in ('DRAFT','PUBLISHED','SUSPENDED') then raise exception 'Invalid status'; end if;
  update public.projects set
    title       = coalesce(nullif(btrim(p_title), ''), title),
    description = coalesce(left(p_description, 5000), description),
    price_inr   = coalesce(p_price, price_inr),
    status      = coalesce(p_status::public.project_status, status),
    published_at = case when p_status = 'PUBLISHED' and published_at is null then now() else published_at end
  where id = p_id and deleted_at is null;
  if not found then raise exception 'Project not found'; end if;
  perform public.audit_write('PROJECT_UPDATED_BY_OWNER', 'project', p_id,
    jsonb_build_object('price', p_price, 'status', p_status));
end $$;

revoke all on function public.admin_dev_id() from public, anon, authenticated;
revoke all on function public.admin_create_project(text,text,numeric,uuid,boolean) from public, anon;
revoke all on function public.admin_update_project(uuid,text,text,numeric,text) from public, anon;
grant execute on function public.admin_create_project(text,text,numeric,uuid,boolean) to authenticated;
grant execute on function public.admin_update_project(uuid,text,text,numeric,text) to authenticated;
