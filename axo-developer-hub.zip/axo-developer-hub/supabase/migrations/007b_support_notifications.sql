-- 007b: support tickets + notifications helpers
create or replace function public.create_ticket(p_category text, p_subject text, p_body text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v uuid;
begin
  if auth.uid() is null then raise exception 'not authenticated' using errcode = '42501'; end if;
  if char_length(btrim(coalesce(p_body, ''))) < 1 then raise exception 'Write a message'; end if;
  if (select count(*) from public.support_tickets
       where user_id = auth.uid() and created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Too many tickets, try again later';
  end if;
  insert into public.support_tickets(user_id, category, subject)
  values (auth.uid(), btrim(p_category), btrim(p_subject)) returning id into v;
  insert into public.support_messages(ticket_id, sender_id, body)
  values (v, auth.uid(), left(btrim(p_body), 3000));
  return v;
end $$;

create or replace function public.admin_list_tickets()
returns table(ticket_id uuid, email text, display_name text, category text, subject text, status text, created_at timestamptz)
language plpgsql security definer set search_path = '' as $$
begin
  perform public.require_admin();
  return query
    select t.id, u.email::text, pr.display_name, t.category, t.subject, t.status::text, t.created_at
      from public.support_tickets t
      join auth.users u on u.id = t.user_id
      join public.profiles pr on pr.id = t.user_id
     order by (t.status = 'CLOSED'), t.created_at desc limit 100;
end $$;

create or replace function public.mark_notifications_read() returns void
language sql security definer set search_path = '' as $$
  update public.notifications set read_at = now() where user_id = auth.uid() and read_at is null $$;

revoke all on function public.create_ticket(text,text,text) from public, anon;
revoke all on function public.admin_list_tickets() from public, anon;
revoke all on function public.mark_notifications_read() from public, anon;
grant execute on function public.create_ticket(text,text,text) to authenticated;
grant execute on function public.admin_list_tickets() to authenticated;
grant execute on function public.mark_notifications_read() to authenticated;
