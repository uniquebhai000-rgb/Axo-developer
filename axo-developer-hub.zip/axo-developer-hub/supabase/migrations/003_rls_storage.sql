-- AXO DEVELOPER HUB - Phase 3 (2/3): Row Level Security + private storage
-- Run AFTER 002_tables.sql. Safe to re-run.

-- ---------- access helpers (SECURITY DEFINER: no RLS recursion) ----------
create or replace function public.owns_project(pid uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.projects p join public.developer_profiles d on d.id = p.developer_id
                 where p.id = pid and d.user_id = auth.uid()) $$;

create or replace function public.owns_editable_project(pid uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.projects p join public.developer_profiles d on d.id = p.developer_id
                 where p.id = pid and d.user_id = auth.uid() and p.status in ('DRAFT','REJECTED')
                   and p.deleted_at is null) $$;

create or replace function public.project_visible(pid uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select pid is not null and exists (
    select 1 from public.projects p where p.id = pid
      and ((p.status = 'PUBLISHED' and p.deleted_at is null) or public.owns_project(pid) or public.is_super_admin())) $$;

create or replace function public.my_dev_id() returns uuid
language sql stable security definer set search_path = '' as $$
  select id from public.developer_profiles
   where user_id = auth.uid() and status = 'APPROVED' and deleted_at is null $$;

create or replace function public.ticket_visible(tid uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.support_tickets t where t.id = tid
                 and (t.user_id = auth.uid() or public.is_super_admin())) $$;

create or replace function public.has_active_access(p_user uuid, p_project uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.project_access
                 where user_id = p_user and project_id = p_project and status = 'ACTIVE'
                   and revoked_at is null and (expires_at is null or expires_at > now())) $$;

revoke all on function public.has_active_access(uuid, uuid) from public, anon, authenticated;
grant execute on function public.has_active_access(uuid, uuid) to service_role;
revoke all on function public.safe_uuid(text), public.touch_updated_at() from public, anon;
grant execute on function public.safe_uuid(text) to authenticated, service_role;
revoke all on function public.is_super_admin(), public.owns_project(uuid), public.owns_editable_project(uuid),
  public.project_visible(uuid), public.my_dev_id(), public.ticket_visible(uuid) from public, anon;
grant execute on function public.is_super_admin(), public.owns_project(uuid), public.owns_editable_project(uuid),
  public.project_visible(uuid), public.my_dev_id(), public.ticket_visible(uuid) to authenticated;

-- ---------- drop previous axo_ policies (re-runnable) ----------
do $$ declare r record; begin
  for r in select schemaname, tablename, policyname from pg_policies
           where policyname like 'axo\_%' and schemaname in ('public','storage') loop
    execute format('drop policy %I on %I.%I', r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

-- ---------- lock everything, then grant only what's needed ----------
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

do $$ declare t text; begin
  foreach t in array array['profiles','user_roles','developer_profiles','categories','projects','project_previews',
    'project_files','payment_requests','payment_settings','project_access','download_logs','developer_earnings',
    'developer_payouts','notifications','support_tickets','support_messages','audit_logs','app_settings','favorites'] loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- profiles / roles: own row, plus admin read
grant select on public.profiles, public.user_roles to authenticated;
create policy axo_profiles_admin on public.profiles for select to authenticated using (public.is_super_admin());
create policy axo_roles_admin    on public.user_roles for select to authenticated using (public.is_super_admin());

-- developer_profiles
grant select on public.developer_profiles to authenticated;
grant update (display_name, bio, portfolio_links, avatar_path) on public.developer_profiles to authenticated;
create policy axo_dev_select on public.developer_profiles for select to authenticated
  using (user_id = auth.uid() or (status = 'APPROVED' and deleted_at is null) or public.is_super_admin());
create policy axo_dev_update_own on public.developer_profiles for update to authenticated
  using (user_id = auth.uid() and status in ('PENDING','APPROVED')) with check (user_id = auth.uid());

-- categories (admin edits go through service-side code)
grant select on public.categories to authenticated;
create policy axo_cat_select on public.categories for select to authenticated
  using ((is_active and deleted_at is null) or public.is_super_admin());

-- projects: developers can only create/edit their OWN drafts. status/price approval fields are not grantable.
grant select on public.projects to authenticated;
grant insert (developer_id, category_id, title, description, price_inr, cover_path, features, compatibility, version)
  on public.projects to authenticated;
grant update (category_id, title, description, price_inr, cover_path, features, compatibility, version, deleted_at)
  on public.projects to authenticated;
create policy axo_proj_select on public.projects for select to authenticated
  using ((status = 'PUBLISHED' and deleted_at is null) or public.owns_project(id) or public.is_super_admin());
create policy axo_proj_insert on public.projects for insert to authenticated
  with check (developer_id = public.my_dev_id());
create policy axo_proj_update on public.projects for update to authenticated
  using (public.owns_editable_project(id)) with check (developer_id = public.my_dev_id());

-- previews (safe, watermarked assets only)
grant select, delete on public.project_previews to authenticated;
grant insert (project_id, kind, storage_path, sort_order, is_cover) on public.project_previews to authenticated;
grant update (sort_order, is_cover) on public.project_previews to authenticated;
create policy axo_prev_select on public.project_previews for select to authenticated using (public.project_visible(project_id));
create policy axo_prev_insert on public.project_previews for insert to authenticated with check (public.owns_editable_project(project_id));
create policy axo_prev_update on public.project_previews for update to authenticated
  using (public.owns_editable_project(project_id)) with check (public.owns_editable_project(project_id));
create policy axo_prev_delete on public.project_previews for delete to authenticated using (public.owns_editable_project(project_id));

-- ORIGINAL FILES: visible only to the owning developer and admin. Customers can NEVER read this table.
grant select, delete on public.project_files to authenticated;
grant insert (project_id, file_name, storage_path, size_bytes, sha256, mime_type, version) on public.project_files to authenticated;
create policy axo_files_select on public.project_files for select to authenticated
  using (public.owns_project(project_id) or public.is_super_admin());
create policy axo_files_insert on public.project_files for insert to authenticated with check (public.owns_editable_project(project_id));
create policy axo_files_delete on public.project_files for delete to authenticated using (public.owns_editable_project(project_id));

-- payments & access: read-only for owners; all writes go through SECURITY DEFINER functions
grant select on public.payment_requests to authenticated;
create policy axo_pay_select on public.payment_requests for select to authenticated using (user_id = auth.uid() or public.is_super_admin());

grant select on public.payment_settings to authenticated;
create policy axo_paysettings_select on public.payment_settings for select to authenticated using (true);

grant select on public.project_access to authenticated;
create policy axo_access_select on public.project_access for select to authenticated using (user_id = auth.uid() or public.is_super_admin());

grant select on public.download_logs to authenticated;
create policy axo_dl_select on public.download_logs for select to authenticated using (user_id = auth.uid() or public.is_super_admin());

grant select on public.developer_earnings, public.developer_payouts to authenticated;
create policy axo_earn_select on public.developer_earnings for select to authenticated
  using (public.is_super_admin() or exists (select 1 from public.developer_profiles d where d.id = developer_id and d.user_id = auth.uid()));
create policy axo_payout_select on public.developer_payouts for select to authenticated
  using (public.is_super_admin() or exists (select 1 from public.developer_profiles d where d.id = developer_id and d.user_id = auth.uid()));

-- notifications
grant select, delete on public.notifications to authenticated;
grant update (read_at) on public.notifications to authenticated;
create policy axo_notif_select on public.notifications for select to authenticated using (user_id = auth.uid());
create policy axo_notif_update on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy axo_notif_delete on public.notifications for delete to authenticated using (user_id = auth.uid());

-- support
grant select on public.support_tickets, public.support_messages to authenticated;
grant insert (category, subject) on public.support_tickets to authenticated;
grant insert (ticket_id, body, attachment_path) on public.support_messages to authenticated;
create policy axo_ticket_select on public.support_tickets for select to authenticated using (user_id = auth.uid() or public.is_super_admin());
create policy axo_ticket_insert on public.support_tickets for insert to authenticated with check (user_id = auth.uid());
create policy axo_msg_select on public.support_messages for select to authenticated using (public.ticket_visible(ticket_id));
create policy axo_msg_insert on public.support_messages for insert to authenticated
  with check (sender_id = auth.uid() and public.ticket_visible(ticket_id)
              and exists (select 1 from public.support_tickets t where t.id = ticket_id and t.status <> 'CLOSED'));

-- audit log: admin read only, nobody writes directly
grant select on public.audit_logs to authenticated;
create policy axo_audit_select on public.audit_logs for select to authenticated using (public.is_super_admin());

-- app settings: public keys for everyone, the rest admin only
grant select on public.app_settings to authenticated;
create policy axo_settings_select on public.app_settings for select to authenticated using (is_public or public.is_super_admin());

-- favorites
grant select, insert, delete on public.favorites to authenticated;
create policy axo_fav_select on public.favorites for select to authenticated using (user_id = auth.uid());
create policy axo_fav_insert on public.favorites for insert to authenticated
  with check (user_id = auth.uid() and public.project_visible(project_id));
create policy axo_fav_delete on public.favorites for delete to authenticated using (user_id = auth.uid());

-- ======================= STORAGE =======================
-- ORIGINALS: private bucket with NO client policies. Only Edge Functions (service role) touch it.
-- Supabase free plan caps uploads at 50 MB per file; raise limits on a paid plan.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
 ('originals',          'originals',          false, 52428800, array['application/zip','application/x-zip-compressed','application/vnd.android.package-archive','application/pdf','application/json','application/x-7z-compressed','application/gzip','application/octet-stream','image/png','image/jpeg']),
 ('previews',           'previews',           false, 10485760, array['image/png','image/jpeg','image/webp','video/mp4','application/pdf']),
 ('avatars',            'avatars',            false, 2097152,  array['image/png','image/jpeg','image/webp']),
 ('payment-proofs',     'payment-proofs',     false, 5242880,  array['image/png','image/jpeg','image/webp']),
 ('support-attachments','support-attachments',false, 5242880,  array['image/png','image/jpeg','image/webp']),
 ('payment-assets',     'payment-assets',     false, 2097152,  array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- previews: path = <project_id>/<file>
create policy axo_st_prev_select on storage.objects for select to authenticated
  using (bucket_id = 'previews' and public.project_visible(public.safe_uuid((storage.foldername(name))[1])));
create policy axo_st_prev_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'previews' and public.owns_editable_project(public.safe_uuid((storage.foldername(name))[1])));
create policy axo_st_prev_delete on storage.objects for delete to authenticated
  using (bucket_id = 'previews' and public.owns_editable_project(public.safe_uuid((storage.foldername(name))[1])));

-- avatars: path = <user_id>/<file>
create policy axo_st_av_select on storage.objects for select to authenticated using (bucket_id = 'avatars');
create policy axo_st_av_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy axo_st_av_update on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy axo_st_av_delete on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- payment proofs + support attachments: owner uploads/reads own folder, admin reads all
create policy axo_st_proof_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'payment-proofs' and (storage.foldername(name))[1] = auth.uid()::text);
create policy axo_st_proof_select on storage.objects for select to authenticated
  using (bucket_id = 'payment-proofs' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_super_admin()));
create policy axo_st_sup_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'support-attachments' and (storage.foldername(name))[1] = auth.uid()::text);
create policy axo_st_sup_select on storage.objects for select to authenticated
  using (bucket_id = 'support-attachments' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_super_admin()));

-- payment QR image: any signed-in user may read it
create policy axo_st_qr_select on storage.objects for select to authenticated using (bucket_id = 'payment-assets');
