-- AXO DEVELOPER HUB - Phase 3 (1/3): tables, enums, helpers
-- Run AFTER 001_profiles_roles.sql

-- Re-define the signup trigger without pgcrypto dependency (safe if 001 was already run)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
declare code text; tries int := 0; nm text;
begin
  nm := left(btrim(coalesce(new.raw_user_meta_data->>'display_name','')), 40);
  loop
    code := 'AXO-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,8));
    begin
      insert into public.profiles(id, account_code, display_name) values (new.id, code, nm);
      exit;
    exception when unique_violation then
      tries := tries + 1;
      if tries > 5 then raise; end if;
    end;
  end loop;
  insert into public.user_roles(user_id, role) values (new.id, 'CUSTOMER') on conflict do nothing;
  return new;
end $$;

-- ---------- enums ----------
do $$ begin create type public.project_status as enum ('DRAFT','PENDING_REVIEW','APPROVED','REJECTED','PUBLISHED','SUSPENDED'); exception when duplicate_object then null; end $$;
do $$ begin create type public.payment_status as enum ('PENDING','UNDER_REVIEW','APPROVED','REJECTED','REFUNDED'); exception when duplicate_object then null; end $$;
do $$ begin create type public.access_status  as enum ('ACTIVE','REVOKED','EXPIRED'); exception when duplicate_object then null; end $$;
do $$ begin create type public.earning_status as enum ('PENDING','APPROVED','PAID','CANCELLED'); exception when duplicate_object then null; end $$;
do $$ begin create type public.ticket_status  as enum ('OPEN','ANSWERED','CLOSED'); exception when duplicate_object then null; end $$;
do $$ begin create type public.dev_status     as enum ('PENDING','APPROVED','REJECTED','SUSPENDED'); exception when duplicate_object then null; end $$;
do $$ begin create type public.preview_kind  as enum ('IMAGE','VIDEO','DOCUMENT'); exception when duplicate_object then null; end $$;

-- ---------- helpers ----------
create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create or replace function public.is_super_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.user_roles
                 where user_id = auth.uid() and role = 'SUPER_ADMIN' and revoked_at is null) $$;

create or replace function public.safe_uuid(t text) returns uuid
language plpgsql immutable as $$
begin return t::uuid; exception when others then return null; end $$;

-- ---------- 3. developer_profiles ----------
create table if not exists public.developer_profiles (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null unique references auth.users(id) on delete cascade,
  display_name       text not null check (char_length(display_name) between 2 and 40),
  bio                text not null default '' check (char_length(bio) <= 500),
  portfolio_links    jsonb not null default '[]'::jsonb,
  avatar_path        text,
  status             public.dev_status not null default 'PENDING',
  commission_percent numeric(5,2) check (commission_percent between 0 and 100),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  deleted_at         timestamptz
);

-- ---------- 4. categories ----------
create table if not exists public.categories (
  id         uuid primary key default gen_random_uuid(),
  parent_id  uuid references public.categories(id) on delete restrict,
  slug       text not null unique,
  name       text not null,
  icon       text,
  sort_order int not null default 0,
  is_active  boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
create index if not exists categories_parent_idx on public.categories(parent_id, sort_order);

-- ---------- 5. projects ----------
create table if not exists public.projects (
  id               uuid primary key default gen_random_uuid(),
  developer_id     uuid not null references public.developer_profiles(id) on delete restrict,
  category_id      uuid not null references public.categories(id),
  title            text not null check (char_length(title) between 3 and 80),
  description      text not null default '' check (char_length(description) <= 5000),
  price_inr        numeric(10,2) not null default 0 check (price_inr >= 0),
  cover_path       text,
  features         jsonb not null default '[]'::jsonb,
  compatibility    text not null default '',
  version          text not null default '1.0.0',
  status           public.project_status not null default 'DRAFT',
  rejection_reason text,
  reviewed_by      uuid references auth.users(id),
  published_at     timestamptz,
  download_count   int not null default 0,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz
);
create index if not exists projects_status_idx on public.projects(status, published_at desc);
create index if not exists projects_dev_idx on public.projects(developer_id);
create index if not exists projects_cat_idx on public.projects(category_id);

-- ---------- 6. project_previews (watermarked / low-res only) ----------
create table if not exists public.project_previews (
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid not null references public.projects(id) on delete cascade,
  kind         public.preview_kind not null default 'IMAGE',
  storage_path text not null,
  sort_order   int not null default 0,
  is_cover     boolean not null default false,
  created_at   timestamptz not null default now(),
  constraint preview_path_in_project check (storage_path like project_id::text || '/%')
);
create index if not exists previews_project_idx on public.project_previews(project_id, sort_order);

-- ---------- 7. project_files (ORIGINALS - never exposed to clients) ----------
create table if not exists public.project_files (
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid not null references public.projects(id) on delete cascade,
  file_name    text not null check (char_length(file_name) between 1 and 200),
  storage_path text not null,
  size_bytes   bigint not null check (size_bytes > 0),
  sha256       text,
  mime_type    text,
  version      text not null default '1.0.0',
  created_at   timestamptz not null default now(),
  deleted_at   timestamptz,
  constraint file_path_in_project check (storage_path like project_id::text || '/%')
);
create index if not exists files_project_idx on public.project_files(project_id);

-- ---------- 9. payment_settings (single row) ----------
create table if not exists public.payment_settings (
  id              int primary key default 1 check (id = 1),
  upi_id          text not null default '',
  qr_path         text,
  instructions    text not null default '',
  support_contact text not null default '',
  terms           text not null default '',
  updated_by      uuid references auth.users(id),
  updated_at      timestamptz not null default now()
);
insert into public.payment_settings(id) values (1) on conflict do nothing;

-- ---------- 8. payment_requests ----------
create table if not exists public.payment_requests (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid not null references auth.users(id) on delete restrict,
  project_id       uuid not null references public.projects(id) on delete restrict,
  amount           numeric(10,2) not null check (amount >= 0),   -- copied from projects.price_inr on the server
  transaction_ref  text not null check (char_length(transaction_ref) between 6 and 40),
  payment_date     date not null,
  screenshot_path  text,
  message          text check (char_length(message) <= 500),
  status           public.payment_status not null default 'PENDING',
  admin_note       text,
  rejection_reason text,
  reviewed_by      uuid references auth.users(id),
  reviewed_at      timestamptz,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists pay_user_idx on public.payment_requests(user_id, created_at desc);
create index if not exists pay_status_idx on public.payment_requests(status, created_at);
-- one open request per customer+project, and a transaction reference can't be reused
create unique index if not exists uq_pay_open_per_project on public.payment_requests(user_id, project_id)
  where status in ('PENDING','UNDER_REVIEW');
create unique index if not exists uq_pay_txn_ref on public.payment_requests(lower(transaction_ref))
  where status in ('PENDING','UNDER_REVIEW','APPROVED');

-- ---------- 10. project_access ----------
create table if not exists public.project_access (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null references auth.users(id) on delete cascade,
  project_id         uuid not null references public.projects(id) on delete cascade,
  status             public.access_status not null default 'ACTIVE',
  granted_by         uuid references auth.users(id),
  granted_at         timestamptz not null default now(),
  expires_at         timestamptz,
  revoked_at         timestamptz,
  revoked_by         uuid references auth.users(id),
  payment_request_id uuid references public.payment_requests(id),
  reason             text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create unique index if not exists uq_access_active on public.project_access(user_id, project_id) where status = 'ACTIVE';
create index if not exists access_user_idx on public.project_access(user_id);
create index if not exists access_project_idx on public.project_access(project_id);

-- ---------- 11. download_logs ----------
create table if not exists public.download_logs (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references auth.users(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  file_id    uuid references public.project_files(id) on delete set null,
  access_id  uuid references public.project_access(id) on delete set null,
  outcome    text not null check (outcome in ('GRANTED','DENIED')),
  reason     text,
  ip         text,
  created_at timestamptz not null default now()
);
create index if not exists dl_user_idx on public.download_logs(user_id, created_at desc);
create index if not exists dl_project_idx on public.download_logs(project_id, created_at desc);

-- ---------- 13. developer_payouts (created before earnings) ----------
create table if not exists public.developer_payouts (
  id           uuid primary key default gen_random_uuid(),
  developer_id uuid not null references public.developer_profiles(id) on delete restrict,
  amount       numeric(12,2) not null check (amount > 0),
  method       text not null check (char_length(method) between 2 and 40),
  reference    text not null check (char_length(reference) between 3 and 80),   -- real payout reference is mandatory
  note         text,
  paid_by      uuid not null references auth.users(id),
  paid_at      timestamptz not null default now(),
  created_at   timestamptz not null default now()
);
create index if not exists payouts_dev_idx on public.developer_payouts(developer_id, paid_at desc);

-- ---------- 12. developer_earnings ----------
create table if not exists public.developer_earnings (
  id                 uuid primary key default gen_random_uuid(),
  developer_id       uuid not null references public.developer_profiles(id) on delete restrict,
  project_id         uuid not null references public.projects(id) on delete restrict,
  payment_request_id uuid not null unique references public.payment_requests(id) on delete restrict,
  gross_amount       numeric(10,2) not null,
  commission_percent numeric(5,2) not null,
  commission_amount  numeric(10,2) not null,
  net_amount         numeric(10,2) not null,
  status             public.earning_status not null default 'PENDING',
  payout_id          uuid references public.developer_payouts(id),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  -- an earning can only be PAID when a recorded payout exists
  constraint paid_needs_payout check (status <> 'PAID' or payout_id is not null)
);
create index if not exists earn_dev_idx on public.developer_earnings(developer_id, created_at desc);

-- ---------- 14. notifications ----------
create table if not exists public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  type       text not null,
  title      text not null,
  body       text not null default '',
  data       jsonb not null default '{}'::jsonb,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notif_user_idx on public.notifications(user_id, created_at desc);

-- ---------- 15. support_tickets (+ messages) ----------
create table if not exists public.support_tickets (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  category   text not null check (char_length(category) between 2 and 40),
  subject    text not null check (char_length(subject) between 3 and 120),
  status     public.ticket_status not null default 'OPEN',
  closed_at  timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists tickets_user_idx on public.support_tickets(user_id, created_at desc);

create table if not exists public.support_messages (
  id              uuid primary key default gen_random_uuid(),
  ticket_id       uuid not null references public.support_tickets(id) on delete cascade,
  sender_id       uuid not null default auth.uid() references auth.users(id),
  body            text not null check (char_length(body) between 1 and 3000),
  attachment_path text,
  is_staff        boolean not null default false,
  created_at      timestamptz not null default now()
);
create index if not exists msgs_ticket_idx on public.support_messages(ticket_id, created_at);

-- ---------- 16. audit_logs (append-only) ----------
create table if not exists public.audit_logs (
  id          bigint generated always as identity primary key,
  actor_id    uuid,
  action      text not null,
  entity_type text not null,
  entity_id   uuid,
  details     jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);
create index if not exists audit_entity_idx on public.audit_logs(entity_type, entity_id);
create index if not exists audit_created_idx on public.audit_logs(created_at desc);

-- ---------- 17. app_settings ----------
create table if not exists public.app_settings (
  key        text primary key,
  value      jsonb not null,
  is_public  boolean not null default false,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

-- ---------- 18. favorites ----------
create table if not exists public.favorites (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, project_id)
);

-- ---------- updated_at triggers ----------
do $$ declare t text; begin
  foreach t in array array['developer_profiles','categories','projects','payment_requests','project_access',
                           'developer_earnings','support_tickets','payment_settings'] loop
    execute format('drop trigger if exists trg_touch on public.%I', t);
    execute format('create trigger trg_touch before update on public.%I for each row execute function public.touch_updated_at()', t);
  end loop;
end $$;

-- support: mark staff messages and keep ticket status in sync
create or replace function public.support_message_before() returns trigger
language plpgsql security definer set search_path = '' as $$
begin new.is_staff := public.is_super_admin(); return new; end $$;
drop trigger if exists trg_support_before on public.support_messages;
create trigger trg_support_before before insert on public.support_messages
  for each row execute function public.support_message_before();

create or replace function public.support_message_after() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  update public.support_tickets
     set status = case when new.is_staff then 'ANSWERED'::public.ticket_status else 'OPEN'::public.ticket_status end
   where id = new.ticket_id and status <> 'CLOSED';
  return new;
end $$;
drop trigger if exists trg_support_after on public.support_messages;
create trigger trg_support_after after insert on public.support_messages
  for each row execute function public.support_message_after();
