// AXO LOCK - secure download gate. Every download goes through these checks:
// signed-in user -> rate limit -> project published -> ACTIVE, non-expired access -> file belongs to project
// -> 60 second signed URL -> logged. Original storage paths are never returned.
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Content-Type": "application/json",
};
const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: cors });
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json(405, { error: "method_not_allowed" });
  try {
    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false } },
    );

    // 1. authenticate (role is never taken from the client)
    const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    if (!token) return json(401, { error: "unauthorized" });
    const { data: u, error: ue } = await admin.auth.getUser(token);
    if (ue || !u?.user) return json(401, { error: "unauthorized" });
    const uid = u.user.id;
    const ip = (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || null;

    // 2. validate input
    let body: any;
    try { body = await req.json(); } catch { return json(400, { error: "bad_request" }); }
    const action = body?.action;
    const projectId = String(body?.project_id ?? "");
    const fileId = body?.file_id ? String(body.file_id) : null;
    if (!["list", "download"].includes(action) || !UUID.test(projectId) || (fileId && !UUID.test(fileId))) {
      return json(400, { error: "bad_request" });
    }

    const deny = async (reason: string, status = 403) => {
      await admin.rpc("log_download", {
        p_user: uid, p_project: projectId, p_file: null, p_access: null,
        p_outcome: "DENIED", p_reason: reason, p_ip: ip,
      });
      return json(status, { error: "forbidden" });
    };

    // 3. rate limit: 10 attempts per minute per user
    const since = new Date(Date.now() - 60_000).toISOString();
    const { count } = await admin.from("download_logs")
      .select("id", { count: "exact", head: true }).eq("user_id", uid).gte("created_at", since);
    if ((count ?? 0) >= 10) return json(429, { error: "rate_limited" });

    // 4. project must exist and be published
    const { data: project } = await admin.from("projects")
      .select("id,status,deleted_at").eq("id", projectId).maybeSingle();
    if (!project || project.deleted_at) return json(404, { error: "not_found" });
    if (project.status !== "PUBLISHED") return await deny("NOT_PUBLISHED");

    // 5. active, non-expired, non-revoked access for THIS user and THIS project
    const { data: acc } = await admin.from("project_access")
      .select("id,expires_at").eq("user_id", uid).eq("project_id", projectId)
      .eq("status", "ACTIVE").is("revoked_at", null);
    const active = (acc ?? []).find((a) => !a.expires_at || new Date(a.expires_at) > new Date());
    if (!active) return await deny("NO_ACTIVE_ACCESS");

    // 6a. list files (metadata only)
    if (action === "list") {
      const { data: files } = await admin.from("project_files")
        .select("id,file_name,size_bytes,version").eq("project_id", projectId)
        .is("deleted_at", null).order("created_at", { ascending: false });
      return json(200, { files: files ?? [] });
    }

    // 6b. download: the file must belong to this project (blocks IDOR via file_id)
    let q = admin.from("project_files").select("id,file_name,storage_path")
      .eq("project_id", projectId).is("deleted_at", null);
    q = fileId ? q.eq("id", fileId) : q.order("created_at", { ascending: false }).limit(1);
    const { data: file } = await q.maybeSingle();
    if (!file) return json(404, { error: "not_found" });

    const { data: signed, error: se } = await admin.storage.from("originals")
      .createSignedUrl(file.storage_path, 60, { download: file.file_name });
    if (se || !signed?.signedUrl) return json(500, { error: "server_error" });

    await admin.rpc("log_download", {
      p_user: uid, p_project: projectId, p_file: file.id, p_access: active.id,
      p_outcome: "GRANTED", p_reason: null, p_ip: ip,
    });
    return json(200, { url: signed.signedUrl, file_name: file.file_name, expires_in: 60 });
  } catch (_e) {
    return json(500, { error: "server_error" });
  }
});
