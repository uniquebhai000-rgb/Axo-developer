-- AXO DEVELOPER HUB - RLS / authorization smoke test
-- Paste into the Supabase SQL Editor and Run. It creates temporary users and data, runs the checks,
-- then ALWAYS rolls back (you will see an error message at the end: that is how it undoes itself).
--   "ALL TESTS PASSED"  -> good.     Any other message -> a security check failed.
do $$
declare
  a uuid := gen_random_uuid(); b uuid := gen_random_uuid(); d uuid := gen_random_uuid(); adm uuid := gen_random_uuid();
  dev_id uuid; cat uuid; proj uuid := gen_random_uuid(); req uuid; n int; ok boolean; v_amount numeric;
begin
  insert into auth.users(id, email) values (a,'a@test.local'),(b,'b@test.local'),(d,'dev@test.local'),(adm,'admin@test.local');
  insert into public.user_roles(user_id, role) values (adm, 'SUPER_ADMIN');
  insert into public.developer_profiles(user_id, display_name, status) values (d, 'Dev One', 'APPROVED') returning id into dev_id;
  select id into cat from public.categories limit 1;
  insert into public.projects(id, developer_id, category_id, title, price_inr, status, published_at)
    values (proj, dev_id, cat, 'Test Pack', 100, 'PUBLISHED', now());
  insert into public.project_files(project_id, file_name, storage_path, size_bytes)
    values (proj, 'pack.zip', proj::text || '/pack.zip', 1000);

  -- ===== as customer A =====
  execute 'set local role authenticated';
  perform set_config('request.jwt.claims', json_build_object('sub', a, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', a::text, true);

  select count(*) into n from public.project_files;
  if n <> 0 then raise exception 'FAIL: customer can read original file records'; end if;

  select count(*) into n from public.projects where id = proj;
  if n <> 1 then raise exception 'FAIL: customer cannot see published project'; end if;

  ok := false;
  begin insert into public.user_roles(user_id, role) values (a, 'SUPER_ADMIN'); exception when others then ok := true; end;
  if not ok then raise exception 'FAIL: customer can grant themselves a role'; end if;

  ok := false;
  begin insert into public.payment_requests(user_id, project_id, amount, transaction_ref, payment_date)
        values (a, proj, 1, 'HACK123456', current_date); exception when others then ok := true; end;
  if not ok then raise exception 'FAIL: customer inserted a payment request directly'; end if;

  ok := false;
  begin update public.projects set price_inr = 0 where id = proj; get diagnostics n = row_count; if n = 0 then ok := true; end if;
  exception when others then ok := true; end;
  if not ok then raise exception 'FAIL: customer changed a project price'; end if;

  req := public.submit_payment_request(proj, 'UTR1234567890', current_date, null, 'test');
  select amount into v_amount from public.payment_requests where id = req;
  if v_amount <> 100 then raise exception 'FAIL: amount not taken from server price'; end if;

  ok := false;
  begin perform public.submit_payment_request(proj, 'UTR9999999999', current_date); exception when others then ok := true; end;
  if not ok then raise exception 'FAIL: duplicate open payment request allowed'; end if;

  ok := false;
  begin perform public.approve_payment(req); exception when others then ok := true; end;
  if not ok then raise exception 'FAIL: customer approved their own payment'; end if;

  -- ===== as customer B =====
  perform set_config('request.jwt.claims', json_build_object('sub', b, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', b::text, true);
  select count(*) into n from public.payment_requests;
  if n <> 0 then raise exception 'FAIL: customer B can see customer A payment (IDOR)'; end if;
  select count(*) into n from public.project_access;
  if n <> 0 then raise exception 'FAIL: customer B can see access records of others'; end if;

  -- ===== as admin =====
  perform set_config('request.jwt.claims', json_build_object('sub', adm, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', adm::text, true);
  perform public.approve_payment(req, 'ok');
  ok := false;
  begin perform public.approve_payment(req); exception when others then ok := true; end;
  if not ok then raise exception 'FAIL: duplicate approval allowed'; end if;

  -- ===== back to superuser: verify state =====
  execute 'reset role';
  if not public.has_active_access(a, proj) then raise exception 'FAIL: approved customer has no access'; end if;
  if public.has_active_access(b, proj) then raise exception 'FAIL: customer B has access without payment'; end if;
  select count(*) into n from public.project_access where user_id = a and project_id = proj and status = 'ACTIVE';
  if n <> 1 then raise exception 'FAIL: expected exactly one active access, got %', n; end if;
  select count(*) into n from public.developer_earnings where payment_request_id = req and net_amount = 80;
  if n <> 1 then raise exception 'FAIL: earnings row missing or wrong commission'; end if;
  select count(*) into n from public.audit_logs where action = 'PAYMENT_APPROVED';
  if n < 1 then raise exception 'FAIL: approval not audited'; end if;

  raise exception 'ALL TESTS PASSED (rolled back on purpose)';
end $$;
