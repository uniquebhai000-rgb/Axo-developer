-- TEST DATA ONLY. Replace YOUR_EMAIL with your signed-up email, then Run.
insert into public.developer_profiles(user_id, display_name, bio, status)
select id, 'AXO Studio', 'Official AXO test developer', 'APPROVED' from auth.users where email = 'YOUR_EMAIL'
on conflict (user_id) do nothing;

insert into public.user_roles(user_id, role)
select id, 'DEVELOPER' from auth.users where email = 'YOUR_EMAIL' on conflict do nothing;

insert into public.projects(developer_id, category_id, title, description, price_inr, features, compatibility, version, status, published_at)
select d.id, c.id, 'Neon PvP Texture Pack',
       'A clean, FPS-friendly neon texture pack made for competitive PvP.',
       199, '["16x16 resolution","FPS friendly","Custom sword animations"]'::jsonb,
       'Minecraft Java 1.20+', '1.0.0', 'PUBLISHED', now()
from public.developer_profiles d
join auth.users u on u.id = d.user_id
join public.categories c on c.slug = 'texture-packs'
where u.email = 'YOUR_EMAIL';

-- Show the project id (needed for the image folder name):
select id, title from public.projects order by created_at desc limit 1;

-- AFTER uploading previews/<project_id>/cover.jpg in the dashboard, link it:
-- update public.projects set cover_path = '<project_id>/cover.jpg' where id = '<project_id>';
-- insert into public.project_previews(project_id, kind, storage_path, sort_order, is_cover)
--   values ('<project_id>', 'IMAGE', '<project_id>/cover.jpg', 0, true);

-- CLEANUP (removes the test project):
-- delete from public.projects where title = 'Neon PvP Texture Pack';
