# Phase 2 + 3 backend setup (Supabase)

Do this once, in order. Use the Supabase dashboard -> **SQL Editor** -> New query.
On GitHub open each file -> tap "Raw" or the copy icon -> paste into the SQL Editor -> **Run**.

1. `supabase/migrations/001_profiles_roles.sql`
2. `supabase/migrations/002_tables.sql`
3. `supabase/migrations/003_rls_storage.sql`
4. `supabase/migrations/004_functions_seed.sql`
5. `supabase/tests/rls_smoke_test.sql`  -> should end with the message **ALL TESTS PASSED (rolled back on purpose)**

If a script fails, copy the red error here and fix before running the next one.

## Auth settings (Authentication -> Providers / Settings)
- Email provider ON, **Confirm email ON**, minimum password length 8.

## Make yourself Super Admin (after you signed up and verified email)
```sql
insert into public.user_roles(user_id, role)
select id, 'SUPER_ADMIN' from auth.users where email = 'YOUR_EMAIL';
```

## GitHub secrets for the APK
`SUPABASE_URL` and `SUPABASE_ANON_KEY` (anon/publishable key only).

## What Phase 3 gives you
- All 18 required tables (+ `support_messages`) with UUID keys, FKs, indexes, timestamps, soft delete.
- RLS on every table. Customers only see their own payments/access. Customers can never read `project_files`.
- Private storage buckets. `originals` has no client policy at all: only server code (Edge Functions, Phase 5) can read it.
- Atomic functions: `submit_payment_request`, `approve_payment`, `reject_payment`, `refund_payment`,
  `grant_access`, `revoke_access`, `extend_access`, `admin_set_project_status`, `record_payout`, ...
  Price always comes from the database, approval locks the row (no double approval), everything is audited.
- Seeded categories and settings (platform commission default 20%).

## Rules for the admin dashboard (Phase 8)
Admin functions check `auth.uid()`, so the dashboard server must call them with the **admin's own session token**.
Never ship the service-role key to the browser.

## Limits to know
- Supabase free plan: 50 MB max per uploaded file. Raise `file_size_limit` after upgrading.
- Google login and push notifications are set up in later phases.
