# Phase 5: AXO LOCK (secure downloads)

1. SQL Editor: run `supabase/migrations/005_download_log.sql`.
2. Supabase -> Edge Functions -> Deploy a new function -> Via Editor -> name `get-download-url`
   -> paste `supabase/functions/get-download-url/index.ts` -> Deploy. (Leave "Verify JWT" ON; if the app gets 401
   from the gateway, switch it OFF: the function checks the token itself.)
3. Upload a test file: Storage -> `originals` -> folder named `<project_id>` -> upload any file.
4. Register it and give yourself test access (see the SQL in chat or below), build the app, open the project -> DOWNLOAD.

```sql
insert into public.project_files(project_id, file_name, storage_path, size_bytes, mime_type)
select id, 'FILE_NAME_YOU_UPLOADED', id::text || '/FILE_NAME_YOU_UPLOADED', 1000, 'application/zip'
from public.projects where title = 'Neon PvP Texture Pack';

insert into public.project_access(user_id, project_id, reason)
select u.id, p.id, 'test access' from auth.users u, public.projects p
where u.email = 'YOUR_EMAIL' and p.title = 'Neon PvP Texture Pack';
```

## Security checks the function enforces
signed-in user, 10 requests/min limit, project PUBLISHED, ACTIVE + non-expired + non-revoked access for that exact
user and project, file must belong to the project, 60-second signed URL, every attempt logged (GRANTED/DENIED).
The `originals` bucket has no client policy, so direct storage access is impossible without the function.
