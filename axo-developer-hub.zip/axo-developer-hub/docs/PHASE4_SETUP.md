# Phase 4: marketplace

App now loads real data from Supabase: categories, published projects (recent / trending),
search + category/price/sort filters, project details, protected preview (FLAG_SECURE + watermark),
favorites, and My Library (unlocked + saved).

## Test data (run in Supabase SQL Editor, replace YOUR_EMAIL)
See `supabase/seed_test_project.sql`. It creates a test developer + one published project.
To show images, upload a JPG/PNG to Storage -> bucket `previews` -> folder `<project_id>/` and then link it
(second part of the same file).

Remove test data later with the DELETE statements at the bottom of that file.
