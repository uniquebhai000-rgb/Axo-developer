# Phase 6: payments, support, notifications

SQL (Supabase SQL Editor, in order): 007a_payments_admin.sql, 007b_support_notifications.sql

Customer: project -> GET ACCESS -> pay (UPI ID / QR shown) -> submit reference (+ optional screenshot) -> status PENDING.
Owner (Admin tab -> Payments): open request, see proof, Mark under review / Approve / Reject (with reason) / Refund and lock.
Approve runs one database transaction: row lock, access record, developer earning, notification, audit log. Double approval is impossible.
Owner (Admin tab -> Settings): UPI ID, QR image, instructions, support contact, terms.
Support: customers: Profile -> Help & support. Owner: Admin tab -> Support inbox.
Notifications: bell icon on Home. Project delete: Admin -> project -> Delete project (soft delete, history kept).

Not built (on purpose / later): Developer Studio for other developers (you asked for owner-only), Next.js web dashboard,
ratings and reviews, light theme, Google login, push notifications (FCM).
