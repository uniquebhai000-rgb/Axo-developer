# Owner-only Admin panel

Visible only to the SUPER_ADMIN account (tab "Admin"). Everything is enforced again on the server:
admin SQL functions call require_admin(), and the storage upload policies for `originals` / `previews` allow only super admin.

Run in Supabase SQL Editor (in order): `006a_admin_projects.sql`, `006b_admin_files_access.sql`.
Make yourself super admin: insert into public.user_roles(user_id, role) select id,'SUPER_ADMIN' from auth.users where email='YOUR_EMAIL' on conflict do nothing;

Panel: create project, set price, Draft/Published/Hidden, cover images, upload locked files (max 50 MB on free plan),
see who has access, unlock a user (forever / 30 days / 7 days), lock again, remove files.
