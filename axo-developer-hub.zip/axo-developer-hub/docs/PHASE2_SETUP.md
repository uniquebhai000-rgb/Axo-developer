# Phase 2 setup (Auth + profiles)

## 1. Supabase project
1. Create a project at supabase.com.
2. SQL Editor -> paste `supabase/migrations/001_profiles_roles.sql` -> Run.
3. Authentication -> Providers -> Email: enable, **turn ON "Confirm email"**, set minimum password length to 8.
4. Authentication -> Rate Limits: keep defaults or lower them (server-side protection against brute force).
5. Project Settings -> API: copy the **Project URL** and the **anon / publishable key**. Never use the service_role key in the app.

## 2. GitHub secrets (so the APK can reach your backend)
Repo -> Settings -> Secrets and variables -> Actions -> New repository secret:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

## 3. Make yourself Super Admin (once)
Sign up in the app, verify the email, then in the Supabase SQL Editor:
```sql
insert into public.user_roles(user_id, role)
select id, 'SUPER_ADMIN' from auth.users where email = 'YOUR_EMAIL';
```
Roles can only be changed server-side. The app only displays them.

## 4. Not yet included
- Google login: needs a Google Cloud OAuth client + Supabase Google provider + app deep link. Planned as a follow-up.
- Verification and reset links open in the browser. In-app deep links come later.
